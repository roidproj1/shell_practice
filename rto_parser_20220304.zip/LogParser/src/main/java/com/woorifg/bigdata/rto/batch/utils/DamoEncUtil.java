package com.woorifg.bigdata.rto.batch.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/******** DAMO API **********/
import com.penta.scpdb.ScpDbAgent;
import com.penta.scpdb.ScpDbAgentException;
/******** DAMO API **********/
public class DamoEncUtil {
	
	private static final Logger log = LoggerFactory.getLogger(DamoEncUtil.class);
	
	private static final String INI_FILE_PATH = "C:\\app\\damo3\\scpdb_agent.ini"; // Unix/Linux
	private static ScpDbAgent agt = null;
	private static byte[] ctx = null;
	private static int ret;
	
	static {
		/* DAMO SCP */
		/* DAMO SCP : initialization */
		agt = new ScpDbAgent();
		ret = agt.AgentInit(INI_FILE_PATH);
		ctx = agt.AgentCipherCreateContextServiceID("RTO", "Account");
//		log.info("init ret code : {}", ret);
//		log.debug("{}", ctx != null? ctx.toString():null);
	}
	
	/* 주민등록번호 검증  */
	public static String juminNoVerification(String juminNo){

		String convert_juminNo = "";

		if(juminNo == null){
			return juminNo;
		}else{
			convert_juminNo = juminNo.trim();
		}

		if(convert_juminNo.isEmpty() || convert_juminNo.length() != 13) {
			return juminNo;
		}

		boolean isNumber = convert_juminNo.replaceAll("\\d+", "").equals("");
		
		/* 숫자로 이루어지지 않은경우  */
		if(!isNumber){
			return juminNo;
		}

		String[] convert_juminNo_array = convert_juminNo.split("(?!^)\\b|\\B");
		int birthMonth = (Integer.parseInt(convert_juminNo_array[2]) * 10) + Integer.parseInt(convert_juminNo_array[3]);
		
		/* 생년월이 12월보다 클경우  */
		if(birthMonth > 12){
			return juminNo;
		}

		int birthDay = (Integer.parseInt(convert_juminNo_array[4]) * 10) + Integer.parseInt(convert_juminNo_array[5]);
		
		/* 생년일이 31일보다 클경우 */
		if(birthDay > 31){
			return juminNo;

		}
		
		/*
		int gender = Integer.parseInt(convert_juminNo_array[6]);

		성별이 9(1800년대남자),0(1800년대여자),1(1900년대남자),2(1900년대여자),3(2000년대남자),4(2000년대여자)가 아닐경우
		
		if(gender != 9 && gender != 0 && gender != 1 && gender != 2 && gender != 3 && gender != 4){
			return juminNo;
		}
		 */
		
		if(checkJuminNum(juminNo)){
			/* 유효한 주민등록번호일 경우 암호화한다. */
			return data_encryption(convert_juminNo,"string");
		} else {
			return juminNo;
		}


	}

	public static boolean checkJuminNum(String str) {
		if (null == str) return false;
		str = str.trim();
		if (13 != str.length()) return false;

		int checkNum[] = new int[13];
		for (int i=0; i < 13; i++) {
			// 체크해오는 값은 아스키코드 값으로 입력되므로 -48을 함
			checkNum[i] = str.charAt(i) - 48;
			if (checkNum[i] < 0 || checkNum[i] > 9) return false; // 0~9까지의 숫자이어야 함

			// 7번째 자리를 비교하여 결과값 반환
			//if (0 == checkNum[6] || 6 < checkNum[6]) return false;
		}
		// 유효성을 체크 (1~12번째 자리로 특정수를 얻은 후 13번째 번호와 비교)
		int sum = (checkNum[0] * 2)
				+ (checkNum[1] * 3)
				+ (checkNum[2] * 4)
				+ (checkNum[3] * 5)
				+ (checkNum[4] * 6)
				+ (checkNum[5] * 7)
				+ (checkNum[6] * 8)
				+ (checkNum[7] * 9)
				+ (checkNum[8] * 2)
				+ (checkNum[9] * 3)
				+ (checkNum[10] * 4)
				+ (checkNum[11] * 5);
		sum = ( 11 - (sum % 11)) % 10 ;
		// 리턴값이 11이나 10일 경우는 십의자리 수로 반환
		if (11 == sum) sum = 1;
		else if (10 == sum) sum = 0;
		//내국인
		if (checkNum[12] == sum) return true;
		//외국인
		sum +=2;
		if(sum >=10) sum-=10;
		if (checkNum[12] == sum) return true;

		return false;
	}


	/* 데이터 암호화  */
	public static String data_encryption(String data, String encType){

		if(data == null || data.isEmpty()){
			return data;
		}

		String sha = "";
		try {
//			int ret;
			//* DAMO SCP : config file full path
//			String iniFilePath = "C:\\app\\damo3\\scpdb_agent.ini";

			//* DAMO SCP
//			ScpDbAgent agt = new ScpDbAgent();

			//* DAMO SCP : initialization
			//* return : 0,118(success)
//			ret = agt.AgentInit( iniFilePath );
			//System.out.println("AgentInit ret : " + ret );
			if ( ret != 0 && ret != 118 )
			{
				//Thread.sleep(2000);
				return data.replaceAll(".", "*");
			}

			// DAMO SCP : reinitialization
			// return : 0(success)
			//Thread.sleep(2000);

			// DAMO SCP : create context
//			byte[] ctx;
//			String scpKeyFilePath = "/app/damo3/damo-scp_WOORIBANK-DEV-WOORI.key"; //keyfile.scp fullpath
//			ctx = agt.AgentCipherCreateContextImportFile( scpKeyFilePath );
//			ctx = agt.AgentCipherCreateContextServiceID( "RTO", "Account");		
//			System.out.println(ctx);
			
			if(encType.equals("string")){
				sha = agt.AgentCipherEncryptString( ctx, data );    /* DAMO SCP : encrypt/decrypt string function */
			}else if(encType.equals("index")){
				sha = agt.AgentCipherIndexString(ctx, data); /* DAMO SCP : index encrypt function */
			}else if(encType.equals("hash")){
				/* DAMO SCP : HASH function */
				/* HASH Algorithm ID :
	        SHA1 = 70
	        SHA256 = 71
	        SHA384 = 72
	        SHA512 = 73
	        HAS160 = 74
	        MD5 = 75
				 */
				sha = agt.AgentCipherHashString(71, data);
			}else if(encType.equals("*")){
				sha = data.replaceAll(".", "*");
			}else{
				sha = agt.AgentCipherEncryptString( ctx, data );    /* DAMO SCP : encrypt/decrypt string function */
			}
			//Thread.sleep(2000);
		} catch (ScpDbAgentException e1) {
			System.out.println(e1.toString());
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//  try{Thread.sleep(2000);}catch(Exception e2){}
		}

		return sha;
	}

	public static String data_encryption_new(String data, String encType) {

		if (data == null || data.isEmpty()) {
			return data;
		}

		String sha = "";
		try {
//			int ret;
			// * DAMO SCP : config file full path
//			String iniFilePath = "C:\\app\\damo3\\scpdb_agent.ini";

			// * DAMO SCP
//			ScpDbAgent agt = new ScpDbAgent();

			// * DAMO SCP : initialization
			// * return : 0,118(success)
//			ret = agt.AgentInit(iniFilePath);
			// System.out.println("AgentInit ret : " + ret );
			if (ret != 0 && ret != 118) {
				// Thread.sleep(2000);
				return data.replaceAll(".", "*");
			}
			

			// DAMO SCP : reinitialization
			// return : 0(success)
			// Thread.sleep(2000);

			// DAMO SCP : create context
//			byte[] ctx;
//			ctx = agt.AgentCipherCreateContextServiceID("RTO", "Account");
//			System.out.println(ctx);
			// String scpKeyFilePath = "/pidi_repo/damo/AES_128_E_FIXED_IV_CBC.SCPS"; //keyfile.scp fullpath
			// ctx = agt.AgentCipherCreateContextImportFile( scpKeyFilePath );
			if (encType.equals("string")) {
				sha = agt.AgentCipherEncryptString(ctx, data); /* DAMO SCP : encrypt/decrypt string function */
			} else if (encType.equals("index")) {
				sha = agt.AgentCipherIndexString(ctx, data); /* DAMO SCP : index encrypt function */
			} else if (encType.equals("hash")) {
				/* DAMO SCP : HASH function */
				/*
				 * HASH Algorithm ID : SHA1 = 70 SHA256 = 71 SHA384 = 72 SHA512 = 73 HAS160 = 74 MD5 = 75
				 */
				sha = agt.AgentCipherHashString(71, data);
			} else if (encType.equals("*")) {
				sha = data.replaceAll(".", "*");
			} else {
				sha = agt.AgentCipherEncryptString(ctx, data); /* DAMO SCP : encrypt/decrypt string function */
			}
			// Thread.sleep(2000);
		} catch (ScpDbAgentException e1) {
			System.out.println(e1.toString());
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// try{Thread.sleep(2000);}catch(Exception e2){}
		}

		return sha;
	}

	/* 데이터 복호화  */
	public static String data_decryption(String data){

		if(data == null || data.isEmpty()){

			return data;

		}

		String sha = "";
		//sha = data.replaceAll(".", "*");

		try {
//			int ret;
			//* DAMO SCP : config file full path
//			String iniFilePath = "C:\\app\\damo3\\scpdb_agent.ini";

			//* DAMO SCP
//			ScpDbAgent agt = new ScpDbAgent();

			//* DAMO SCP : initialization
			//* return : 0,118(success)
//			ret = agt.AgentInit( iniFilePath );
			//System.out.println("AgentInit ret : " + ret );
			if ( ret != 0 && ret != 118 )
			{
				//Thread.sleep(2000);
				return data.replaceAll(".", "*");
			}

			// DAMO SCP : reinitialization
			// return : 0(success)
			//Thread.sleep(2000);

			// DAMO SCP : create context
//			byte[] ctx;
			//ctx = agt.AgentCipherCreateContextServiceID( "ServiceID", "Account");
			//ctx = agt.AgentCipherCreateContext( "agent_id", "db_name", "owner", "table_name", "column_name" );
//			String scpKeyFilePath = "/pidi_repo/damo/AES_256_E_FIXED_IV_CBC.SCPS"; //keyfile.scp fullpath
//			ctx = agt.AgentCipherCreateContextImportFile( scpKeyFilePath );
//			ctx = agt.AgentCipherCreateContextServiceID( "RTO", "Account");
//			System.out.println(ctx);
			
			sha = agt.AgentCipherDecryptString( ctx, data );


			//Thread.sleep(2000);
		} catch (ScpDbAgentException e1) {
			System.out.println(e1.toString());
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//  try{Thread.sleep(2000);}catch(Exception e2){}
		}
		return sha;
	}
	
	public static void main(String[] args) {
		
//		PersonalInfomationUtil encObj = new PersonalInfomationUtil();
		
//		String tmp = PersonalInfomationUtil.data_encryption("Test00001", "string");
//		String tmp = PersonalInfomationUtil.data_decryption("A0BFAA42B498B1E0C7A70A09F36FC399");
//		System.out.println(tmp);

		String[] src = {
				"5400D3F0596D795B5E41FBCAEEBD2C1E"
		};
		
		System.out.println(DamoEncUtil.data_decryption(src[0]));
		
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00001", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00002", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00003", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00004", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00005", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00006", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00007", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00008", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00009", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00010", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00011", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00012", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00013", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00014", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00015", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00016", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00017", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00018", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00019", "string"));
//		System.out.println(PersonalInfomationUtil.data_encryption("Test00020", "string"));
		
		
	}

}
