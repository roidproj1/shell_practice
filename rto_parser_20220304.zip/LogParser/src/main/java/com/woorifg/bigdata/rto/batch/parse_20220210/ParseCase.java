package com.woorifg.bigdata.rto.batch.parse_20220210;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.utils.UUIDUtil;

public class ParseCase {

	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(ParseCase.class);

	
	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";
	private static Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);
	
	// HttpQuery Parser
	public JsonObject parseLine(String src) {
		
		// 1: HTTP_QUERY Case --> 2: parseStepHttpQuery
		
		JsonObject rsltJson = new JsonObject();
		
		try {
		
			JsonObject tmpHttpQry = parseStepHttpQuery(src);
			
			if (tmpHttpQry == null) {
				rsltJson.addProperty("HTTP_QUERY", src);
			} else {
				rsltJson.add("HTTP_QUERY", tmpHttpQry);
			}
			
		} catch (Exception e) {
			
//			e.printStackTrace();
			rsltJson.addProperty("HTTP_QUERY", src);
			
			log.debug("HttpQuery toJson Error : {}", src);
		}
		
		return rsltJson.size() == 0 ? null : rsltJson;

	}

	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {

					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) {

					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}

				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value

					// dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}	
	
	
	
	public static void main(String[] args) {
		
		
		String[] htp_qurey_case = {
				"PHONE_TYPE\u003dAndroid\u0026__STEP\u003d\u0026withyou\u003dNFSVC0002"
		};
		
		Gson gs = new Gson();
		JsonObject json;
		
		
		

//		log.debug("RndKey : {}", getRndKey());

		log.debug("LogAggrDatetime : {}", getNow());

		String[] httpTime = { "20211116150002859" };
		parseHttpTime(httpTime[0]);

		String[] remoteUser = { "KJFOUND_/3_/0_/idLogin" };
		parseRemoteUser(remoteUser[0]);

		String[] userAgent = {
				"Mozilla/5.0 (iPhone; U; CPU iOS 12_4_1 like Mac OS X; ko-kr) AppleWebKit/528.18 (KHTML, like Gecko) Mobile;nma-plf\u003dIPN;nma-plf-ver\u003d12.4.1;nma-siteid\u003dSMTMPB;SMT_RGS_YN\u003dY;nma-app-ver\u003d2.1.1;push-id\u003dnoToken;nma-uniqueid\u003dPB_I_W_B_001;nma-imodel\u003diPhone7,2;IDFA\u003dFBD48A02-5513-4DE4-A4D3-79DFF1A40ACA;appId\u003dWooriWON", // wnsmt
				"Mozilla/5.0 (iPhone; U; CPU iOS 13_3_1 like Mac OS X; ko-kr) AppleWebKit/528.18 (KHTML, like Gecko) Mobile;nma-plf\u003dIPN;nma-plf-ver\u003d13.3.1;nma-siteid\u003dSMTMPB;SMT_RGS_YN\u003dY;nma-app-ver\u003d9.0.0;push-id\u003dnoToken;nma-uniqueid\u003dPB_I_W_B_001;nma-imodel\u003diPhone9,3;nma-mydata\u003dY;IDFA\u003dCB6A4FC8-3812-48E5-B0A4-6C7F8C94EF86;appId\u003dWooriWON",
				"Mozilla/5.0 (Linux; Android 11; SM-G981N Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.74 Mobile Safari/537.36;nma-plf\u003dADR;SMT_RGS_YN\u003dY;nma-plf-ver\u003d30;nma-siteid\u003dSMTMPB;nma-uniqueid\u003dPB_A_W_B_001;nma-model\u003dSM-G981N;nma-login-type\u003dWON_CERT;nma-os-ver\u003dAndroid 11;push-id\u003deEaA9b-lSrGeYYOajUoATG:APA91bHD8AlYWeEKvbKU3J3R70F-oC96xdmKKktFUhpF5bMez7gLwGEZb_OKBKzIx5_nDsEIvkeAPE39YHTKkgzrdhWj72sZWX9X0VYY2-h0TKdjEwz-yPhHs8Pz3uMrMu2QI2SpGmO5;nma-app-ver\u003d2.1.3;ADID\u003d7cbb30e1-c063-453f-931e-1de230a1dcd5",
				"Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD1.170816.004) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Mobile Safari/537.36",
				"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Mobile Safari/537.36", // wnpot
				"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 3.0.30729; .NET CLR 3.5.30729)", 
		};

		parseUserAgent(userAgent[0]);

		String[] cc = { 
				"c043442:c043561",
				"../../../../../../../../../../../../../../../../../../../../Windows/System32/drivers/etc/services\u0000",
				"c007095:c009166/../../../../../../../../../../../../../../../../../../../../etc/passwd\u0000",
				"file:///etc/passwd", "https://wapiti3.ovh/e.php\u0000", 
		};

		log.debug("cc: {}", parseCpntCnInfo(cc[2], null));

		String[] m = { 
				"i", 
				"e", 
				"10222", 
				"10264", 
				"30002", 
				"eai", 
		};

//		log.debug("m: {}", parsePsnzChnlKey(m[3]));		

		String[] s = { 
				"0", 
				"", 
		};

		/*
		 * log.debug("s: {}", parsePsnzScnrKey(m[2], s[0]));
		 */

		String[] sQrAdvpeNo = { 
				"", 
		};

		String[] sQr_advpe_no = { 
				"", 
		};

		log.debug("qr_advpe_no: {}", parseQrAdvpeNo(sQrAdvpeNo[0], sQr_advpe_no[0]));

		// .HTTP_QUERY.ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.ACNO
		String[] htp_qry_acno = { 
				"", 
		};

		String[] htp_qry_json_dat_req_dat_acno = { 
				"", 
		};

		String[] acno = { 
				htp_qry_acno[0], 
				htp_qry_json_dat_req_dat_acno[0], 
		};

//		log.debug("acno: {}", parseAcno(acno));

		// .HTTP_QUERY.BKCD , .HTTP_QUERY.bkCd , .HTTP_QUERY._JSON_DATA._REQ_DATA.BKCD
		String[] htp_qry_bkcd_01 = { 
				"", 
		};

		String[] htp_qry_bkcd_02 = { 
				"", 
		};

		String[] htp_qry_json_dat_req_dat_bkcd = { 
				"", 
		};

		String[] bkcd = { 
				htp_qry_bkcd_01[0], 
				htp_qry_bkcd_02[0], 
				htp_qry_json_dat_req_dat_bkcd[0], 
		};

//		log.debug("acno: {}", parseBkcd(bkcd));		

		// .HTTP_QUERY.INQ_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.INQ_ACNO
		String[] htp_qry_inq_acno = { 
				"", 
		};

		String[] htp_qry_json_dat_req_dat_inq_acno = { 
				"", 
		};

		String[] inq_acno = { 
				htp_qry_inq_acno[0], 
				htp_qry_json_dat_req_dat_inq_acno[0], 
		};

//		log.debug("inq_acno: {}", parseInqAcno(inq_acno));		

		// .HTTP_QUERY.WDR_BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_BKCD
		String[] htp_qry_wdr_bkcd = { 
				"", 
		};

		String[] htp_qry_json_dat_req_dat_wdr_bkcd = { 
				"", 
		};

		String[] wdr_bkcd = { 
				htp_qry_wdr_bkcd[0], 
				htp_qry_json_dat_req_dat_wdr_bkcd[0], 
		};

//		log.debug("wdr_bkcd: {}", parseWdrBkcd(wdr_bkcd));			

		// .HTTP_QUERY.WDR_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_ACNO
		String[] htp_qry_wdr_acno = { "", };

		String[] htp_qry_json_dat_req_dat_wdr_acno = { "", };

		String[] wdr_acno = { htp_qry_wdr_acno[0], htp_qry_json_dat_req_dat_wdr_acno[0], };

//		log.debug("wdr_acno: {}", parseWdrAcno(wdr_acno));			

		String[] http_referer = { 
				"https://wnpib.wooribank.com/pib/Dream?withyou\u003dPSBAC0000",
				"https://wnpib.wooribank.com/pib/Dream?withyou=PSBAC0000&target=AAAAA&withyou=PSBAC0009", 
		};

		String[] htp_qry_withyou = { 
				"PSBAC0179",
				"PSDEP0010/../../../../../../../../../../Windows/System32/drivers/etc/services\u0000",
				"https://wapiti3.ovh/e.php", "C:\\Windows\\System32\\drivers\\etc\\services\u0000", 
				"Dream::$DATA",
				"mwcsc0009", 
				"", 
		};

		log.debug("withyou: {}", parsePageId(htp_qry_withyou[2], http_referer[0]));

		
		
		// parsePsnzChnlKey가 30002인 경우는 parsePsnzScnrKey값을 step로 저장
		String scnrKey = parsePsnzScnrKey(m[2], s[0]);
		
		String[] step = {
				"10",
				scnrKey,
				
		};

		log.debug("step: {}", parsePageStepOrder(step[0]));

	}

	/*** Utility ***/

	public static void printHashMap(HashMap<String, String> src) {
		if (src != null && src.size() > 0) {
			for (String key : src.keySet()) {
				log.debug("{} : {}", key, src.get(key));
			}
		}
	}

	public static String[] explode(String str, String delim, boolean isTrim) {
		int delimLength = delim.length();

		List<String> list = new LinkedList<String>();
		int sidx = 0;
		int eidx = 0;
		while (true) {
			eidx = str.indexOf(delim, sidx);
			String col = _substring(str, sidx, eidx, isTrim);
			list.add(col);

			if (-1 == eidx)
				break;

			sidx = eidx + delimLength;
		}

		return list.toArray(new String[list.size()]);
	}

	private static String _substring(String str, int sidx, int eidx, boolean isTrim) {
		String retval;
		if (eidx < 0)
			retval = str.substring(sidx);
		else
			retval = str.substring(sidx, eidx);

		if (isTrim)
			return retval.trim();
		else
			return retval;
	}

	public static String parsePtn(String sPtn, String src) {

		if (src == null || "".equals(src.trim())) {
			return null;
		}

		Pattern ptn = Pattern.compile(sPtn);
		Matcher mtch = ptn.matcher(src);
		StringBuilder rslt = new StringBuilder();

		while (mtch.find() && mtch.groupCount() != 0) {

			if (mtch.groupCount() > 1) {

				log.debug("{} : {} ===> ", sPtn, src);

				for (int i = 0; i <= mtch.groupCount(); i++) {
					log.debug("{} : {}, ", i, mtch.group(i));
				}
			}

			rslt.append(mtch.group(1));
		}

		return rslt.length() == 0 ? null : rslt.toString();
	}

	public static String parsePtn(String sPtn, String src, int idx) {

		if (src == null || "".equals(src.trim())) {
			return null;
		}

		Pattern ptn = Pattern.compile(sPtn);
		Matcher mtch = ptn.matcher(src);
		StringBuilder rslt = new StringBuilder();

		while (mtch.find() && mtch.groupCount() != 0) {

			if (mtch.groupCount() > 1) {

				log.debug("{} : {} ===> ", sPtn, src);

				for (int i = 0; i <= mtch.groupCount(); i++) {
					log.debug("{} : {}, ", i, mtch.group(i));
				}
			}

			rslt.append(mtch.group(idx));
		}

		return rslt.length() == 0 ? null : rslt.toString();
	}

	public static String strArrContains(String[] strArr) {

		if (strArr == null) {
			return null;
		}

		for (String s : strArr) {
			if (s != null && !s.trim().isEmpty()) {
				return s;
			}
		}

		return null;
	}

	/*** Parse ***/

	/***
	 * RndKey , rnd_key
	 ***/
	public static String getRndKey() {
		return UUIDUtil.getRndKey8();
	}

	/***
	 * LogAggrDatetime , log_aggr_datetime
	 ***/
	public static String getNow() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}

	public static String getLogAggrDatetime() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}

	/***
	 * HttpTime , http_time http_time_occur_date http_time_occur_time ymdh
	 * 
	 ***/
	public static HashMap<String, String> parseHttpTime(String src) {

		HashMap<String, String> rsltMap = new HashMap<String, String>();

		if (src == null || src.trim().isEmpty()) {
			rsltMap.put("ymdh", null);
			rsltMap.put("http_time_occur_date", null);
			rsltMap.put("http_time_occur_time", null);
			return rsltMap;
		}

		if (src.trim().length() >= 8) {
			rsltMap.put("http_time_occur_date", src.substring(0, 8));
		}

		if (src.trim().length() >= 10) {
			rsltMap.put("ymdh", src.substring(0, 10));
		}

		if (src.trim().length() == 17) {
			rsltMap.put("http_time_occur_time", src.substring(8, 17));
		}

		printHashMap(rsltMap);

		return rsltMap;
	}

	/***
	 * RemoteUser , remote_user remote_user_id remote_user_sex remote_user_age
	 * remote_user_logintype
	 * 
	 ***/
	public static HashMap<String, String> parseRemoteUser(String src) {

		HashMap<String, String> rsltMap = new HashMap<String, String>();

		if (src == null || src.trim().isEmpty()) {
			rsltMap.put("remote_user_id", null);
			rsltMap.put("remote_user_sex", null);
			rsltMap.put("remote_user_age", null);
			rsltMap.put("remote_user_logintype", null);
			return rsltMap;
		}

		String[] rslt = explode(src, "_/", true);

		int c = rslt.length;

		switch (c) {

		case 4:
			rsltMap.put("remote_user_logintype", rslt[3]);
		case 3:
			rsltMap.put("remote_user_age", rslt[2]);
		case 2:
			rsltMap.put("remote_user_sex", rslt[1]);
		case 1:
			rsltMap.put("remote_user_id", rslt[0]);
			break;

		}

		printHashMap(rsltMap);

		return rsltMap;
	}

	/***
	 * UserAgent , user_agent user_agent_osinfo_android
	 * user_agent_model_info_android user_agent_osinfo_ios user_agent_model_info_ios
	 * nma_app_ver push_id adid idfa
	 ***/
	public static HashMap<String, String> parseUserAgent(String src) {

		final String userAgentOsinfoAndroidPtn = ";.?Android.?([0-9\\.]*);.?[^;|\\)]*";
		final String userAgentModelInfoAndroidPtn = ";.?Android.?[0-9\\.]*;.?([^;|\\)]*)";
		final String userAgentOsinfoIosPtn = ";.?CPU .*?OS.?([0-9_]*)[^;]*";
		final String userAgentModelInfoIosPtn = "\\([^;]*;.?[U|u];.?CPU (.*)?OS.?[0-9_]*[^;]*";
		final String nmpAppVerPtn = ";nma-app-ver=[\\[]?([0-9\\.]*)";
		final String pushIdPtn = ";push-id=([^;]*)";
		final String adidPtn = ";ADID=([a-zA-Z0-9-]*)";
		final String idfaPtn = ";IDFA=([^;]*)";

		HashMap<String, String> rsltMap = new HashMap<String, String>();

		if (src == null || src.trim().isEmpty()) {
			rsltMap.put("user_agent_osinfo_android", null);
			rsltMap.put("user_agent_model_info_android", null);
			rsltMap.put("user_agent_osinfo_ios", null);
			rsltMap.put("user_agent_model_info_ios", null);
			rsltMap.put("nma_app_ver", null);
			rsltMap.put("push_id", null);
			rsltMap.put("adid", null);
			rsltMap.put("idfa", null);

			return rsltMap;
		}

		rsltMap.put("user_agent_osinfo_android", parsePtn(userAgentOsinfoAndroidPtn, src));
		rsltMap.put("user_agent_model_info_android", parsePtn(userAgentModelInfoAndroidPtn, src));
		rsltMap.put("user_agent_osinfo_ios", parsePtn(userAgentOsinfoIosPtn, src));
		rsltMap.put("user_agent_model_info_ios", parsePtn(userAgentModelInfoIosPtn, src));
		rsltMap.put("nma_app_ver", parsePtn(nmpAppVerPtn, src));
		rsltMap.put("push_id", parsePtn(pushIdPtn, src));
		rsltMap.put("adid", parsePtn(adidPtn, src));
		rsltMap.put("idfa", parsePtn(idfaPtn, src));

		printHashMap(rsltMap);

		return rsltMap;
	}

	
	public static String parseCpntId(String sId, String sReferer) {
		
		final String sIdPtn = "(^c[a-zA-Z0-9]*)";
		final String sRefererPtn = "__ID=(c[a-zA-Z0-9]*)";
		
		if(sId != null) {
			return parsePtn(sIdPtn, sId, 0);
		} else {
			return parsePtn(sRefererPtn, sReferer, 1);
		}
		
	}

	
	public static String parseCpntCnInfo(String sCc, String sReferer) {

		final String sCcPtn = "^(c\\d+[:|;]?)+";
		final String sRefererPtn = "cc=(c\\d+[:|;]?)+";

		String rslt = null;
		
		if(sCc != null) {
			rslt = parsePtn(sCcPtn, sCc, 0);
		} else {
			rslt = parsePtn(sRefererPtn, sReferer, 1);
		}

		if (rslt != null) {
			rslt = rslt.replace("\\|", "");
		}

		return rslt;
	}

	
	public static String parsePlmPdcd(String sPlmPdcd) {
		
		if (sPlmPdcd == null || sPlmPdcd.trim().isEmpty()) {
			return null;
		}
		
		final String sPlmPdcdPtn = "(^P[0-9]{9})";
		
		return parsePtn(sPlmPdcdPtn, sPlmPdcd, 0);
		
	}
	

	public static String parsePrdCd(String sPrdCd, String sReferer) {
		
		final String sRefererPtn = "PRD_CD=([a-zA-Z0-9]*)";
		
		if(sPrdCd != null) {
			return sPrdCd;
		} else {
			return parsePtn(sRefererPtn, sReferer, 1);
		}
		
	}	

	
	public static String parseEventNo(String sEventNo) {
		
		final String sEventNoPtn = "(^[0-9a-zA-Z]{6})";
		
		if(sEventNo == null || sEventNo.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sEventNoPtn, sEventNo, 0);
		}
		
	}	
	
	
	
	public static String parsePsnzChnlKey(String psnzChnlKey) {

		if (psnzChnlKey == null || psnzChnlKey.trim().isEmpty()) {
			return null;
		}

		final String psnzChnlKeyValidPtn = "e|f|i|p|pubmain|s|10222|10264|30002|10224";

		return Arrays.asList(psnzChnlKeyValidPtn.split("\\|")).contains(psnzChnlKey) ? psnzChnlKey : null;
	}

	
	public static String parsePsnzAreaKey(String psnzAreaKey) {
		
		final String sPsnzAreaKeyPtn = "([a-zA-Z0-9_]*)";
		
		if(psnzAreaKey == null || psnzAreaKey.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sPsnzAreaKeyPtn, psnzAreaKey, 0);
		}
		
	}	
	
	
	public static String parsePsnzScnrKey(String m, String src) {

		if (src == null || src.trim().isEmpty()) {
			return null;
		}

		String psnzScnrKeyValidPtn = "10222|10264|30002";

		return Arrays.asList(psnzScnrKeyValidPtn.split("\\|")).contains(src) ? src : null;
	}
	
	
	public static String parsePsnzCtnsKey(String psnzCtnsKey) {
		
		final String sPsnzCtnsKeyPtn = "(^[0-9]{4})";
		
		if(psnzCtnsKey == null || psnzCtnsKey.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sPsnzCtnsKeyPtn, psnzCtnsKey, 0);
		}
	}	

	public static String parsePsnzTgtKey(String psnzTgtKey) {
		
		final String sPsnzTgtKeyPtn = "([0-9]{1,5})";
		
		if(psnzTgtKey == null || psnzTgtKey.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sPsnzTgtKeyPtn, psnzTgtKey, 0);
		}
	}	
	
	public static String parseCmdCd(String cmdCd) {
		final String sCmdCdPtn = "([a-zA-Z0-9_]*)";
		
		if(cmdCd == null || cmdCd.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sCmdCdPtn, cmdCd, 0);
		}
	}
	

	public static String parseQrBrCd(String qrBrCd) {
		final String sQrBrCdPtn = "([0-9]{8})";
		
		if(qrBrCd == null || qrBrCd.trim().isEmpty()) {
			return null;
		} else {
			return parsePtn(sQrBrCdPtn, qrBrCd, 0);
		}
	}	
	

	public static String parseQrAdvpeNo(String sQrAdvpeNo, String sQr_advpe_no) {
		
		String[] src = {
				sQrAdvpeNo,
				sQr_advpe_no
		};
		
		return strArrContains(src);
	}

	public static String parseSearchText(String inbkSearchText, String smtbkSearchText) {
		
		String[] src = {
				inbkSearchText,
				smtbkSearchText
		};
		
		return strArrContains(src);
	}
	

	public static String parsePageId(String htp_qry_withyou, String http_referer) {

		String rslt = null;

		final String htpQryWithyouPtn = "(^[a-zA-Z0-9]{2,15})";
		final String httpRefererPtn = "\\?withyou=([a-zA-Z0-9]{2,15})";

		if (htp_qry_withyou != null && !htp_qry_withyou.trim().isEmpty()) {
			rslt = parsePtn(htpQryWithyouPtn, htp_qry_withyou);
		}

		if (http_referer != null && !http_referer.trim().isEmpty()) {
			if (rslt == null) {
				rslt = parsePtn(httpRefererPtn, http_referer);
			}
		}

		// Dream 및 쓰레기 Data 제거
		if (rslt != null) {
			if ((rslt.indexOf("Dream") > -1 || rslt.indexOf("passwd") > -1)
					|| !(rslt.length() == 2 || rslt.length() > 5)) {
				rslt = null;
			}
		}

		// 2자리 추출 case 제외 대문자화
		if (rslt != null && rslt.length() != 2) {
			rslt = rslt.toUpperCase();
		}

		return rslt;
	}

	
	public static String parsePageStepOrder(String sReferer, String... sStep) {

		String rslt = null;
		
		if(sStep != null && sStep.length == 1 && !"".equals(sStep[0])) {
			rslt = strArrContains(sStep);
		}
		
		final String stepOrderPtn = "(^[0-9]{0,2})";
		final String sRefererPtn = "__STEP=([0-9]{0,2})";
		
		if(rslt == null) {
			return parsePtn(sRefererPtn, sReferer, 1);
		} else {
			return parsePtn(stepOrderPtn, rslt);
		}
 
	}

	
	public static String parseAcno(String... src) {
		return strArrContains(src);
	}

	public static String parseBkcd(String... src) {
		return strArrContains(src);
	}

	public static String parseInqAcno(String... src) {
		return strArrContains(src);
	}

	public static String parseWdrBkcd(String... src) {
		return strArrContains(src);
	}

	public static String parseWdrAcno(String[] src) {
		return strArrContains(src);
	}	



}
