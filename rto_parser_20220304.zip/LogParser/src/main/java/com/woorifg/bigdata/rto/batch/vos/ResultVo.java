package com.woorifg.bigdata.rto.batch.vos;

import java.util.List;

import lombok.Data;

@Data
public class ResultVo {

	private String query;
	private List<String> args;
	
}
