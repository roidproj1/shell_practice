package com.woorifg.bigdata.rto.batch.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class JsonToSQL {

	private static final Logger log = LoggerFactory.getLogger(JsonToSQL.class);

	private static final String IN_CHARSET = "UTF-8";
	private static final String OUT_CHARSET = "UTF-8";

	public static void main(String[] args) {

		StopWatch swch = new StopWatch("logToJson");
		swch.start("allStep");
		
//		final String SRC_PATH = "/Proj/LogExmples/tmp_json/";
		final String SRC_PATH = "/Proj/LogExmples/dev_json/";		
		
//		final String TGT_PATH = "/Proj/LogExmples/tmp_json/";
		final String TGT_PATH = "/Proj/LogExmples/dev_sql/";		


		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), 
//				"*.parse.{json}"
				"*.{json}"				
				)) 
		{
			
			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());				
				srcFiles.add(path.toFile());
			});

			dirStream.close();
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		

		Gson gs = new Gson();
		
		JsonObject json = null;
		String rsltJsonStr = null;
		
		String rd_line = null;
		String sqlStr = null;
		
		long idxLn = 0L;

		for (File src : srcFiles) {
			
			if (src.exists()) {

				idxLn = 0L;

				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + ".sql.info");
//					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					rd_line = null;

					while ((rd_line = br.readLine()) != null) {
					
						System.out.println(sqlStr = JsonToInsert(rd_line));
						owr.write(sqlStr + "\n");
						
					}
					
					owr.close();
					br.close();
						
				} catch(Exception e) {
					e.printStackTrace();
				} 
			}
			
		}

	}

	private static String JsonToInsert(String rd_line) throws Exception {
		
		// keys
		// values
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("INSERT INTO (");

		List<String> keys = new ArrayList<String>();
		List<String> values = new ArrayList<String>();		
		
		JsonElement el = JsonParser.parseString(rd_line);
		JsonObject obj = el.getAsJsonObject(); 
		
		Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();
		
		for(Map.Entry<String, JsonElement> entry : entries) {
//			System.out.println(entry.getKey());
			keys.add(entry.getKey());
			
//			System.out.println(entry.getValue());
			values.add(entry.getValue().getAsString());
		}
		
		
		int i = 0;
		for(String key : keys) {
			
			if(i==0) {
				sb.append(key);
			} else {
				sb.append(",").append(key);
			}
			
			i++;
		}
		
		sb.append(") VALUES (");
		
		i = 0;
		for(String val : values) {
			
			if(i==0) {
				sb.append("'").append(val).append("'");
			} else {
				sb.append(",").append("'").append(val).append("'");
			}
			
			i++;
		}		
		
		sb.append(");");
		
		return sb.toString();

	}
	


}
