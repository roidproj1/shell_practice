package com.woorifg.bigdata.rto.batch.enums_20220210;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.Getter;

@Getter
public enum ETest {
	
	test1("tt1"),
	test2("tt2"),
	test3("tt3"),
	test4("tt4"),
	test5("tt1"),
	test6("tt6"),
	test7("tt7"),
	test8("tt8"),
	;
	
	
	private final String key;
	
	ETest(String key) {
		this.key = key;
	}
	
	private static final Map<String, ETest> jsonKeys =
			Collections.unmodifiableMap(Stream.of(values())
			.collect(Collectors.toMap(ETest::getKey, Function.identity())));
	
	public static Optional<ETest> find(String key) {
		return Optional.ofNullable(jsonKeys.get(key));
	}
	

}
