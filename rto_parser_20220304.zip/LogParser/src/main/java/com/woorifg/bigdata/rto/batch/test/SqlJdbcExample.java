/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.woorifg.bigdata.rto.batch.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.apache.ignite.client.ClientConnectionException;

import com.google.gson.Gson;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.utils.UUIDUtil;
import com.woorifg.bigdata.rto.batch.vos.TestVoKey;


public class SqlJdbcExample {

	/** schema name. */
	
	private static final String SCHEMA = "PUBLIC";

	public static void main(String[] args) throws Exception {

//		Class.forName("org.apache.ignite.IgniteJdbcThinDriver");
		
//		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800?lazy=true;distributedJoins=true")) {
		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {		
	
			String jsonStr = "{\"HTTP_CC_GUID\":\"20200730130438c0a8755c0187b0015c\",\"HTTP_CC_SESSION\":\"20211024185237c0a8755c015470008c\",\"SERVER_HOST\":\"wnbiz.wooribank.com\",\"SERVER_URL\":\"/biz/Dream\",\"REMOTE_ADDR\":\"1.232.5.3\",\"REMOTE_USER\":\"TESTFXD002_/2_/51\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnbiz.wooribank.com/biz/Dream?withyou=BZFXD0343\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"GET\",\"HTTP_TIME\":\"20211025010206406\",\"HTTP_QUERY\":\"B808F33356D2630466CFB5EB77874EA3CC3195977A2EB231D81DF0A54E128F52\",\"rnd_key\":\"6e30cf77\",\"log_aggr_datetime\":\"20220211144913255\"}";
			
			Gson gs = new Gson();
			
			TestVoKey vok = gs.fromJson(jsonStr, TestVoKey.class);
			LogOrgDto vo = gs.fromJson(jsonStr, LogOrgDto.class);
			
			vok.setRnd_key(UUIDUtil.getRndKey8());
			vok.setLog_aggr_datetime(UUIDUtil.getNow());
			
			vo.setRnd_key(vok.getRnd_key());
			vo.setLog_aggr_datetime(vok.getLog_aggr_datetime());
			
//			cache.put(vok, vo);
			
//			try (PreparedStatement stmt = conn.prepareStatement(
//					"INSERT INTO LOG_ORG("+ 
//							"http_cc_guid," + 
//							"http_cc_session," + 
//							"http_time," + 
//							"host_name," + 
//							"log_aggr_datetime," + 
//							"rnd_key," + 
//							"http_cookie," + 
//							"http_method," + 
//							"http_referer," + 
//							"http_uri," + 
//							"remote_addr," + 
//							"remote_user," + 
//							"server_host," + 
//							"server_url," + 
//							"user_agent," + 
//							"http_query" + 
//							") values ( " +
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?," + 
//								"?" +
//							")"
//			)) {
//				
//				int idx = 1;
//				
//				stmt.setString(idx++, vo.getHttp_cc_guid());
//				stmt.setString(idx++, vo.getHttp_cc_session());
//				stmt.setString(idx++, vo.getHttp_time());
//				stmt.setString(idx++, vo.getHost_name());
//				stmt.setString(idx++, vo.getLog_aggr_datetime());
//				stmt.setString(idx++, vo.getRnd_key());
//				stmt.setString(idx++, vo.getHttp_cookie());
//				stmt.setString(idx++, vo.getHttp_method());
//				stmt.setString(idx++, vo.getHttp_referer());
//				stmt.setString(idx++, vo.getHttp_uri());
//				stmt.setString(idx++, vo.getRemote_addr());
//				stmt.setString(idx++, vo.getRemote_user());
//				stmt.setString(idx++, vo.getServer_host());
//				stmt.setString(idx++, vo.getServer_url());
//				stmt.setString(idx++, vo.getUser_agent());
//				stmt.setString(idx++, vo.getHttp_query());
//				stmt.executeUpdate();
//			}
			
			
			
			
			
			
			
//			Long idx = 1L;
//			
//			SqlFieldsQuery qry = new SqlFieldsQuery("INSERT INTO city (id, name) VALUES (?, ?)");
//			
//			cache.query(qry.setArgs(idx++, "Forest Hill")).getAll();
//			cache.query(qry.setArgs(idx++, "Denver")).getAll();
//			cache.query(qry.setArgs(idx++, "St. Petersburg")).getAll();
//			
//			
//			idx = 1L;
//
//			qry = new SqlFieldsQuery("INSERT INTO person (id, name, city_id) values (?, ?, ?)");
//
//			cache.query(qry.setArgs(idx++, "John Doe", 3L)).getAll();
//			cache.query(qry.setArgs(idx++, "Jane Roe", 2L)).getAll();
//			cache.query(qry.setArgs(idx++, "Mary Major", 1L)).getAll();
//			cache.query(qry.setArgs(idx++, "Richard Miles", 2L)).getAll();
//
//			print("Populated data.");
//
//			
//			FieldsQueryCursor<List<?>> cursor = cache.query(
//					new SqlFieldsQuery("SELECT p.name, c.name FROM Person p INNER JOIN City c on c.id = p.city_id")
//			);
			
			
//			List<List<?>> res = cache.query(
//					new SqlFieldsQuery("SELECT p.name, c.name FROM Person p INNER JOIN City c on c.id = p.city_id")
//			).getAll();
			
			
//			print("Query results:");
//
//			
//			for (Object next : cursor)
//				System.out.println(">>>    " + next);

			
//          cache.query(new SqlFieldsQuery("drop table Person")).getAll();
//          cache.query(new SqlFieldsQuery("drop table City")).getAll();

		} catch (ClientConnectionException ex) {
			ex.printStackTrace();
		}

//		print("Cache query Thin example finished.");

	}

	/**
	 * Prints message.
	 *
	 * @param msg Message to print before all objects are printed.
	 */
	private static void print(String msg) {
		System.out.println();
		System.out.println(">>> " + msg);
	}
}
