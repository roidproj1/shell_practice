package com.woorifg.bigdata.rto.batch.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class KeyParseUtil {

	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}
	
	private static final Logger log = LoggerFactory.getLogger(KeyParseUtil.class);
	private static final int DEPTH_LIMIT = 5;
	

	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";
	private static Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);

	// HttpQuery Parser
	public static JsonObject parseLine(String src) {
		
		// 1: HTTP_QUERY Case --> 2: parseStepHttpQuery
		
		JsonObject rsltJson = new JsonObject();
		
		try {
		
			JsonObject tmpHttpQry = parseStepHttpQuery(src);
		
			if (tmpHttpQry == null) {
				rsltJson.addProperty("HTTP_QUERY", src);
			} else {
				rsltJson.add("HTTP_QUERY", tmpHttpQry);
			}
			
		} catch (Exception e) {
			
//			e.printStackTrace();
			rsltJson.addProperty("HTTP_QUERY", src);
			
			log.debug("HttpQuery toJson Error : {}", src);
		}
		
		return rsltJson.size() == 0 ? null : rsltJson;

	}

	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
		System.out.println("parseStepHttpQuery : " + sHttpQry);
		
		while (mtch.find()) {
			
			System.out.println(mtch.group(0));

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {

					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) {

					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}

				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value

					// dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}		
	
	
	public static TreeMap<String, String> parseKeyValues(String jsonStr) {
		
		TreeMap<String, String> keys = new TreeMap<String, String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonKeyValues(keys, json, "", 1);	
		

		
		return keys;
		
	}
	
	
	private static TreeMap<String, String> _getJsonKeyValues(TreeMap<String, String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!"".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
			
			if(entry.getValue().isJsonArray()) {
				keys.put(hd + entry.getKey(), entry.getValue().toString());
			}

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.put(hd + entry.getKey(), entry.getValue().toString());
				_getJsonKeyValues(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.containsKey(hd + entry.getKey())) {
					try {
						keys.put(hd + entry.getKey(), entry.getValue().getAsString());
					} catch(Exception e) {
						log.error(entry.getKey());
					}
				}
			}
		}
		return keys;
	}
	
	
	
	public static List<String> parseJsonKeys(String jsonStr) {
		
		List<String> keys = new ArrayList<String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonKeys(keys, json, "", 1);	
		
		return keys;
		
	}	
	

	private static List<String> _getJsonKeys(List<String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!"".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.add(hd + entry.getKey());
				_getJsonKeys(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.contains(hd + entry.getKey())) {
					keys.add(hd + entry.getKey());
				}
			}
		}
		return keys;
	}
	
	
	
	public static List<String> parseJsonPathKeys(String jsonStr) {
		
		List<String> keys = new ArrayList<String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonPathKeys(keys, json, ".", 1);	
		
		return keys;
		
	}

	private static List<String> _getJsonPathKeys(List<String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!".".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.add(hd + entry.getKey());
				_getJsonPathKeys(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.contains(hd + entry.getKey())) {
					keys.add(hd + entry.getKey());
				}
			}
		}
		return keys;
	}
	

	
	public static void main(String[] args) {
		
		String[] jsonStr = {
				"PHONE_TYPE\u003dAndroid\u0026__STEP\u003d\u0026withyou\u003dNFSVC0002",
				
//				"{\"HTTP_CC_GUID\":\"20211206134705c0a8755c016870004e\",\"HTTP_CC_SESSION\":\"20211206134705c0a8755c016870004e\",\"SERVER_HOST\":\"wnwib.wooribank.com\",\"SERVER_URL\":\"/wib/brand\",\"REMOTE_ADDR\":\"106.247.226.242\",\"REMOTE_USER\":\"ILOVEPSY07_/1_/42\",\"USER_AGENT\":\"Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G935S Build/R16NW);nma-plf\\u003dADR;SMT_RGS_YN\\u003dY;nma-plf-ver\\u003d26;nma-siteid\\u003dBRAND;nma-uniqueid\\u003dPB_A_W_B_001;nma-model\\u003dSM-G935S;push-id\\u003de9YlXKouFQM:APA91bGM7T2n3gnZzOe3QkVuxiXjKGrs5UYk6VPwzq0UmfYUkgFyMFByR0zC4emugZ874OtVvpt8KMkDcVPWmodtKvocMi-27F1Kio5edBzQk-y-2sy6hD6sCdWWCRBP7XK7Y4gvtpPc;nma-app-ver\\u003d3.4.9\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140404203\",\"HTTP_QUERY\":{\"DEVICE_ID_GROUP\":\"eyJJU19FTkMiOiJZIiwiREVWSUNFX0lEIjoiTXpVMU5qUTNNRGN3T0RBME9UYzEiLCJHT09HTEVfQURfSUQiOiJNVE16TUdZNVltRXRaamN5T1MwMFpXTmxMV0k1TXpNdE1UYzBaamRoTjJVeU5XWXkiLCJBTkRST0lEX0lEIjoiTkRjelpUZG1ZVGhpTTJJek56TmtOZz09In0\\u003d\",\"_COM_SMT_UNIQUEID\":\"1MzU1NjQ3MDcwODA0OTc1\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\",\"_COM_SSAID\":\"3NDczZTdmYThiM2IzNzNkNg\\u003d\\u003d\",\"_JSON_DATA\":{\"H_LANG\":\"KO\",\"_REQ_DATA\":{\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\"}},\"_ROOT_CHECK_RESULT\":\"N\",\"_ROOT_CHECK_RESULT_CODE\":\"0\",\"_SYSTEM_MDI_KDCD\":\"0515\",\"isPhone\":\"N\",\"withyou\":\"WBGTW0136\"}}",
				"{\"HTTP_CC_GUID\":\"20211206134705c0a8755c016870004e\",\"HTTP_CC_SESSION\":\"20211206134705c0a8755c016870004e\",\"SERVER_HOST\":\"wnwib.wooribank.com\",\"SERVER_URL\":\"/wib/brand\",\"REMOTE_ADDR\":\"106.247.226.242\",\"REMOTE_USER\":\"ILOVEPSY07_/1_/42\",\"USER_AGENT\":\"Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G935S Build/R16NW);nma-plf\\u003dADR;SMT_RGS_YN\\u003dY;nma-plf-ver\\u003d26;nma-siteid\\u003dBRAND;nma-uniqueid\\u003dPB_A_W_B_001;nma-model\\u003dSM-G935S;push-id\\u003de9YlXKouFQM:APA91bGM7T2n3gnZzOe3QkVuxiXjKGrs5UYk6VPwzq0UmfYUkgFyMFByR0zC4emugZ874OtVvpt8KMkDcVPWmodtKvocMi-27F1Kio5edBzQk-y-2sy6hD6sCdWWCRBP7XK7Y4gvtpPc;nma-app-ver\\u003d3.4.9\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140431765\",\"HTTP_QUERY\":{\"DEVICE_ID_GROUP\":\"eyJJU19FTkMiOiJZIiwiREVWSUNFX0lEIjoiTXpVMU5qUTNNRGN3T0RBME9UYzEiLCJHT09HTEVfQURfSUQiOiJNVE16TUdZNVltRXRaamN5T1MwMFpXTmxMV0k1TXpNdE1UYzBaamRoTjJVeU5XWXkiLCJBTkRST0lEX0lEIjoiTkRjelpUZG1ZVGhpTTJJek56TmtOZz09In0\\u003d\",\"_COM_SMT_UNIQUEID\":\"1MzU1NjQ3MDcwODA0OTc1\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\",\"_COM_SSAID\":\"3NDczZTdmYThiM2IzNzNkNg\\u003d\\u003d\",\"_JSON_DATA\":{\"H_LANG\":\"KO\",\"_REQ_DATA\":{\"USER_ID\":\"ILOVEPSY07\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\"}},\"_ROOT_CHECK_RESULT\":\"N\",\"_ROOT_CHECK_RESULT_CODE\":\"0\",\"_SYSTEM_MDI_KDCD\":\"0515\",\"isPhone\":\"N\",\"withyou\":\"WBLON0021\"}}",
				"{\"HTTP_CC_GUID\":\"20211110200923c0a8755c01f210002d\",\"HTTP_CC_SESSION\":\"20211206125411c0a8755c018280025a\",\"SERVER_HOST\":\"wnm.wooribank.com\",\"SERVER_URL\":\"/mw/jcc\",\"REMOTE_ADDR\":\"192.168.115.93\",\"REMOTE_USER\":\"\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnm.wooribank.com/mw/mws?withyou\\u003dMWMBW0054\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140323169\",\"HTTP_QUERY\":\"\"}"
			};
		
			Gson gs = new Gson();
		
			String src = gs.toJson(jsonStr[0]);
			JsonElement jel = gs.fromJson(src, JsonElement.class);		

			JsonObject jobj = parseLine(jel.getAsString());			
			
			System.out.println(jobj.toString());
			
			System.out.println(KeyParseUtil.parseKeyValues(jobj.get("HTTP_QUERY").toString()));
			
//			System.out.println(KeyParseUtil.parseKeyValues(jobj.getAsString()));

			
			
		
//		ForkJoinPool fjpool = new ForkJoinPool(3); 
//		
//		try {
//			fjpool.submit(() -> {
//				
//				IntStream.range(0, 1).parallel().forEach(idx -> {
//					
//					List<String> arrStr = KeyParseUtil.parseKeys(jsonStr[idx]);
//					
//					for(String key : arrStr) {
//						System.out.println(idx + ":" + key);
//					}
//					
//					System.out.println(idx + ": length["+ arrStr.size() +"], " + Thread.currentThread().getName());
//				});
//				
//				
//			}).get();
//		} catch (InterruptedException | ExecutionException e) {
//			e.printStackTrace();
//		}
//		
	}
	
}
