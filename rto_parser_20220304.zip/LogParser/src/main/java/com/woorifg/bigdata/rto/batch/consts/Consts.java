package com.woorifg.bigdata.rto.batch.consts;

public class Consts {

	public static final String DEFAULT_LOG_NAME = "LogParser";
	public static final String SCHEMA = "PUBLIC";
	
}
