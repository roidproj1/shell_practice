package com.woorifg.bigdata.rto.batch.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class UUIDUtil {
	
	public static String getNow() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
	
	public static String getRndKey8() {
		return UUID.randomUUID().toString().subSequence(0, 8).toString();
	}

	public static String getRndKey12() {
		return UUID.randomUUID().toString().subSequence(24, 36).toString();
	}	

}
