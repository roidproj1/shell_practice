package com.woorifg.bigdata.rto.batch.parse_20220210;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.woorifg.bigdata.rto.batch.consts.Consts;

// Step 1. Log to Json
public class LogToHashMap {
	
	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}	

	private static final Logger log = LoggerFactory.getLogger(LogToHashMap.class);
	
	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";	
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";

	
	// Base Parser
	// ((HTTP_QUERY)="(.*)"$)|(([_a-zA-Z]+)="([^"]*)")
	private static final String STEP_BASE = "(HTTP_QUERY=\"(.*)\"\\s*$)|(([_a-zA-Z0-9]+)=\"([^\"]*)\")";

	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";

	
	private static Pattern ptnBase = Pattern.compile(STEP_BASE);
	private static Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);

	// Base Parser
	public static HashMap<String, Object> parseLine(String src) throws Exception {
		return parseStepBase(src);
	}

	// HttpQuery Parser
	private static HashMap<String, Object> parseStepBase(String src) throws Exception {

		HashMap<String, Object> rsltMap = new HashMap<String, Object>();
		Matcher mtch = ptnBase.matcher(src);

		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				if (mtch.group(1) != null) {

					// 1: HTTP_QUERY Case --> 2: not used, 3: parseStepHttpQuery
					Object tmpHttpQry = parseStepHttpQuery(mtch.group(3).toString());
//					log.debug("parseStepBase - HttpQuery : {}", tmpHttpQry==null?null:tmpHttpQry.toString());
					
					if (tmpHttpQry == null) {
						rsltMap.put("HTTP_QUERY", mtch.group(3).toString());
					} else {
						rsltMap.put("HTTP_QUERY", tmpHttpQry);
					}

				} else if (mtch.group(4) != null) {

					// 4: Normal Case --> 5: key, 6: value
					rsltMap.put(mtch.group(5).toString(), mtch.group(6).toString());
				}
			}
		}

		return rsltMap.size() == 0 ? null : rsltMap;
	}

	
	// HttpQuery Parser
	private static Object parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		HashMap<String, Object> rsltMap = new HashMap<String, Object>();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		
		// 성능에 따라서 여기서 제한 처리 및 분기 처리 가능		
		while (mtch.find()) {
			
			// Step 1 --> 0
			if (mtch.group(0) != null) {
				
				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					rsltMap.put("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);

				} else if (mtch.group(3) != null) {
					
					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					rsltMap.put(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);

				} else if (mtch.group(6) != null) { 
					
					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					rsltMap.put(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					
				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value
//					//dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltMap.put(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}
		
		

		return rsltMap.size() == 0 ? null : rsltMap;
	}

	
	public static void main(String[] args) {

		StopWatch swch = new StopWatch("logToJson");
		swch.start("allStep");
		
//		final String SRC_PATH = "/Proj/LogExmples/test";
		final String SRC_PATH = "/Proj/LogExmples/tmp/";
		
		final String TGT_PATH = "/Proj/LogExmples/tmp_out/";


		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{log}")) {
			
			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());				
				srcFiles.add(path.toFile());
			});

			dirStream.close();
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		

		Gson gs = new Gson();
		
		HashMap<String, Object> map = null;
		String rsltMapStr = null;
		
		long idxLn = 0L;

		for (File src : srcFiles) {
			log.debug("src : {}", src.getPath());

			if (src.exists()) {

				idxLn = 0L;

				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + src.getName() + ".json");
					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					String rd_line = null;

					while ((rd_line = br.readLine()) != null) {

						idxLn++;

//						map = gs.toJsonTree(parseLine(rd_line)).getAsJsonObject();
						map = parseLine(rd_line);

						rsltMapStr = gs.toJson(map) + "\n";
						owr.write(rsltMapStr);
					}

					owr.close();
					br.close();

					long oSize = wrFile.length();
					log.debug("tgt file : size -- {}, lines -- {}", oSize, idxLn);

				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());

	}
}
