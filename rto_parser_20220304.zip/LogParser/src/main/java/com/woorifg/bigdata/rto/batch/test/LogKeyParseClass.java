package com.woorifg.bigdata.rto.batch.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class LogKeyParseClass {

	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}
	
	private static final Logger log = LoggerFactory.getLogger(LogKeyParseClass.class);
	
	private static final String IN_CHARSET = "UTF-8";
	private static final String OUT_CHARSET = "UTF-8";

	public static List<String> arrStr = new ArrayList<String>();
	public static StringBuilder sb = new StringBuilder();
	public static int cnt = 0;
	
	public static void main(String[] args) {

		StopWatch swch = new StopWatch("logToJson");
		swch.start("allStep");
		
		final String SRC_PATH = "/Proj/LogExmples/tmp_json/";
		final String TGT_PATH = "/Proj/LogExmples/keys_info/";

		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{json}")) {
			
			dirStream.forEach(path -> {
				srcFiles.add(path.toFile());
			});

			dirStream.close();
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		Gson gs = new Gson();
		JsonObject json = null;
		JsonElement el = null;

		for (File src : srcFiles) {

			// log.debug("src : {}", src.getPath());

			if (src.exists()) {

				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					String rd_line = null;

					while ((rd_line = br.readLine()) != null) {

						el = gs.fromJson(rd_line, JsonElement.class);
						json = el.getAsJsonObject();
						
						getJsonKeys(json, ".", 1);
						
					}

					br.close();

				} catch (Exception e) {
					log.error(e.getMessage());
				}
			}
		}
		
		
		File wrFile = new File(TGT_PATH + "keys_info.info");
		
		try (OutputStreamWriter	owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET)) {
			
			owr.write(sb.toString());
			owr.close();
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());

	}
	
	public static String getJsonKeys(JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!".".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
			
			if (entry.getValue().isJsonObject()) {
				getJsonKeys(entry.getValue().getAsJsonObject(), hd + entry.getKey(), depth++);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && !arrStr.contains(hd + entry.getKey())) {
					sb.append(hd + entry.getKey() + "\n");
					arrStr.add(hd + entry.getKey());
				}
			}
		}
		
		cnt++;
		return sb.toString();

	}
}
