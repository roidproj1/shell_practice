package com.woorifg.bigdata.rto.batch.parse_20220210;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.enums_20220210.EMaster;
import com.woorifg.bigdata.rto.batch.utils.EncryptUtil;
import com.woorifg.bigdata.rto.batch.utils.KeyParseUtil;

public class JsonToTest {
	
	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}	

	private static final Logger log = LoggerFactory.getLogger(JsonToTest.class);

	private static final String IN_CHARSET = "UTF-8";
	private static final String OUT_CHARSET = "UTF-8";

	public static void main(String[] args) {

		StopWatch swch = new StopWatch("JsonToMaster");
		swch.start("allStep");

//		final String SRC_PATH = "/Proj/LogExmples/tst_out";
		final String SRC_PATH = "/Proj/LogExmples/dev_out/";
//		final String SRC_PATH = "/Proj/LogExmples/tmp_out/";
		
		final String TGT_PATH = "/Proj/LogExmples/dev_json/";
//		final String TGT_PATH = "/Proj/LogExmples/tmp_json/";

		// JsonPath Config
		Configuration jsonPathConf = Configuration.builder()
				.mappingProvider(new GsonMappingProvider())
				.jsonProvider(new GsonJsonProvider())
//				.options(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS).build();
				.options(Option.SUPPRESS_EXCEPTIONS).build();		
//				.options(Option.ALWAYS_RETURN_LIST).build();		

		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{json}")) {

			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());
				srcFiles.add(path.toFile());
			});

		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Gson gs = new Gson();

		String rsltJsonStr = null;
		JsonObject jsObj = null;

		long idxLn = 0L;

		for (File src : srcFiles) {
//			log.debug("src : {}", src.getPath());

			if (src.exists()) {

//				idxLn = 0L;

				try (BufferedReader br = new BufferedReader(
						new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + ".parse.json");
//					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					String rd_line = null;

					while ((rd_line = br.readLine()) != null) {

						idxLn++;

						// MasterParser

						// jsonPathKey --> pckgKey convert

						// depth check : dp1 , dp 2 분기, dp 3 분기, dp n 분기

						// 1. parse case 1 : 1 on 1 move MOVE
						// 2. parse case 2 : 1 on 1 with modify MD_
						// 3. parse case 3 : n on 1 JOIN_
						// 4. parse case 4 : 1 on n SPLT_
						// 5. parse case 5 : n on m with specail process SPC_

						jsObj = new JsonObject();
						
//						EnumSet.allOf(EMaster.class).stream().forEach(en -> {
						
						
						
						/*
						 * for(EMaster en : EMaster.values()) {
						 * 
						 * try {
						 * 
						 * jsObj.addProperty(en.name(), JsonToTest.parseData(en,
						 * JsonPath.using(jsonPathConf).parse(rd_line).read("$" +
						 * en.getJsonPathKey())));
						 * 
						 * } catch(Exception e) {
						 * 
						 * // } catch(InvalidKeyException | UnsupportedEncodingException |
						 * NoSuchAlgorithmException // | NoSuchPaddingException |
						 * InvalidAlgorithmParameterException // | IllegalBlockSizeException |
						 * BadPaddingException e) {
						 * 
						 * System.out.println(en.name() + "-->" + rd_line); e.printStackTrace();
						 * 
						 * }
						 * 
						 * }
						 */
						
						// 복잡 parsing은 분리 처리 ?
						
						// 추가건 처리 
						
						// 암호화는 완전 분리하여 이후 처리로 ?
						

//						System.out.println(jsObj);
//						
//						System.out.println("http_cc_guid:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_CC_GUID"));
//						System.out.println("http_cc_session:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_CC_SESSION"));

						try {
							
							List<String> arrKeys = KeyParseUtil.parseJsonPathKeys(rd_line);
							
							if(arrKeys == null) {
								log.error("Parse Error --> {} - {} line : {}", src.getName() , idxLn , rd_line );
								continue;
							}
							
							for(String key : arrKeys) {
								
								EMaster en = EMaster.findJsonKey(key);
								
								if(en == EMaster.NONE) {
									continue;
								}
								
								if(en.getJsonPathKey() != null) {
									jsObj.addProperty(en.name(), JsonToParse.parseData(en, JsonPath.using(jsonPathConf).parse(rd_line).read("$" + en.getJsonPathKey())));
								}

							}

						} catch (Exception e) {
							e.printStackTrace();
						}

						
//						if(jsObj.get("http_referer") != null && !jsObj.get("http_referer").isJsonNull()) {
//							System.out.println(jsObj.get("http_referer").getAsString());
//							jsObj.addProperty("http_referer_dec",EncryptUtil.decrypt(jsObj.get("http_referer").getAsString()));
//						}
						
						rsltJsonStr = gs.toJson(jsObj) + "\n";
						System.out.print(rsltJsonStr);
						
						owr.write(rsltJsonStr);

					}
					owr.close();
					br.close();

					long oSize = wrFile.length();
//					log.debug("tgt file : size -- {}, lines -- {}", oSize, idxLn);

				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		swch.stop();

		System.out.println("sec : " + swch.getTotalTimeSeconds() + " s");

	}

	public static String parseData(EMaster en, JsonElement jsonPathObj) 
			throws InvalidKeyException, UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException  
	{

		String rsltStr = null;
		Gson gs = new Gson();
		
//		Type mapType = new TypeToken<Map<String, String>>() {}.getType();
		
		if(jsonPathObj != null) {
	
			switch (en.getParseMthd()) {
				case SIMPLE_PARSE:
					rsltStr = en.getParsing(jsonPathObj.getAsString());
					break;
				case DUMP:
					rsltStr = gs.toJson(jsonPathObj);
					break;
				case COMPLEX_PARSE:
					rsltStr = cmplxParse(en, jsonPathObj);
					break;
				case MOVE:
				default:
					rsltStr = jsonPathObj.getAsString();
					break;
			}
			
			if(rsltStr != null) {
				switch (en.getEncMthd()) {
				case ENC_BLANK:
					rsltStr = EncryptUtil.encrypt(rsltStr);
					break;
				case ENC:
					if(!"".equals(rsltStr.trim())) {
						rsltStr = EncryptUtil.encrypt(rsltStr);
					} else {
						rsltStr = null;
					}
					break;
				case MASK:
				case FULL_MASK:
					rsltStr = "*****";
					break;					
				default:
					break;
				}			
			}
		
		}
		
		return rsltStr;

	}
	
	
	public static String cmplxParse(EMaster en, JsonElement jsonPathObj) {
		
		String rsltStr = null;
		Gson gs = new Gson();
		
		switch(en) {
		
		// withyou 가공
		// 1. HTTP_QUERY 아래 withyou가 존재할 경우 사용
		// 1.1. HTTP_QUERY 존재 여부 체크
		// 2. 없으면 HTTP_REFERER 에서 추출
		// 3. 없으면 exception
//				1) ?withyou= 케이스
//				 BRLON[0-9]{8}
//				 BRAI[A-Z]{3}[0-9]{4}
//				 SPWI[A-Z]{3}[0-9]{4}
//				 BRUNIV[0-9]{4}
//				 OW0659
//				 SP0022
//				 ['wp','fn','dc','mc','ow','bz','hm','wl','es','cb','cd','ln','pn','nf','ci','fx','wb','mw','cm','ps',
//				  'is','cs','en','wf','ml','cq','ct','ev','st','br','sp','mf','np','bs','yl','ac','po','hb','rp','bp',
//				  'tc','pf','sc','sf']
//				 [a-zA-Z]{5}[0-9]{4}
//				 mwcsc0009 --> MWCSC0009 ( 대문자화 )
//				 
//				------------------------
//				 
//				2) | 케이스
//				 BRLON[0-9]{8}
//				 BRAI[A-Z]{3}[0-9]{4}
//				 SPWI[A-Z]{3}[0-9]{4} 
//				 BRUNIV[0-9]{4}
//				 OW0659
//				 SP0022
//				 ['wp','fn','dc','mc','ow','bz','hm','wl','es','cb','cd','ln','pn','nf','ci','fx','wb','mw','cm','ps',
//				  'is','cs','en','wf','ml','cq','ct','ev','st','br','sp','mf','np','bs','yl','ac','po','hb','rp','bp',
//				  'tc','pf','sc','sf']
//				 [a-zA-Z]{5}[0-9]{4}
//				 mwcsc0009 --> MWCSC0009
//
//				3)  [-_a-zA-Z0-9] 외는 모두 삭제, null 처리
		
		
		// step 가공
//		* withyou가 먼저 파싱 처리 되어야함
//
//		1) withyou=PSBKM0041 --> __STEP = 40 ~ 48
//		2) withyou=PSLO|NPLO|PSBK|SPLO 로 시작 --> __STEP = 30 ~ 39
//		3) __STEP =^([0-9]{1,2}) = 1~29    
//
//		* 전체 1~48 범위 내에 포함되어야 함

		
//		없을 경우, __JSON_DATA._REQ_DATA.__STEP가 존재하는지 체크 

		
		
		
		// * simple parse건
		
		// .HTTP_QUERY.__ID
		// ^[^c] ==> 시작이 c가 아니면 null , c로 시작이면 특수문자 제거하고 반영
		
		
		// .HTTP_QUERY.cc
		// c[0-9]+[:;]로 반복되는 배열 자료 중 |만 제거하고 저장
		
		
		// .HTTP_QUERY.PLM_PDCD
		// ^([P][0-9]{9}) 필터링
		
		
		// .HTTP_QUERY.no
		// [0-9a-zA-Z]{6} 필터링, 
		
		
		// .HTTP_QUERY.m
		// 'e','f','i','p','pubmain','s','10222','10264','30002','10224' 만 걸러냄
		
		
		// .HTTP_QUERY.z
		// [[:punct:]] 제거
		
		
		// .HTTP_QUERY.c
		// [0-9]{4}
		
		
		// .HTTP_QUERY.t
		// [0-9]{1,5}
		
		
		// .HTTP_QUERY.cmd
		// [[:punct:]] 제거
		
		
		// .HTTP_QUERY.qrAdvpeNo
		// [0-9]{8}
		
		
		// .SERVER_HOST
		// ^((sccd|smpib|swib|ssmt|spib|m|svc|sbiz|spot)\.wooribank\.com)
		// 해당하지 않으면 ?
		
		
		
		// 분기
		
		// .REMOTE_USER
		// ^([^_/]*)_/([0-9]*)_/([0-9]*)(_/)?([a-zA-Z]{0,10}) , 3~4개로 분리
		
		
		// .USER_AGENT
//		;.?Android.?(\\d+\\.?)* : Android
//		;.?CPU (.*)?OS.?(\\d+_?)*[^;]* : Ios
//		;.?Android.?(\\d+\\.?)*;.?([^;|\\)]*) : 모델명 ( Android )
//		\\(([^;]*);.?[U|u];.?CPU (.*)?OS.?(\\d+_?)*[^;]* : 모델명 ( Ios )
//		;nma-app-ver=([\\[]?(\\d+\\.?)*) : 앱버젼
//		;push-id=([^;]*)  : 푸쉬 ID
//		;ADID=((([a-z|A-Z|0-9]*)-?){5})  : ADID
//		;IDFA=([^;]*)  : IDFA
		
		
		// * 추가
		
		// server : .SERVER_HOST 앞부분 자르기
		
		
		// json 아래 항목 몇개 추가
		// __ID
		// __STEP : 위의 step 가공에서 처리
		// ACNO
		// BKCD
		
		// HTTP_QUERY.JSON_DATA.REQ_DATA.INQ_ACNO
		// WDR_ACNO
		// WDR_BKCD
		
		
		// * 생성
		
		// http_time 로그발생시간
		// log_aggr_datetime 수집 시간 ? or 데이타 insert 시간 ?
		// 동일 캐시 체크 ? 랜덤키
		
		
		
		default:
			break;
		
		}
		
		rsltStr = gs.toJson(jsonPathObj);
		
		return rsltStr;
	}

}
