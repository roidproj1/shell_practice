package com.woorifg.bigdata.rto.batch.test;

public class TestStr {

	public static void main(String[] args) {
		String[] tst = "aaa,,".split(",", -1);
		
		for(String a : tst) {
			System.out.println("{"+a+"}");
		}
		
	}

}
