package com.woorifg.bigdata.rto.batch.parse_20220210;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class JsonToMaster {
	
	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}	
	
	private static final Logger log = LoggerFactory.getLogger(JsonToMaster.class);

	private static final String IN_CHARSET = "UTF-8";
	private static final String OUT_CHARSET = "UTF-8";
	
	
	public static void main(String[] args) {

		StopWatch swch = new StopWatch("JsonToMaster");
		swch.start("allStep");
		
//		final String SRC_PATH = "/Proj/LogExmples/tst_out";
//		final String SRC_PATH = "/Proj/LogExmples/dev_out/";
		final String SRC_PATH = "/Proj/LogExmples/tmp_out/";
		
//		final String TGT_PATH = "/Proj/LogExmples/dev_json/";
		final String TGT_PATH = "/Proj/LogExmples/tmp_json/";
		
		// JsonPath Config
		Configuration jsonPathConf = Configuration.builder().jsonProvider(new GsonJsonProvider())
				.options(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS).build();
//				.options(Option.ALWAYS_RETURN_LIST).build();		
		
		
		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{json}")) {			

			dirStream.forEach(path -> {
				log.debug("path : {}", path.toString());
				srcFiles.add(path.toFile());
			});

		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Gson gs = new Gson();
		
		JsonObject json = null;
		String rsltJsonStr = null;
		
		long idxLn = 0L;
		

		for (File src : srcFiles) {
			log.debug("src : {}", src.getPath());

			if (src.exists()) {

				idxLn = 0L;

				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + ".mst.json");
					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					String rd_line = null;

					while ((rd_line = br.readLine()) != null) {

						idxLn++;

						// MasterParser
						
						// jsonPathKey --> pckgKey convert
						
						// depth check : dp1 , dp 2 분기, dp 3 분기, dp n 분기
						
						// 1. parse case 1 : 1 on 1 move						MOVE
						// 2. parse case 2 : 1 on 1 with modify					MD_
						// 3. parse case 3 : n on 1 							JOIN_
						// 4. parse case 4 : 1 on n 							SPLT_
						// 5. parse case 5 : n on m with specail process		SPC_
						
						System.out.println("http_cc_guid:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_CC_GUID"));
						System.out.println("http_cc_session:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_CC_SESSION"));
						System.out.println("server_host:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.SERVER_HOST"));
						System.out.println("server_url:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.SERVER_URL"));
						System.out.println("remote_addr:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.REMOTE_ADDR"));
						System.out.println("remote_user:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.REMOTE_USER"));
						System.out.println("user_agent:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.USER_AGENT"));
						System.out.println("http_uri:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_URI"));
						System.out.println("http_referer:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_REFERER"));
						System.out.println("http_cookie:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_COOKIE"));
						System.out.println("http_method:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_METHOD"));
						System.out.println("http_time:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_TIME"));
						System.out.println("http_query:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY"));
						System.out.println("http_query_withyou:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY.withyou"));
						System.out.println("http_query.__ID:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY.__ID"));
						System.out.println("http_query.__STEP:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY.__STEP"));
						System.out.println("http_query._JSON_DATA:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY._JSON_DATA"));						
						System.out.println("HTTP_QUERY._JSON_DATA.H_LANG:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY._JSON_DATA.H_LANG"));	
						System.out.println("HTTP_QUERY._JSON_DATA._REQ_DATA._COM_SMT_UNIQUEID_FDS:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY._JSON_DATA._REQ_DATA._COM_SMT_UNIQUEID_FDS"));	
						System.out.println("HTTP_QUERY.isPhone:"+JsonPath.using(jsonPathConf).parse(rd_line).read("$.HTTP_QUERY.isPhone"));	
						
						
						try {

						} catch (Exception e) {
							e.printStackTrace();
						}

						rsltJsonStr = gs.toJson(json) + "\n";
//						owr.write(rsltJsonStr);
						
					}
					owr.close();
					br.close();

					long oSize = wrFile.length();
					log.debug("tgt file : size -- {}, lines -- {}", oSize, idxLn);
					
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		swch.stop();

		System.out.println("sec : " + swch.getTotalTimeSeconds() + " s");

	}

}
