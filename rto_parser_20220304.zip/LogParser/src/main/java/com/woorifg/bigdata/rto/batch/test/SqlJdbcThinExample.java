/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.woorifg.bigdata.rto.batch.test;

import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.ClientCache;
import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;

import com.google.gson.Gson;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.UUIDUtil;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;
import com.woorifg.bigdata.rto.batch.vos.TestVoKey;


public class SqlJdbcThinExample {

	/** schema name. **/
	private static final String SCHEMA = "PUBLIC";

	public static void main(String[] args) throws Exception {

		ClientConfiguration cfg = new ClientConfiguration()
				.setAddresses("10.214.121.67:10800", "10.214.121.68:10800",	"10.214.121.69:10800")
//				.setUserName("ignite")
//				.setUserPassword("ignite")
				;
		
		try (IgniteClient ignite = Ignition.startClient(cfg)) {

			print("Cache query DDL example started.");
			
//			ClientCache<TestVoKey, TestVo> cache = ignite.getOrCreateCache("LOG_ORG_1").withKeepBinary();
//			ClientCache<TestVoKey, TestVo> cache = ignite.cache("LOG_ORG");
			ClientCache<?, ?> cache = ignite.cache("LOG_ORG");
			
			String jsonStr = "{\"HTTP_CC_GUID\":\"20200730130438c0a8755c0187b0015c\",\"HTTP_CC_SESSION\":\"20211024185237c0a8755c015470008c\",\"SERVER_HOST\":\"wnbiz.wooribank.com\",\"SERVER_URL\":\"/biz/Dream\",\"REMOTE_ADDR\":\"1.232.5.3\",\"REMOTE_USER\":\"TESTFXD002_/2_/51\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnbiz.wooribank.com/biz/Dream?withyou=BZFXD0343\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"GET\",\"HTTP_TIME\":\"20211025010206406\",\"HTTP_QUERY\":\"B808F33356D2630466CFB5EB77874EA3CC3195977A2EB231D81DF0A54E128F52\",\"rnd_key\":\"6e30cf77\",\"log_aggr_datetime\":\"20220211144913255\"}";
			
			Gson gs = new Gson();
			
			TestVoKey vok = gs.fromJson(jsonStr, TestVoKey.class);
			LogOrgDto vo = gs.fromJson(jsonStr, LogOrgDto.class);
			
			vok.setRnd_key(UUIDUtil.getRndKey8());
			vok.setLog_aggr_datetime(UUIDUtil.getNow());
			
			vo.setRnd_key(vok.getRnd_key());
			vo.setLog_aggr_datetime(vok.getLog_aggr_datetime());
			
			
//			cache.containsKey(vok);
			
			
			String jsonVok = gs.toJson(vok);
			String jsonVo = gs.toJson(vo);
			
			System.out.println(jsonVok);
			System.out.println(jsonVo);
			
			ResultVo rs = IMDGUtil.makeInsertQryFromVo(jsonVo, "LOG_ORG");

			
			
			
			// Create reference City table based on REPLICATED template.
//			cache.query(new SqlFieldsQuery(
//					"CREATE TABLE city (id LONG PRIMARY KEY, name VARCHAR) WITH \"template=replicated\"")
//			).getAll();
			
			// Create table based on PARTITIONED template with one backup.
//			cache.query(new SqlFieldsQuery(
//					"CREATE TABLE person (id LONG, name VARCHAR, city_id LONG, PRIMARY KEY (id, city_id)) "
//							+ "WITH \"backups=1, affinity_key=city_id\"")
//			).getAll();

			// Create an index.
//			cache.query(new SqlFieldsQuery("CREATE INDEX on Person (city_id)")).getAll();
//			print("Created database objects.");

			
			SqlFieldsQuery qry = new SqlFieldsQuery(rs.getQuery());
			
			System.out.println(rs.getQuery());
			
			cache.query(qry.setArgs(rs.getArgs().toArray())).getAll();
			
//			cache.query(qry.setArgs(idx++, "Forest Hill")).getAll();
//			cache.query(qry.setArgs(idx++, "Denver")).getAll();
//			cache.query(qry.setArgs(idx++, "St. Petersburg")).getAll();
//			
//			
//			idx = 1L;
//
//			qry = new SqlFieldsQuery("INSERT INTO person (id, name, city_id) values (?, ?, ?)");
//
//			cache.query(qry.setArgs(idx++, "John Doe", 3L)).getAll();
//			cache.query(qry.setArgs(idx++, "Jane Roe", 2L)).getAll();
//			cache.query(qry.setArgs(idx++, "Mary Major", 1L)).getAll();
//			cache.query(qry.setArgs(idx++, "Richard Miles", 2L)).getAll();
//
//			print("Populated data.");
//
//			
//			FieldsQueryCursor<List<?>> cursor = cache.query(
//					new SqlFieldsQuery("SELECT p.name, c.name FROM Person p INNER JOIN City c on c.id = p.city_id")
//			);
			
			
//			List<List<?>> res = cache.query(
//					new SqlFieldsQuery("SELECT p.name, c.name FROM Person p INNER JOIN City c on c.id = p.city_id")
//			).getAll();
			
			
//			print("Query results:");
//
//			
//			for (Object next : cursor)
//				System.out.println(">>>    " + next);

			
//          cache.query(new SqlFieldsQuery("drop table Person")).getAll();
//          cache.query(new SqlFieldsQuery("drop table City")).getAll();

		} catch (ClientConnectionException ex) {
			ex.printStackTrace();
		}

		print("Cache query Thin example finished.");

	}

	/**
	 * Prints message.
	 *
	 * @param msg Message to print before all objects are printed.
	 */
	private static void print(String msg) {
		System.out.println();
		System.out.println(">>> " + msg);
	}
}
