package com.woorifg.bigdata.rto.batch.test;

public class ImdgToFile {

}
