package com.woorifg.bigdata.rto.batch.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.woorifg.bigdata.rto.batch.consts.Consts;

public class PropertiesUtil {

	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}
	
	private static final Logger log = LoggerFactory.getLogger(PropertiesUtil.class);

	private static String configDefault = "default.properties";
	
	private static final String CHARSET = "UTF-8";

	public static Properties getProperty() {
		return getProperty(configDefault);
	}

	private static String getFilePath(String propertyPath) {

		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		
		if (cl == null)
			cl = ClassLoader.getSystemClassLoader();
		
		return cl.getResource(propertyPath).getFile();
	}

	public static Properties getProperty(String propertyPath) {

		Properties prop = new Properties();
		InputStream inputStream = null;
		InputStreamReader inputStreamReader = null;

		try {
			
			inputStream = new FileInputStream(getFilePath(propertyPath));
			inputStreamReader = new InputStreamReader(inputStream, Charset.forName(CHARSET));
			prop.load(inputStreamReader);

		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (inputStreamReader != null) {
				try {
					inputStreamReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return prop;
	}

	public static void main(String[] args) {

		Properties property = getProperty("master_key.info");
	 
		System.out.println(property.getProperty("if_hdp.ip"));
		
		System.out.println(
				property
		);
 
		for(String key : property.stringPropertyNames()) {
		     String value = property.getProperty(key);
		     System.out.println(key + " => " + value);
		}
 
		
	}

}