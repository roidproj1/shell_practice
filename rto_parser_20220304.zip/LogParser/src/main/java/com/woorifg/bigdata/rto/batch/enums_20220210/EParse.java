package com.woorifg.bigdata.rto.batch.enums_20220210;

public enum EParse {
	NONE,
	NEW,		// 신규 추가 항목 
	MOVE,		// 단순 Data 이동, 이스케이핑 처리 안함. 오브젝트 단위 저장
	DUMP,		// 오브젝트도 json 스트링화 하여 이스케이핑 처리하여 저장
	SIMPLE_PARSE,	
	COMPLEX_PARSE,
	;
}
