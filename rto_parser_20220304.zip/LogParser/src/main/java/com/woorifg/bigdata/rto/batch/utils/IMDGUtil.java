package com.woorifg.bigdata.rto.batch.utils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;
import com.woorifg.bigdata.rto.batch.vos.TestVoKey;

public class IMDGUtil {


	public static String makeSelectQryFromStrArr(String[] keys, String tblNm) {

		final String QRY_SEL_HD_1 = "SELECT ";
		final String QRY_SEL_TL_1 = " FROM "; 
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		
		qryKey.setLength(0);
		
		for(String key : keys) {
			
			if(qryKey.length() != 0) {
				qryKey.append(", ");	
			}
			
			qryKey.append(key);
		}
		
//		System.out.println(qryKey);
		
		rsltQry.append(QRY_SEL_HD_1)
			.append(qryKey.toString())
			.append(QRY_SEL_TL_1)
			.append(tblNm)
		;
		
		return rsltQry.toString();

	}
	
	
//	INSERT INTO PUBLIC.LOG_ORG
//	(HTTP_CC_GUID, HTTP_CC_SESSION, HTTP_TIME, HOST_NAME, LOG_AGGR_DATETIME, RND_KEY, HTTP_COOKIE, HTTP_METHOD, HTTP_REFERER, HTTP_URI, REMOTE_ADDR, REMOTE_USER, SERVER_HOST, SERVER_URL, USER_AGENT, HTTP_QUERY)
//	VALUES('20200730130438c0a8755c0187b0015c', '20211024185237c0a8755c015470008c', '20211025010206406', 'default', '20220211165059619', 'f96c1deb', '', 'GET', 'https://wnbiz.wooribank.com/biz/Dream?withyou=BZFXD0343', ' ', '1.232.5.3', 'TESTFXD002_/2_/51', 'wnbiz.wooribank.com', '/biz/Dream', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36', 'B808F33356D2630466CFB5EB77874EA3CC3195977A2EB231D81DF0A54E128F52');

	public static ResultVo makeInsertQryFromVo(String jsonVo, String tblNm) {

		ResultVo rslt = new ResultVo();  
		
		final String QRY_INS_HD_1 = "INSERT INTO ";
		final String QRY_INS_HD_2 = " ( "; 
		final String QRY_INS_MD_1 = " ) VALUES ( "; 
		final String QRY_INS_TL_1 = " )";
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		StringBuilder qryValue = new StringBuilder();
		
		Gson gs = new Gson();
		
		Type voMapType = new TypeToken<TreeMap<String, String>>(){
			private static final long serialVersionUID = 1L;
		}.getType();
		
		TreeMap<String, String> mp = gs.fromJson(jsonVo, voMapType);
		
		
		qryKey.setLength(0);
		List<String> tmpArg = new ArrayList<String>(); 
		
		for(String key : mp.keySet()) {
			
			if(qryKey.length()!=0) {
				qryKey.append(", ");	
				qryValue.append(", ");
			}
			
			qryKey.append(key);
			qryValue.append("?");
			
			tmpArg.add(mp.get(key));
			
		}
		
//		System.out.println(qryKey);
		
		rsltQry.append(QRY_INS_HD_1)
			.append(tblNm)
			.append(QRY_INS_HD_2)
			.append(qryKey.toString())
			.append(QRY_INS_MD_1)
			.append(qryValue.toString())
			.append(QRY_INS_TL_1)
		;	
		
		rslt.setArgs(tmpArg);
		rslt.setQuery(rsltQry.toString());
		
		return rslt;

	}
	
	public static ResultVo makeInsertQryFromVo(String jsonVo, String schemaNm, String tblNm) {

		ResultVo rslt = new ResultVo();  
		
		final String QRY_INS_HD_1 = "INSERT INTO ";
		final String QRY_INS_HD_2 = " ( "; 
		final String QRY_INS_MD_1 = " ) VALUES ( "; 
		final String QRY_INS_TL_1 = " )";
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		StringBuilder qryValue = new StringBuilder();
		
		Gson gs = new Gson();
		
		Type voMapType = new TypeToken<TreeMap<String, String>>(){
			private static final long serialVersionUID = 1L;
		}.getType();
		
		TreeMap<String, String> mp = gs.fromJson(jsonVo, voMapType);
		
		
		qryKey.setLength(0);
		List<String> tmpArg = new ArrayList<String>(); 
		
		for(String key : mp.keySet()) {
			
			if(qryKey.length()!=0) {
				qryKey.append(", ");	
				qryValue.append(", ");
			}
			
			qryKey.append(key);
			qryValue.append("?");
			
			tmpArg.add(mp.get(key));
			
		}
		
//		System.out.println(qryKey);
		
		rsltQry.append(QRY_INS_HD_1)
			.append(schemaNm)
			.append(".")
			.append(tblNm)
			.append(QRY_INS_HD_2)
			.append(qryKey.toString())
			.append(QRY_INS_MD_1)
			.append(qryValue.toString())
			.append(QRY_INS_TL_1)
		;	
		
		rslt.setArgs(tmpArg);
		rslt.setQuery(rsltQry.toString());
		
		return rslt;

	}	
	
	public static void main(String[] args) {

//		String[] jsonStr = {
//				"{\"HTTP_CC_GUID\":\"20211206134705c0a8755c016870004e\",\"HTTP_CC_SESSION\":\"20211206134705c0a8755c016870004e\",\"SERVER_HOST\":\"wnwib.wooribank.com\",\"SERVER_URL\":\"/wib/brand\",\"REMOTE_ADDR\":\"106.247.226.242\",\"REMOTE_USER\":\"ILOVEPSY07_/1_/42\",\"USER_AGENT\":\"Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G935S Build/R16NW);nma-plf\\u003dADR;SMT_RGS_YN\\u003dY;nma-plf-ver\\u003d26;nma-siteid\\u003dBRAND;nma-uniqueid\\u003dPB_A_W_B_001;nma-model\\u003dSM-G935S;push-id\\u003de9YlXKouFQM:APA91bGM7T2n3gnZzOe3QkVuxiXjKGrs5UYk6VPwzq0UmfYUkgFyMFByR0zC4emugZ874OtVvpt8KMkDcVPWmodtKvocMi-27F1Kio5edBzQk-y-2sy6hD6sCdWWCRBP7XK7Y4gvtpPc;nma-app-ver\\u003d3.4.9\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140404203\",\"HTTP_QUERY\":{\"DEVICE_ID_GROUP\":\"eyJJU19FTkMiOiJZIiwiREVWSUNFX0lEIjoiTXpVMU5qUTNNRGN3T0RBME9UYzEiLCJHT09HTEVfQURfSUQiOiJNVE16TUdZNVltRXRaamN5T1MwMFpXTmxMV0k1TXpNdE1UYzBaamRoTjJVeU5XWXkiLCJBTkRST0lEX0lEIjoiTkRjelpUZG1ZVGhpTTJJek56TmtOZz09In0\\u003d\",\"_COM_SMT_UNIQUEID\":\"1MzU1NjQ3MDcwODA0OTc1\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\",\"_COM_SSAID\":\"3NDczZTdmYThiM2IzNzNkNg\\u003d\\u003d\",\"_JSON_DATA\":{\"H_LANG\":\"KO\",\"_REQ_DATA\":{\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\"}},\"_ROOT_CHECK_RESULT\":\"N\",\"_ROOT_CHECK_RESULT_CODE\":\"0\",\"_SYSTEM_MDI_KDCD\":\"0515\",\"isPhone\":\"N\",\"withyou\":\"WBGTW0136\"}}",
//				"{\"HTTP_CC_GUID\":\"20211206134705c0a8755c016870004e\",\"HTTP_CC_SESSION\":\"20211206134705c0a8755c016870004e\",\"SERVER_HOST\":\"wnwib.wooribank.com\",\"SERVER_URL\":\"/wib/brand\",\"REMOTE_ADDR\":\"106.247.226.242\",\"REMOTE_USER\":\"ILOVEPSY07_/1_/42\",\"USER_AGENT\":\"Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G935S Build/R16NW);nma-plf\\u003dADR;SMT_RGS_YN\\u003dY;nma-plf-ver\\u003d26;nma-siteid\\u003dBRAND;nma-uniqueid\\u003dPB_A_W_B_001;nma-model\\u003dSM-G935S;push-id\\u003de9YlXKouFQM:APA91bGM7T2n3gnZzOe3QkVuxiXjKGrs5UYk6VPwzq0UmfYUkgFyMFByR0zC4emugZ874OtVvpt8KMkDcVPWmodtKvocMi-27F1Kio5edBzQk-y-2sy6hD6sCdWWCRBP7XK7Y4gvtpPc;nma-app-ver\\u003d3.4.9\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140431765\",\"HTTP_QUERY\":{\"DEVICE_ID_GROUP\":\"eyJJU19FTkMiOiJZIiwiREVWSUNFX0lEIjoiTXpVMU5qUTNNRGN3T0RBME9UYzEiLCJHT09HTEVfQURfSUQiOiJNVE16TUdZNVltRXRaamN5T1MwMFpXTmxMV0k1TXpNdE1UYzBaamRoTjJVeU5XWXkiLCJBTkRST0lEX0lEIjoiTkRjelpUZG1ZVGhpTTJJek56TmtOZz09In0\\u003d\",\"_COM_SMT_UNIQUEID\":\"1MzU1NjQ3MDcwODA0OTc1\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\",\"_COM_SSAID\":\"3NDczZTdmYThiM2IzNzNkNg\\u003d\\u003d\",\"_JSON_DATA\":{\"H_LANG\":\"KO\",\"_REQ_DATA\":{\"USER_ID\":\"ILOVEPSY07\",\"_COM_SMT_UNIQUEID_FDS\":\"||/wE6upuxAUAA0ZQgekLgnq2eyMiFzg1swkHEGYH51dXKLZPjoGPjO/SasQpNU/5XcvQz2JMk9bqyFYalzYovln0kPEOnx15 7Qk7Whhrm28dj8w4xLmdTx6bqGeXIZL0rAjbHBjHkqID8uTNXwPMVA7co2c L0wDZoRy8ga1QT2EJ6EkZp99vC7OjpB6rBVb8QTMmYpJtvFSzMC46ALeYzYqUuMIHGyBjMsY0UQ7ddrdYJ7ycoRVjn0Xj/GJh9yXWzdsEfZVLO/EdCgv2RYU0k2LakL318 YEcfrso6wZ2mimjNSzXL1tBtGg2 CmDul7jcZjW x08bYL6i2kqM8ZcjNWqjdKD9qKd2dW1xDf on0aJPwWaRl3/vCQ1d9dBDIpxFIy2wee ZPQbZwNvoNWNj97sUa7o9lgzNDUTfArBCmGoEcBhDzfg\\u003d\"}},\"_ROOT_CHECK_RESULT\":\"N\",\"_ROOT_CHECK_RESULT_CODE\":\"0\",\"_SYSTEM_MDI_KDCD\":\"0515\",\"isPhone\":\"N\",\"withyou\":\"WBLON0021\"}}",
//				"{\"HTTP_CC_GUID\":\"20211110200923c0a8755c01f210002d\",\"HTTP_CC_SESSION\":\"20211206125411c0a8755c018280025a\",\"SERVER_HOST\":\"wnm.wooribank.com\",\"SERVER_URL\":\"/mw/jcc\",\"REMOTE_ADDR\":\"192.168.115.93\",\"REMOTE_USER\":\"\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnm.wooribank.com/mw/mws?withyou\\u003dMWMBW0054\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"POST\",\"HTTP_TIME\":\"20211206140323169\",\"HTTP_QUERY\":\"\"}"
//			};
		
		String jsonStr = "{\"HTTP_CC_GUID\":\"20200730130438c0a8755c0187b0015c\",\"HTTP_CC_SESSION\":\"20211024185237c0a8755c015470008c\",\"SERVER_HOST\":\"wnbiz.wooribank.com\",\"SERVER_URL\":\"/biz/Dream\",\"REMOTE_ADDR\":\"1.232.5.3\",\"REMOTE_USER\":\"TESTFXD002_/2_/51\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnbiz.wooribank.com/biz/Dream?withyou=BZFXD0343\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"GET\",\"HTTP_TIME\":\"20211025010206406\",\"HTTP_QUERY\":\"B808F33356D2630466CFB5EB77874EA3CC3195977A2EB231D81DF0A54E128F52\",\"rnd_key\":\"6e30cf77\",\"log_aggr_datetime\":\"20220211144913255\"}";
		
		Gson gs = new Gson();
		
		TestVoKey vok = gs.fromJson(jsonStr, TestVoKey.class);
		LogOrgDto vo = gs.fromJson(jsonStr, LogOrgDto.class);
		
		vok.setRnd_key(UUIDUtil.getRndKey8());
		vok.setLog_aggr_datetime(UUIDUtil.getNow());
		
		vo.setRnd_key(vok.getRnd_key());
		vo.setLog_aggr_datetime(vok.getLog_aggr_datetime());
		
		
//		cache.containsKey(vok);
		
		
		String jsonVok = gs.toJson(vok);
		String jsonVo = gs.toJson(vo);
		
//		System.out.println(jsonVok);
//		System.out.println(jsonVo);	
		
		
		ResultVo rs = makeInsertQryFromVo(jsonVo, "PUBLIC.LOG_ORG");
		
		System.out.println(rs.getQuery());
		
		System.out.println(rs.getArgs());

	}



}
