package com.woorifg.bigdata.rto.batch.parse_20220210;

public class DetectCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
