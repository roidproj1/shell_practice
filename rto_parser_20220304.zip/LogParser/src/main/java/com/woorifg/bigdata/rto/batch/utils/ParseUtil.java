package com.woorifg.bigdata.rto.batch.utils;

public class ParseUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
