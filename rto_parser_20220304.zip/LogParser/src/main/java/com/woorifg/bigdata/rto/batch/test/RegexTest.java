package com.woorifg.bigdata.rto.batch.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;

public class RegexTest {

	public static void main(String[] args) {
		String src = "20220127133045123";
//		String sPtn = "(^[0-9]{8})";
		String sPtn = "[0-9]{8}([0-9]{9})"; 
		
		Pattern ptn = Pattern.compile(sPtn);
		Matcher mtch = ptn.matcher(src);
		
		while(mtch.find() && mtch.groupCount() != 0) {
			System.out.println(mtch.group(1));
		}
		
		
		Gson gs = new Gson();
		
//		ENT0180In tmp = gs.fromJson(json, ENT0180In.class);

	}

}
