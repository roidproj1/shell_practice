package com.woorifg.bigdata.rto.batch.vos;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestVoKey implements Serializable {

	private static final long serialVersionUID = 1L;

	@SerializedName(value="http_cc_guid", alternate="HTTP_CC_GUID")
	private String http_cc_guid;
	
	@SerializedName(value="http_cc_session", alternate="HTTP_CC_SESSION")
	String http_cc_session;
	
	@SerializedName(value="http_time", alternate="HTTP_TIME")
	String http_time;
	
	@SerializedName(value="host_name", alternate="HOST_NAME")
	String host_name = "default";
	
	String log_aggr_datetime;
	String rnd_key;
	
}
