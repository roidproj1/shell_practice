package com.woorifg.bigdata.rto.batch.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class TestJsonKeyContains {

	public static void main(String[] args) {

		ArrayList<String> srchKeyArr = new ArrayList<String>();

		try (BufferedReader br = new BufferedReader(new FileReader("master_key.info"))) {

			String sLine = br.readLine();

			while (sLine != null) {

				srchKeyArr.add(sLine);

				sLine = br.readLine();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		for (String key : srchKeyArr) {
			System.out.println(key + ",");
		}

	}

}
