package com.woorifg.bigdata.rto.batch.parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.ClientCache;
import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.ClientException;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.eBrother.nibbler.parser.ParserHelper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.utils.DamoEncUtil;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.UUIDUtil;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;

// Step 1. Log to Json
public class Temp001MainLogToJson {
	
	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(Temp001MainLogToJson.class);
	
	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";	
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";

	private static final String VALID_CHECK = "^\\s*HTTP_CC_GUID=.*HTTP_QUERY=\".*\"\\s*$";
//	private static final String VALID_CHECK = "^\\s*HOST_NAME=.*HTTP_QUERY=\".*\"\\s*$";	
	private static Pattern ptnValid = Pattern.compile(VALID_CHECK);
	
	// Base Parser
	// (HTTP_QUERY="(.*)"\s*$)|(([_a-zA-Z]+)="([^"]*)")
	// (HTTP_QUERY="(.*)"\s*$)|(([_a-zA-Z]+)="([^"]*)")|(^HOST_NAME=([0-9\.]*))
	private static final String STEP_BASE = "(HTTP_QUERY=\"(.*)\"\\s*$)|(([_a-zA-Z0-9]+)=\"([^\"]*)\")";
//	private static final String STEP_BASE = "(HTTP_QUERY=\"(.*)\"\\s*$)|(([_a-zA-Z0-9]+)=\"([^\"]*)\")|(^HOST_NAME=([0-9\\.]*))";	
	
	private static Pattern ptnBase = Pattern.compile(STEP_BASE);
	
	// Base Parser
	public JsonObject parseLine(String src) throws Exception {
		return parseStepBase(src);
	}

	// HttpQuery Parser
	private JsonObject parseStepBase(String src) throws Exception {

		JsonObject rsltJson = new JsonObject();
		Matcher mtch = ptnBase.matcher(src);

		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				if (mtch.group(1) != null) {
					
					rsltJson.addProperty("HTTP_QUERY", mtch.group(2).toString());
					
				} else if (mtch.group(3) != null) {
					// 3: Normal Case --> 4: key, 5: value
					rsltJson.addProperty(mtch.group(4).toString(), mtch.group(5).toString());
					
//				} else if (mtch.group(6) != null) {
					// 6: HOST_NAME --> 7 : value
//					rsltJson.addProperty("HOST_NAME", mtch.group(7).toString());
				}
				
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}
	
	
	private List<File> getFileListFromDir(final String SRC_PATH, final String ext) {
		
		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), ext)) {
			
			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());
				srcFiles.add(path.toFile());
			});

			dirStream.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return srcFiles;
	}
	
	
	private void printParseErr(String fileNm, Long idxLn, String src ) {
		log.info("Parse Err : {} -- {} line : {}", fileNm, idxLn, src);
	}
	
	private String getNow() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
	
	
	public void fileToFile(final String SRC_PATH, final String TGT_PATH, boolean enc) {

		StopWatch swch = new StopWatch("Step001MainLogToJson");
		swch.start("fileToFile");
		
		List<File> srcFiles = getFileListFromDir(SRC_PATH, "*.{log}");
		
//		Gson gs = new Gson();
		
		JsonObject json = null;
		String rsltJsonStr = null;
		Matcher mtch = null;
		
		long idxLn = 0L;

		for (File src : srcFiles) {
			
//			log.debug("src : {}", src.getPath());

			if (src.exists()) {

				idxLn = 0L;
				
				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + src.getName() + ".json");
//					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					String rd_line = null;
					String encStr = null;
					
					while ((rd_line = br.readLine()) != null
//						&& idxLn < 1000
					) {

						idxLn++;

//						System.out.println(rd_line);
						
						try {
							
							mtch = ptnValid.matcher(rd_line);
							
							if(mtch.find()) {
								json = parseLine(rd_line);
							} else {
								printParseErr(src.getName(), idxLn, rd_line);
								continue;								
							}
							
						} catch(Exception e) {
							
							printParseErr(src.getName(), idxLn, rd_line);
							continue;
						}

						if(json == null) {
							
							printParseErr(src.getName(), idxLn, rd_line);
							continue;
							
						} else {
							
							if( json.get("HTTP_QUERY") != null 
									&& !json.get("HTTP_QUERY").getAsString().trim().isEmpty() 
									&& !"null".equals(json.get("HTTP_QUERY").getAsString().trim())
							) {
															
								if(enc) {
									encStr = DamoEncUtil.data_encryption(json.get("HTTP_QUERY").getAsString(), "string");
									
									json.addProperty("HTTP_QUERY", encStr);
								}
								
							} else {
								
								// 공백 또는 null일 경우 null로 치환
								json.add("HTTP_QUERY", null);
								
							}
							
							json.addProperty("rnd_key", UUIDUtil.getRndKey8());
							json.addProperty("log_aggr_datetime", UUIDUtil.getNow());
							
//							log.debug(json.toString());
							
							rsltJsonStr = json.toString() + "\n";
//							rsltJsonStr = gs.toJson(json) + "\n";
//							log.debug(rsltJsonStr);
							
							owr.write(rsltJsonStr);
						}
					}

					owr.close();
					br.close();

				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					log.info("{}", src.getName());
					e.printStackTrace();
				}
			}
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());		
	}
	
	
	public void fileToImdgJdbc(final String SRC_PATH, final String TGT_TBL, boolean enc) {

		StopWatch swch = new StopWatch("Step001MainLogToJson");
		swch.start("fileToImdg");
		
		List<File> srcFiles = getFileListFromDir(SRC_PATH, "*.{log}");
		
		
		ClientConfiguration cfg = new ClientConfiguration()
				.setAddresses("10.214.121.67:10800", "10.214.121.68:10800",	"10.214.121.69:10800")
//				.setUserName("ignite")
//				.setUserPassword("ignite")
				;
		
		try (IgniteClient ignite = Ignition.startClient(cfg)) {
			
			ClientCache<?, ?> cache = ignite.cache(TGT_TBL);
			Gson gs = new Gson();
			
			JsonObject json = null;
//			String rsltJsonStr = null;
			Matcher mtch = null;
			
			long idxLn = 0L;
	
			for (File src : srcFiles) {
				
//				log.debug("src : {}", src.getPath());
	
				if (src.exists()) {
	
					idxLn = 0L;
					
					try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

//						log.debug("tgt : {}", wrFile.getPath());
	
						String rd_line = null;
						String encStr = null;
						
						while ((rd_line = br.readLine()) != null) {
	
							idxLn++;
	
//							System.out.println(rd_line);
							try {
								
								mtch = ptnValid.matcher(rd_line);
								
								if(mtch.find()) {
									json = parseLine(rd_line);
								} else {
									printParseErr(src.getName(), idxLn, rd_line);
									continue;								
								}
								
							} catch(Exception e) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
							}
	
							if(json == null) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
								
							} else {
								
								if(json.get("HTTP_QUERY") != null 
										&& !json.get("HTTP_QUERY").getAsString().trim().isEmpty()
										&& !"null".equals(json.get("HTTP_QUERY").getAsString().trim())
								)
								{
									if(enc) {
										encStr = DamoEncUtil.data_encryption(json.get("HTTP_QUERY").getAsString(), "string");
										
										json.addProperty("HTTP_QUERY", encStr);									
									}
									
								} else {
									
									// 공백 또는 null일 경우 null로 치환
									json.add("HTTP_QUERY", null);
									
								}
								
								json.addProperty("rnd_key", UUIDUtil.getRndKey8());
								json.addProperty("log_aggr_datetime", getNow());
								
//								log.debug(json.toString());
								
								LogOrgDto vo = gs.fromJson(json, LogOrgDto.class);
								String jsonVo = gs.toJson(vo);
								
								ResultVo rs = IMDGUtil.makeInsertQryFromVo(jsonVo, TGT_TBL);
								SqlFieldsQuery qry = new SqlFieldsQuery(rs.getQuery());
								
//								System.out.println(rs.getQuery());
								
								cache.query(qry.setArgs(rs.getArgs().toArray())).getAll();								
								
//								rsltJsonStr = json.toString() + "\n";
//								rsltJsonStr = gs.toJson(json) + "\n";
//								log.debug(rsltJsonStr);
								
								// insert
							}
						}
	
						br.close();
	
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (Exception e) {
						log.info("{}", src.getName());
						e.printStackTrace();
					}
				}
			}
			
		} catch(ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());		
	}	
	

	public void fileToImdgThin(final String SRC_PATH, final String TGT_TBL, boolean enc) {

		StopWatch swch = new StopWatch("Step001MainLogToJson");
		swch.start("fileToImdg");
		
		List<File> srcFiles = getFileListFromDir(SRC_PATH, "*.{log}");
		
		
		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
			
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("SET STREAMING ON");
            }
			
			Gson gs = new Gson();
			
			JsonObject json = null;
//			String rsltJsonStr = null;
			Matcher mtch = null;
			
			long idxLn = 0L;
	
			for (File src : srcFiles) {
				
//				log.debug("src : {}", src.getPath());
	
				if (src.exists()) {
	
					idxLn = 0L;
					
					try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

//						log.debug("tgt : {}", wrFile.getPath());
	
						String rd_line = null;
						String encStr = null;
						
						while ((rd_line = br.readLine()) != null) {
	
							idxLn++;
	
//							System.out.println(rd_line);
							try {
								
								mtch = ptnValid.matcher(rd_line);
								
								if(mtch.find()) {
									json = parseLine(rd_line);
								} else {
									printParseErr(src.getName(), idxLn, rd_line);
									continue;								
								}
								
							} catch(Exception e) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
							}
	
							if(json == null) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
								
							} else {
								
								if(json.get("HTTP_QUERY") != null 
										&& !json.get("HTTP_QUERY").getAsString().trim().isEmpty()
										&& !"null".equals(json.get("HTTP_QUERY").getAsString().trim())
								)
								{
									if(enc) {
										encStr = DamoEncUtil.data_encryption(json.get("HTTP_QUERY").getAsString(), "string");
										
										json.addProperty("HTTP_QUERY", encStr);									
									}
									
								} else {
									
									// 공백 또는 null일 경우 null로 치환
									json.add("HTTP_QUERY", null);
									
								}
								
								json.addProperty("rnd_key", UUIDUtil.getRndKey8());
								json.addProperty("log_aggr_datetime", getNow());
								
//								log.debug(json.toString());
								
								LogOrgDto vo = gs.fromJson(json, LogOrgDto.class);
								String jsonVo = gs.toJson(vo);
								
								ResultVo rs = IMDGUtil.makeInsertQryFromVo(jsonVo, TGT_TBL);
								
//								System.out.println(rs.getQuery());
								
								try (PreparedStatement stmt = conn.prepareStatement(rs.getQuery())) {
									
									int idx = 1;
									for(String val : rs.getArgs()) {
										stmt.setString(idx++, val);				
									}
									
									stmt.executeUpdate();
								}
								
//								rsltJsonStr = json.toString() + "\n";
//								rsltJsonStr = gs.toJson(json) + "\n";
//								log.debug(rsltJsonStr);
								
								// insert
							}
						}
	
						br.close();
	
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (Exception e) {
						log.info("{}", src.getName());
						e.printStackTrace();
					}
				}
			}
			
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("SET STREAMING OFF");
            }
			
		} catch(ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());		
	}		

	public void fDatabindToFile(final String SRC_PATH, final String TGT_PATH, boolean enc) {

		
		ParserHelper helper = ParserHelper.getInstance();
		
		StopWatch swch = new StopWatch("Step001MainLogToJson");
		swch.start("fileToFile");
		
		List<File> srcFiles = getFileListFromDir(SRC_PATH, "*.{log}");
		
		Gson gs = new Gson();
		
		JsonObject json = null;
		String rsltJsonStr = null;
		Matcher mtch = null;
		
		long idxLn = 0L;

		for (File src : srcFiles) {
			
//			log.debug("src : {}", src.getPath());

			if (src.exists()) {

				idxLn = 0L;
				
				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

					File wrFile = new File(TGT_PATH + src.getName() + ".json");
//					log.debug("tgt : {}", wrFile.getPath());

					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);

					String rd_line = null;
					String encStr = null;
					
					while ((rd_line = br.readLine()) != null
//							&& idxLn < 10
							) {

						idxLn++;

//						System.out.println(rd_line);
						
							String rslt = helper.parse2JsonWN(rd_line);
							
							log.debug(rslt);
							
							json = gs.fromJson(rslt, JsonObject.class);
							
							
							
							if( json.get("HTTP_QUERY") != null 
									&& !json.get("HTTP_QUERY").getAsString().trim().isEmpty() 
									&& !"null".equals(json.get("HTTP_QUERY").getAsString().trim())
							) {
															
								if(enc) {
									encStr = DamoEncUtil.data_encryption(json.get("HTTP_QUERY").getAsString(), "string");
									
									json.addProperty("HTTP_QUERY", encStr);
								}
								
							} else {
								
								// 공백 또는 null일 경우 null로 치환
								json.add("HTTP_QUERY", null);
								
							}
							
							json.addProperty("RND_KEY", UUIDUtil.getRndKey8());
							json.addProperty("LOG_AGGR_DATETIME", UUIDUtil.getNow());
							
//							log.debug(json.toString());
							
							rsltJsonStr = json.toString() + "\n";
//							rsltJsonStr = gs.toJson(json) + "\n";
//							log.debug(rsltJsonStr);
							
							owr.write(rsltJsonStr);
						
					}

					owr.close();
					br.close();

				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					
					
					log.info("{} ln -- {}", idxLn, src.getName());
					e.printStackTrace();
				}
			}
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());		
	}	
	
	
	public static void main(String[] args) {

		Temp001MainLogToJson step001 = new Temp001MainLogToJson();
		
		// file to file
//		step001.fileToFile(
//				"/Proj/LogExmples/dev/",
//				"/Proj/LogExmples/excp/",
//				
//				"/Proj/LogExmples/step001/",
//				"/Proj/LogExmples/excp_out/",
//				
//				true
//		);

//		step001.fDatabindToFile(
//			"/Proj/LogExmples/tmp03/",
////			"/Proj/LogExmples/excp/",
//		
//			"/Proj/LogExmples/tmp03_out/",
////			"/Proj/LogExmples/excp_out/",
//			false
//		);		
		
		
		// file to file
//		step001.fileToImdgJdbc(
//				"/Proj/LogExmples/dev/",
////				"/Proj/LogExmples/excp/",
//				"LOG_ORG",
//				true
//		);		
		
		
		step001.fileToImdgThin(
				"/Proj/LogExmples/dev/",
//				"/Proj/LogExmples/excp/",
				"ECUBE.RTO0001TM",
				true
		);				

		// file to imdg
		
		// input src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto
		
		// output src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto
		
	}		

}
