package com.woorifg.bigdata.rto.batch.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.commons.io.FilenameUtils;

public class HashMapTest {

	private static final String IN_CHARSET = "UTF-8";
	
	public static void main(String[] args) {
		
//		System.out.println(
//			FilenameUtils.getPath("/ecube/file/ifs/hdp/send/RTO0001TM_TEST.json") + 
//			FilenameUtils.getBaseName("/ecube/file/ifs/hdp/send/RTO0001TM_TEST.json")
//		);
		
		System.exit(0);
		
		
		File src = new File("/ecube/config/map.conf");
		
		if (src.exists()) {
			
			LinkedHashMap<String, Object> hm = new LinkedHashMap<String, Object>();
			
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
			
//				hm.put("withyou", "HTP_QRY_WITHYOU;m;x");
//				hm.put("_COM_SMT_UNIQUEID_FDS", "HTP_QRY__COM_SMT_UNIQUEID_FDS;m;x");
//				hm.put("_COM_SMT_UNIQUEID", "HTP_QRY__COM_SMT_UNIQUEID;m;x");
//				hm.put("isPhone", "HTP_QRY_ISPHONE;m;x");		

				String rd_line = null;
				
				int idxLn = 0;
				
				while ((rd_line = br.readLine()) != null) {
					
					if(rd_line.trim().isEmpty())
						continue;
					
					idxLn++;
					
//					System.out.println(idxLn + ":" + rd_line);
					
					String[] test = rd_line.split("\\|");
					
//					System.out.println(test[0]);
//					System.out.println(test[1]);
					
					hm.put(test[0], test[1]);
					
				}
				
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			for(Entry<String, Object> tmp : hm.entrySet()) {
				
				System.out.println(tmp.getKey() + "," + tmp.getValue());
			}
		}
		
		
	}

}
