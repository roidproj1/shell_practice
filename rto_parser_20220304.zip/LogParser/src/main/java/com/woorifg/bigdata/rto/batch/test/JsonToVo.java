package com.woorifg.bigdata.rto.batch.test;

import java.lang.reflect.Field;

import com.google.gson.Gson;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.utils.UUIDUtil;
import com.woorifg.bigdata.rto.batch.vos.TestVoKey;

public class JsonToVo {

	public static void main(String[] args) {
		
		String jsonStr = "{\"HTTP_CC_GUID\":\"20200730130438c0a8755c0187b0015c\",\"HTTP_CC_SESSION\":\"20211024185237c0a8755c015470008c\",\"SERVER_HOST\":\"wnbiz.wooribank.com\",\"SERVER_URL\":\"/biz/Dream\",\"REMOTE_ADDR\":\"1.232.5.3\",\"REMOTE_USER\":\"TESTFXD002_/2_/51\",\"USER_AGENT\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\",\"HTTP_URI\":\" \",\"HTTP_REFERER\":\"https://wnbiz.wooribank.com/biz/Dream?withyou=BZFXD0343\",\"HTTP_COOKIE\":\"\",\"HTTP_METHOD\":\"GET\",\"HTTP_TIME\":\"20211025010206406\",\"HTTP_QUERY\":\"B808F33356D2630466CFB5EB77874EA3CC3195977A2EB231D81DF0A54E128F52\",\"rnd_key\":\"6e30cf77\",\"log_aggr_datetime\":\"20220211144913255\"}";
		
		Gson gs = new Gson();
		
		TestVoKey vok = gs.fromJson(jsonStr, TestVoKey.class);
		LogOrgDto vo = gs.fromJson(jsonStr, LogOrgDto.class);
		
		vok.setRnd_key(UUIDUtil.getRndKey8());
		vok.setLog_aggr_datetime(UUIDUtil.getNow());
		
		vo.setRnd_key(vok.getRnd_key());
		vo.setLog_aggr_datetime(vok.getLog_aggr_datetime());
		
		System.out.println(vok.toString());
		System.out.println(vo.toString());
		
		for(Field fd : vo.getClass().getDeclaredFields()) {
			System.out.println(fd.getName());
		}
		
		


	}

}
