package com.woorifg.bigdata.rto.batch.dtos;

import java.io.Serializable;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogOrgDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@SerializedName(value="http_cc_guid", alternate="HTTP_CC_GUID")
	@QuerySqlField(index = true)	
	private String http_cc_guid;
	
	@SerializedName(value="http_cc_session", alternate="HTTP_CC_SESSION")
	@QuerySqlField(index = true)	
	String http_cc_session;
	
	@SerializedName(value="http_time", alternate="HTTP_TIME")
	@QuerySqlField(index = true)	
	String http_time;
	
	@SerializedName(value="host_name", alternate="HOST_NAME")
	@QuerySqlField(index = true)
	String host_name = "wrtoap02d";

	@QuerySqlField(index = true)	
	String log_aggr_datetime;
	
	@QuerySqlField(index = true)	
	String rnd_key;
	
	@SerializedName(value="http_cookie", alternate="HTTP_COOKIE")
	@QuerySqlField	
	String http_cookie;

	@SerializedName(value="http_method", alternate="HTTP_METHOD")
	@QuerySqlField	
	String http_method;
	
	@SerializedName(value="http_referer", alternate="HTTP_REFERER")
	@QuerySqlField	
	String http_referer;
	
	@SerializedName(value="http_uri", alternate="HTTP_URI")
	@QuerySqlField
	String http_uri;
	
	@SerializedName(value="remote_addr", alternate="REMOTE_ADDR")
	@QuerySqlField	
	String remote_addr;
	
	@SerializedName(value="remote_user", alternate="REMOTE_USER")
	@QuerySqlField	
	String remote_user;
	
	@SerializedName(value="server_host", alternate="SERVER_HOST")
	@QuerySqlField	
	String server_host;

	@SerializedName(value="server_url", alternate="SERVER_URL")
	@QuerySqlField	
	String server_url;
	
	@SerializedName(value="user_agent", alternate="USER_AGENT")
	@QuerySqlField	
	String user_agent;
	
	@SerializedName(value="http_query", alternate="HTTP_QUERY")
	@QuerySqlField	
	String http_query;
	
	
	public String getHttp_cookie() {
		if(this.http_cookie != null && this.http_cookie.trim().isEmpty()) {
			this.http_cookie = null;
		}
		return this.http_cookie;
	}
	
	public String getHttp_method() {
		if(this.http_method != null && this.http_method.trim().isEmpty()) {
			this.http_method = null;
		}
		return this.http_method;
	}
	
	public String getHttp_referer() {
		if(this.http_referer != null && this.http_referer.trim().isEmpty()) {
			this.http_referer = null;
		}
		return this.http_referer;
	}
	
	public String getHttp_uri() {
		if(this.http_uri != null && this.http_uri.trim().isEmpty()) {
			this.http_uri = null;
		}
		return this.http_uri;
	}	

	public String getRemote_addr() {
		if(this.remote_addr != null && this.remote_addr.trim().isEmpty()) {
			this.remote_addr = null;
		}
		return this.remote_addr;
	}	
	
	public String getRemote_user() {
		if(this.remote_user != null && this.remote_user.trim().isEmpty()) {
			this.remote_user = null;
		}
		return this.remote_user;
	}
	
	public String getServer_host() {
		if(this.server_host != null && this.server_host.trim().isEmpty()) {
			this.server_host = null;
		}
		return this.server_host;
	}			

	
	public String getServer_url() {
		if(this.server_url != null && this.server_url.trim().isEmpty()) {
			this.server_url = null;
		}
		return this.server_url;
	}
	
	public String getUser_agent() {
		if(this.user_agent != null && this.user_agent.trim().isEmpty()) {
			this.user_agent = null;
		}
		return this.user_agent;
	}	
	
}
