package com.woorifg.bigdata.rto.batch.enums_20220210;

public enum EEnc {
	NONE,
	ENC_BLANK,		//  공백 포함 암호화 ( 오직 공백만 있는 경우도 포함 )
	ENC,			// 	좌우 공백 trim해서 암호화
	FULL_MASK,
	MASK,
	;
}
