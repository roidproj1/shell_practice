package com.woorifg.bigdata.rto.batch.parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.ClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.woorifg.bigdata.rto.batch.consts.Consts;

// Step 1. Log to Json
public class Test001CsvToImdg {
	
	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(Test001CsvToImdg.class);
	
	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";	
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";


	// Base Parser
	public JsonObject parseLine(String src) throws Exception {
		return null;
	}

	// HttpQuery Parser
	
	

	
	private void printParseErr(String fileNm, Long idxLn, String src ) {
		log.info("Parse Err : {} -- {} line : {}", fileNm, idxLn, src);
	}
	
	private String getNow() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
	
	

	

	public void fileToImdgThin(final String SRC_PATH, final String TGT_TBL, boolean enc) {

		StopWatch swch = new StopWatch("Step001MainLogToJson");
		swch.start("fileToImdg");
		
		File src = new File(SRC_PATH);
		
		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
			
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("SET STREAMING ON");
            }
			
			Gson gs = new Gson();
			
			JsonObject json = null;
//			String rsltJsonStr = null;
			
			long idxLn = 0L;
	
				
//				log.debug("src : {}", src.getPath());
	
				if (src.exists()) {
	
					idxLn = 0L;
					
					try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {

//						log.debug("tgt : {}", wrFile.getPath());
	
						String rd_line = null;
						String encStr = null;
						
						while ((rd_line = br.readLine()) != null) {
	
							idxLn++;
	
//							System.out.println(rd_line);
							try {
								
									json = parseLine(rd_line);
								
							} catch(Exception e) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
							}
	
							if(json == null) {
								
								printParseErr(src.getName(), idxLn, rd_line);
								continue;
								
							} else {
								
//								if(json.get("HTTP_QUERY") != null && !json.get("HTTP_QUERY").getAsString().trim().isEmpty())
//								{
//									if(enc) {
//										encStr = PersonalInfomationUtil.data_encryption(json.get("HTTP_QUERY").getAsString(), "string");
//										
//										json.addProperty("HTTP_QUERY", encStr);									
//									}
//									
//								} else {
//									
//									// 공백 또는 null일 경우 null로 치환
//									json.addProperty("HTTP_QUERY", (String) null);
//									
//								}
//								
//								json.addProperty("rnd_key", UUIDUtil.getRndKey8());
//								json.addProperty("log_aggr_datetime", getNow());
								
//								log.debug(json.toString());
								
//								LogOrgDto vo = gs.fromJson(json, LogOrgDto.class);
//								String jsonVo = gs.toJson(vo);
								
//								ResultVo rs = IMDGUtil.makeInsertQryFromVo(jsonVo);
								
//								System.out.println(rs.getQuery());
								
//								try (PreparedStatement stmt = conn.prepareStatement(rs.getQuery())) {
//									
//									int idx = 1;
//									for(String val : rs.getArgs()) {
//										stmt.setNString(idx++, val);				
//									}
//									
//									stmt.executeUpdate();
//								}
								
//								log.debug(rsltJsonStr);
								
								// insert
							}
						}
	
						br.close();
	
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (Exception e) {
						log.info("{}", src.getName());
						e.printStackTrace();
					}
				}
			
			
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("SET STREAMING OFF");
            }
			
		} catch(ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());		
	}		
	
	
	public static void main(String[] args) {

		Test001CsvToImdg step001 = new Test001CsvToImdg();
		
		step001.fileToImdgThin(
				"/Proj/LogExmples/dev/",
//				"/Proj/LogExmples/excp/",
				"LOG_ORG",
				true
		);				

		// file to imdg
		
		// input src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto
		
		// output src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto
		
	}		

}
