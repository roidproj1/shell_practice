package com.woorifg.bigdata.rto.batch.parse;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.ClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.woorifg.bigdata.rto.batch.consts.Consts;

// Step 1. Log to Json
public class Step001HttpQryToImdg {

	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(Step001HttpQryToImdg.class);

	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";

	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";
	private static Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);

	// HttpQuery Parser
	public JsonObject parseLine(String src) throws Exception {
		return parseStepHttpQuery(src);
	}

	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {

					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) {

					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}

				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value

					// dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}

	private List<File> getFileListFromDir(final String SRC_PATH, final String ext) {

		List<File> srcFiles = new ArrayList<File>();

		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), ext)) {

			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());
				srcFiles.add(path.toFile());
			});

			dirStream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return srcFiles;
	}

	private void printParseErr(String fileNm, Long idxLn, String src) {
		log.info("Parse Err : {} -- {} line : {}", fileNm, idxLn, src);
	}

	
	public void logOrgToRto001tm(final String SRC_TBL, final String TGT_TBL, boolean enc) {

		StopWatch swch = new StopWatch("Step002");
		swch.start("toFile");

		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
			
			try (Statement stmt = conn.createStatement()) {
				
                try (ResultSet rs = stmt.executeQuery("SELECT p.name, c.name FROM Person p INNER JOIN City c on c.id = p.city_id")) {


                    while (rs.next())
                        System.out.println(">>>    " + rs.getString(1) + ", " + rs.getString(2));
                }
            }
			
			
			// 읽은것 json화
			
			// httpqry 읽기
			// httpqry 읽은 것 파싱
			
			// httpqry 특수 파싱 처리
			
			// httpqry 암호화 처리
			

		} catch (ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}

	public static void main(String[] args) {

		Step001HttpQryToImdg step002 = new Step001HttpQryToImdg();

		// file to file
//		step002.fileToFile(
//				"/Proj/LogExmples/step001/",
////				"/Proj/LogExmples/excp/",
//				
//				"/Proj/LogExmples/step002/",
////				"/Proj/LogExmples/excp_out/",
//				
//				true
//		);

		// file to imdg

		// input src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto

		// output src
		// 1. file
		// 2. pipe vo
		// 3. imdg dto

	}

}
