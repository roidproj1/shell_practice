package com.woorifg.bigdata.rto.batch.test;

import com.woorifg.bigdata.rto.batch.enums_20220210.EMaster;

public class TestLogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(EMaster.getNewCase());
		
	}

}
