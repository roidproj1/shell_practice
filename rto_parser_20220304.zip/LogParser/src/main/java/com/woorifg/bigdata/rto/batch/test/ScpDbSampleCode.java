package com.woorifg.bigdata.rto.batch.test;
 
/******** DAMO API **********/
/******** DAMO API **********/
import com.penta.scpdb.ScpDbAgent;
import com.penta.scpdb.ScpDbAgentException;

public class ScpDbSampleCode
{
  public static void main(String[] args)
  {
    try
    {
      int ret;
      /* DAMO SCP : config file full path */
//      String iniFilePath = "/app/damo3/scpdb_agent.ini"; //Unix/Linux Server
	  String iniFilePath = "C:\\app\\damo3\\scpdb_agent.ini"; // Windows Server
      
      /* DAMO SCP */      
      ScpDbAgent agt = new ScpDbAgent();
      
      /* DAMO SCP : initialization */ 
      /* return : 0,118(success) */
      ret = agt.AgentInit( iniFilePath );
      System.out.println("AgentInit ret : " + ret );
      if ( ret != 0 && ret != 118 )
      {
        Thread.sleep(2000);
        return;
      }

      /* DAMO SCP : reinitialization */
      /* return : 0(success) */
      Thread.sleep(2000);      
      /*
      ret = agt.AgentReInit( iniFilePath );
      System.out.println("AgentReInit ret : " + ret );
      if ( ret != 0 )
      {
        Thread.sleep(2000);
        return;
      }
      */
      
      
      
      /* DAMO SCP : HASH function */
      /* HASH Algorithm ID :
        SHA1 = 70
        SHA256 = 71
        SHA384 = 72
        SHA512 = 73
        HAS160 = 74
        MD5 = 75
      */
      {        
        String strPlain = "123456-1234567";
        String strHash = "";        
        strHash = agt.AgentCipherHashString(71, strPlain);
        System.out.println("hash(" + strHash.length() + ")         : " + strHash);
        strHash = agt.AgentCipherHashStringB64(71, strPlain);
        System.out.println("hashB64(" + strHash.length() + ")      : " + strHash);
      }
      {
        String strPlain = "123456-1234567";
        String strHash = "";         
        byte[] hash;
        hash = agt.AgentCipherHash(71, strPlain);
        strHash = new String(hash);
        System.out.println("hash(" + strHash.length() + ")         : " + strHash);
        hash = agt.AgentCipherHashB64(71, strPlain);
        strHash = new String(hash);
        System.out.println("hashB64(" + strHash.length() + ")      : " + strHash);
      }
            
      /* DAMO SCP : util function */   
      {       
        String strPlain = "123456-1234567";
        String strHash = "";         
        byte[] hash;
        hash = agt.AgentCipherHash(71, strPlain);
        strHash = new String(hash);
        hash = agt.AgentHexToB64(strHash);
        strHash = new String(hash);
        System.out.println("HexToB64(" + strHash.length() + ")     : " + strHash);
        hash = agt.AgentB64ToHex(strHash);
        strHash = new String(hash);
        System.out.println("B64ToHex(" + strHash.length() + ")     : " + strHash);
      }      
      Thread.sleep(2000);      
      
      
      
      /* DAMO SCP : create context */
      byte[] ctx;      
      ctx = agt.AgentCipherCreateContextServiceID( "RTO", "Account");
      //ctx = agt.AgentCipherCreateContext( "agent_id", "db_name", "owner", "table_name", "column_name" );
      //String scpKeyFilePath = "/app/damo3/AES_128_E_FIXED_IV_CBC.SCPS"; //keyfile.scp fullpath
      //ctx = agt.AgentCipherCreateContextImportFile( scpKeyFilePath );

      /* DAMO SCP : encrypt/decrypt string function */
      {
        String strPlain = "123456-1234567";
        String strEnc = "";
        String strDec = "";      
        strEnc = agt.AgentCipherEncryptString( ctx, strPlain );
        System.out.println("EncryptString    : " + strEnc);
        strDec = agt.AgentCipherDecryptString( ctx, strEnc );
        System.out.println("DecryptString    : " + strDec);
      }

      /* DAMO SCP : encrypt/decrypt string base64 function */
      {
        String strPlain = "123456-1234567";
        String strEnc = "";
        String strDec = "";   
        strEnc = agt.AgentCipherEncryptStringB64( ctx, strPlain );
        System.out.println("EncryptStringB64 : " + strEnc);
        strDec = agt.AgentCipherDecryptStringB64( ctx, strEnc );
        System.out.println("DecryptStringB64 : " + strDec);
      }

      /* DAMO SCP : encrypt/decrypt function */
      {
        String strPlain = "123456-1234567";
        String strEnc = "";
        String strDec = "";        
        byte[] enc;
        byte[] dec;      
        enc = agt.AgentCipherEncrypt( ctx, strPlain );
        strEnc = new String(enc);
        System.out.println("Encrypt          : " + strEnc);      
        dec = agt.AgentCipherDecrypt( ctx, strEnc );
        strDec = new String(dec);
        System.out.println("Decrypt          : " + strDec);
      }  

      /* DAMO SCP : encrypt/decrypt function */
      {
        String strPlain = "123456-1234567";
        String strEnc = "";
        String strDec = "";        
        byte[] enc;
        byte[] dec;        
        enc = agt.AgentCipherEncryptB64( ctx, strPlain );
        strEnc = new String(enc);
        System.out.println("EncryptB64       : " + strEnc);
        dec = agt.AgentCipherDecryptB64( ctx, strEnc );
        strDec = new String(dec);
        System.out.println("DecryptB64       : " + strDec);
      }  

      /* DAMO SCP : encrypt/decrypt function */
      {
        byte[] byteInputPlain = { (byte)0x31, (byte)0x32, (byte)0x33, (byte)0x34, (byte)0x35, (byte)0x36, (byte)0x2d, (byte)0x31, (byte)0x32, (byte)0x33, (byte)0x34, (byte)0x35, (byte)0x36, (byte)0x37 };
        byte[] enc;
        byte[] dec; 
        enc = agt.AgentCipherEncryptRaw( ctx, byteInputPlain );
        System.out.print("EncryptRaw       : ");
        for( int i=0; i<enc.length; i++)
        {
          if ( (0xFF&enc[i]) < 16)
          {
            System.out.print("0"+Integer.toHexString(0xFF&enc[i]));
          }
          else
            System.out.print(Integer.toHexString(0xFF&enc[i]));
        }
        System.out.print("\n");

        dec = agt.AgentCipherDecryptRaw( ctx, enc);
        System.out.print("DecryptRaw       : ");
        for( int i=0; i<dec.length; i++)
        {
          if ( (0xFF&dec[i]) < 16)
          {
            System.out.print("0"+Integer.toHexString(0xFF&dec[i]));
          }
          else
            System.out.print(Integer.toHexString(0xFF&dec[i]));
        }
        System.out.print("\n");
      }
      
      /* DAMO SCP : encrypt/decrypt function */
      {
        String strNumber = "10";
        String strEnc = "";
        String strDec = "";      
        strEnc = agt.AgentCipherEncryptNumber( ctx, strNumber, "ORACLE" );
        System.out.println("EncryptNumber    : " + strEnc);
        strDec = agt.AgentCipherDecryptNumber( ctx, strEnc, "ORACLE" );
        System.out.println("EncryptNumber    : " + strDec);
      }

      /* DAMO SCP : encrypt/decrypt function */
      {
        int inputNumber = 10;
        int outputNumber;
        String strEnc = "";        
        strEnc = agt.AgentCipherEncryptInt( ctx, inputNumber, "ORACLE" );
        System.out.println("EncryptInt       : " + strEnc);
        outputNumber = agt.AgentCipherDecryptInt( ctx, strEnc, "ORACLE" );
        System.out.println("EncryptInt       : " + outputNumber);
      }

      /* DAMO SCP : HASH function */
      /* HASH Algorithm ID :
        SHA1 = 70
        SHA256 = 71
        SHA384 = 72
        SHA512 = 73
        HAS160 = 74
        MD5 = 75
      */
      {        
        String strPlain = "123456-1234567";
        String strHash = "";        
        strHash = agt.AgentCipherHashString(71, strPlain);
        System.out.println("hash(" + strHash.length() + ")         : " + strHash);
        strHash = agt.AgentCipherHashStringB64(71, strPlain);
        System.out.println("hashB64(" + strHash.length() + ")      : " + strHash);
      }
      {
        String strPlain = "123456-1234567";
        String strHash = "";         
        byte[] hash;
        hash = agt.AgentCipherHash(71, strPlain);
        strHash = new String(hash);
        System.out.println("hash(" + strHash.length() + ")         : " + strHash);
        hash = agt.AgentCipherHashB64(71, strPlain);
        strHash = new String(hash);
        System.out.println("hashB64(" + strHash.length() + ")      : " + strHash);
      }
            
      /* DAMO SCP : index encrypt function */            
      {
        String strPlain = "123456-1234567";
        String strEnc = "";        
        strEnc = agt.AgentCipherIndexString(ctx, strPlain);
        System.out.println("IndexString(" + strEnc.length() + ")  : " + strEnc);      
      }
      {
        String strPlain = "123456-1234567";
        String strEnc = "";
        byte[] enc;        
        enc = agt.AgentCipherIndex(ctx, strPlain);
        strEnc = new String(enc);
        System.out.println("Index(" + strEnc.length() + ")        : " + strEnc);
      }  

      /* DAMO SCP : util function */   
      {       
        String strPlain = "123456-1234567";
        String strHash = "";         
        byte[] hash;
        hash = agt.AgentCipherHash(71, strPlain);
        strHash = new String(hash);
        hash = agt.AgentHexToB64(strHash);
        strHash = new String(hash);
        System.out.println("HexToB64(" + strHash.length() + ")     : " + strHash);
        hash = agt.AgentB64ToHex(strHash);
        strHash = new String(hash);
        System.out.println("B64ToHex(" + strHash.length() + ")     : " + strHash);
      }      
      Thread.sleep(2000);
    }
    catch (ScpDbAgentException e1)
    {
      System.out.println(e1.toString());
      e1.printStackTrace();
    }
    catch (Exception e) {
      e.printStackTrace();      
    }
    finally {
      try{Thread.sleep(2000);}catch(Exception e2){}
    }
    
  }
}
