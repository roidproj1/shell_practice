package com.woorifg.bigdata.rto.batch.parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.io.FilenameUtils;
import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.ClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.dtos.LogOrgDto;
import com.woorifg.bigdata.rto.batch.parse_20220210.ParseCase;
import com.woorifg.bigdata.rto.batch.utils.DamoEncUtil;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.JsonUtil;
import com.woorifg.bigdata.rto.batch.utils.KeyParseUtil;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;

// Step 1. Log to Json
public class Step001ImdgLogOrgToFile {

	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(Step001ImdgLogOrgToFile.class);

	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";
	
	
	private static final String SRC_TBL = "RTO0001TM";		// LOG_ORG
	private static final String MST_TBL = "RTO0002TM";		// MASTER

	
	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";
	private static Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);

	// HttpQuery Parser
	public JsonObject parseLine(String src) {
		
		// 1: HTTP_QUERY Case --> 2: parseStepHttpQuery
		
		JsonObject rsltJson = new JsonObject();
		
		try {
		
			JsonObject tmpHttpQry = parseStepHttpQuery(src);
			
			if (tmpHttpQry == null) {
				rsltJson.addProperty("HTTP_QUERY", src);
			} else {
				rsltJson.add("HTTP_QUERY", tmpHttpQry);
			}
			
		} catch (Exception e) {
			
//			e.printStackTrace();
			rsltJson.addProperty("HTTP_QUERY", src);
			
			log.debug("HttpQuery toJson Error : {}", src);
		}
		
		return rsltJson.size() == 0 ? null : rsltJson;

	}

	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {

					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) {

					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}

				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value

					// dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}	

	// 향후 keys 받는 외부 함수로 인자 변경 처리
	public void imdgLogOrgToCsv(final String TGT_PATH) {

		StopWatch swch = new StopWatch("Step001_imdgLogOrgToCsv");
		swch.start("step001");

		
		StringBuilder sb = new StringBuilder();
		
		sb.append("HTTP_CC_GUID;")
			.append("HTTP_CC_SESSION;")
			.append("HTTP_TIME;")
			.append("HOST_NAME;")
			.append("LOG_AGGR_DATETIME;")
			.append("RND_KEY;")
			.append("HTTP_COOKIE;")
			.append("HTTP_METHOD;")
			.append("HTTP_REFERER;")
			.append("HTTP_URI;")
			.append("REMOTE_ADDR;")
			.append("REMOTE_USER;")
			.append("SERVER_HOST;")
			.append("SERVER_URL;")
			.append("USER_AGENT;")
			.append("HTTP_QUERY")
		;
		
		
		String[] keys = sb.toString().split(";", -1);
		
		String selQry = IMDGUtil.makeSelectQryFromStrArr(keys, SRC_TBL);

		StringBuilder sbCsv = new StringBuilder();  
		List<String> lstTmp = new ArrayList<String>(); 
		
		
//		int idx = 0;
		
		// Property 처리할 것
		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
			
			try (Statement stmt = conn.createStatement()) {
				
				File wrFile = new File(TGT_PATH);
            	OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);
				
                try (ResultSet rs = stmt.executeQuery(selQry)) {

                    while (rs.next() 
//                    		&& idx++ < 2
                    ) {

                    	int i = 1;
                    	
                    	lstTmp.clear();
                    	
                    	for(String key : keys) {
                    		
//                    		log.debug("{} -- {}", key, rs.getString(i));
                    		
                    		// HTTP_QUERY 복호화 처리
                    		if("HTTP_QUERY".equals(key) && rs.getString(i) != null) {
                    			lstTmp.add(DamoEncUtil.data_decryption(rs.getString(i)));
                    		} else {
                    			lstTmp.add(rs.getString(i));
                    		}
                    		
                    		i++;
                		
                    	}

                    	sbCsv.setLength(0);
                    	
                    	try(CSVPrinter printer = new CSVPrinter(sbCsv, CSVFormat.DEFAULT)) {
                    		
                    		printer.printRecord(lstTmp);
                    		printer.close();
                    		
                    	} catch (IOException e) {
							e.printStackTrace();
						}
                    	
//                    	log.debug("{}", sbCsv.toString());
                    	
                    	owr.write(sbCsv.toString());
                    }
                    
                    owr.close();
                    
                }
            }
			
		} catch (ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}
	
	

	public void imdgLogOrgToJsonFile(final String TGT_PATH, String sFrom, String sTo) {

		StopWatch swch = new StopWatch("Step001_imdgLogOrgToCsv");
		swch.start("step001");
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("HTTP_CC_GUID;")
			.append("HTTP_CC_SESSION;")
			.append("HTTP_TIME;")
			.append("HOST_NAME;")
			.append("LOG_AGGR_DATETIME;")
			.append("RND_KEY;")
			.append("HTTP_COOKIE;")
			.append("HTTP_METHOD;")
			.append("HTTP_REFERER;")
			.append("HTTP_URI;")
			.append("REMOTE_ADDR;")
			.append("REMOTE_USER;")
			.append("SERVER_HOST;")
			.append("SERVER_URL;")
			.append("USER_AGENT;")
			.append("HTTP_QUERY")
		;
		
		String[] keys = sb.toString().split(";", -1);
		
		StringBuilder sbQry = new StringBuilder();
		
		String selQry = IMDGUtil.makeSelectQryFromStrArr(keys, SRC_TBL);
		
		
		sbQry.append(selQry);
		
		if(sFrom != null) {
			sbQry.append(" WHERE HTTP_TIME >= ").append(sFrom);
		}
		
		if(sFrom != null && sTo != null) {
			sbQry.append(" AND HTTP_TIME < ").append(sTo);
		}
		
		selQry = sbQry.toString();

		
		JsonObject json;
		Gson gs = new Gson();
		
//		int idx = 0;
		
		// Property 처리할 것
		try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
			
			try (Statement stmt = conn.createStatement()) {
				
				File wrFile = new File(TGT_PATH);
            	OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);
				
                try (ResultSet rs = stmt.executeQuery(selQry)) {

                    while (rs.next() 
//                    		&& idx++ < 2
                    ) {

                    	int i = 1;
                    	
                    	json = new JsonObject();
                    	
                    	for(String key : keys) {
                    		
//                    		log.debug("{} -- {}", key, rs.getString(i));
                    		
                    		// HTTP_QUERY 복호화 처리
                    		if("HTTP_QUERY".equals(key) 
                    				&& rs.getString(i) != null
                    				&& !rs.getString(i).trim().isEmpty()
                    				&& !"null".equals(rs.getString(i))
                    		) {
                    			json.addProperty("HTTP_QUERY", DamoEncUtil.data_decryption(rs.getString(i)));
                    		} else {
                    			json.addProperty(key, rs.getString(i));
                    		}
                    		
                    		i++;
                  		
                    	}
                    	
//                    	log.debug("{}", sbCsv.toString());
                    	
                    	owr.write(gs.toJson(json) + "\n");
                    }
                    
                    owr.close();
                    
                }
            }
			
		} catch (ClientConnectionException e) {
			e.printStackTrace();
		} catch (ClientException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}
		
	
	
	// 향후 keys 받는 외부 함수로 인자 변경 처리
	public void fileLogOrgToMstJsonFile(final String SRC_PATH, final String TGT_PATH) {

		StopWatch swch = new StopWatch("fileLogOrgToMstJsonFile");
		swch.start("step001");

//		Configuration jsonPathConf = Configuration.builder()
//				.mappingProvider(new GsonMappingProvider())
//				.jsonProvider(new GsonJsonProvider())
////				.options(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS)
//				.options(Option.SUPPRESS_EXCEPTIONS)
//				.build();
		
		
		File src = new File(SRC_PATH);
		
//		List<File> srcFiles = new ArrayList<File>();
//
//		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{json}")) {
//
//			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());
//				srcFiles.add(path.toFile());
//			});
//
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		}
		
		
		Gson gs = new Gson();
		JsonObject json = null;
		JsonObject jsonHtpQry = null;
		
		String rsltJsonStr = null;
		long idxLn = 0L;
		
		TreeMap<String, Object> hm = new TreeMap<String, Object>();
		
		hm.put("withyou", "HTP_QRY_WITHYOU;m;x");
		hm.put("_COM_SMT_UNIQUEID_FDS", "HTP_QRY__COM_SMT_UNIQUEID_FDS;m;x");
		hm.put("_COM_SMT_UNIQUEID", "HTP_QRY__COM_SMT_UNIQUEID;m;x");
		hm.put("isPhone", "HTP_QRY_ISPHONE;m;x");
		hm.put("_JSON_DATA", "HTP_QRY__JSON_DATA;d;e");
		hm.put("_COM_SSAID", "HTP_QRY__COM_SSAID;m;x");
		hm.put("_SYSTEM_MDI_KDCD", "HTP_QRY__SYSTEM_MDI_KDCD;m;x");
		hm.put("DEVICE_ID_GROUP", "HTP_QRY_DEVICE_ID_GROUP;m;x");
		hm.put("__ID", "HTP_QRY___ID;m;x");
		hm.put("PHONE_TYPE", "HTP_QRY_PHONE_TYPE;m;x");
		hm.put("transkey_i", "HTP_QRY_TRANSKEY_I;m;x");
		hm.put("transkey_inputs", "HTP_QRY_TRANSKEY_INPUTS;m;x");
		hm.put("transkeyUuid", "HTP_QRY_TRANSKEYUUID;m;x");
		hm.put("cmd", "HTP_QRY_CMD;m;x");
		hm.put("PID", "HTP_QRY_PID;m;x");
		hm.put("reqBizId", "HTP_QRY_REQBIZID;m;x");
		hm.put("CNCT_PATH", "HTP_QRY_CNCT_PATH;m;x");
		hm.put("svcGb", "HTP_QRY_SVCGB;m;x");
		hm.put("svcUrl", "HTP_QRY_SVCURL;m;x");
		hm.put("dontUseSes", "HTP_QRY_DONTUSESES;m;x");
		hm.put("datatype", "HTP_QRY_DATATYPE;m;x");
		hm.put("searchText", "HTP_QRY_SEARCHTEXT;m;x");
		hm.put("deviceGubn", "HTP_QRY_DEVICEGUBN;m;x");
		hm.put("charset", "HTP_QRY_CHARSET;m;x");
		hm.put("range", "HTP_QRY_RANGE;m;x");
		hm.put("collection", "HTP_QRY_COLLECTION;m;x");
		hm.put("INQ_ACNO", "HTP_QRY_INQ_ACNO;m;e");
		hm.put("cc", "HTP_QRY_CC;m;x");
		hm.put("target", "HTP_QRY_TARGET;m;x");
		hm.put("CUCD", "HTP_QRY_CUCD;m;x");
		hm.put("SBJCD_2", "HTP_QRY_SBJCD_2;m;x");
		hm.put("AccName", "HTP_QRY_ACCNAME;m;x");
		hm.put("USER_ID", "HTP_QRY_USER_ID;m;x");
		hm.put("AccGbn", "HTP_QRY_ACCGBN;m;x");
		hm.put("__E2E_UNIQUE__", "HTP_QRY___E2E_UNIQUE__;m;x");
		hm.put("__E2E_RESULT__", "HTP_QRY___E2E_RESULT__;m;x");
		hm.put("INQ_END_DT", "HTP_QRY_INQ_END_DT;m;x");
		hm.put("STR_NM", "HTP_QRY_STR_NM;m;e");
		hm.put("CUCD_3", "HTP_QRY_CUCD_3;m;x");
		hm.put("PBOK_BAL", "HTP_QRY_PBOK_BAL;m;x");
		hm.put("ACT_PWNO", "HTP_QRY_ACT_PWNO;m;f");
		hm.put("__STEP", "HTP_QRY___STEP;m;x");
		hm.put("LN_ACNO", "HTP_QRY_LN_ACNO;m;e");
		hm.put("CRCD_3", "HTP_QRY_CRCD_3;m;x");
		hm.put("INQ_STA_DT", "HTP_QRY_INQ_STA_DT;m;x");
		hm.put("OWAC_FNM", "HTP_QRY_OWAC_FNM;m;k");
		hm.put("PSNBZ_RGS_YN", "HTP_QRY_PSNBZ_RGS_YN;m;x");
		hm.put("WDR_ACNO", "HTP_QRY_WDR_ACNO;m;e");
		hm.put("ACNO", "HTP_QRY_ACNO;m;e");
		hm.put("VID_MSG", "HTP_QRY_VID_MSG;m;x");
		hm.put("NEW_ACNO", "HTP_QRY_NEW_ACNO;m;e");
		hm.put("m", "HTP_QRY_M;m;x");
		hm.put("afwdata", "HTP_QRY_AFWDATA;m;x");
		hm.put("z", "HTP_QRY_Z;m;x");
		hm.put("ac", "HTP_QRY_AC;m;x");
		hm.put("INQ_ACNO_15", "HTP_QRY_INQ_ACNO_15;m;e");
		hm.put("defSelAcctNo", "HTP_QRY_DEFSELACCTNO;m;e");
		hm.put("PWD", "HTP_QRY_PWD;m;f");
		hm.put("SBJCD_3", "HTP_QRY_SBJCD_3;m;x");
		hm.put("_INSIDE_NAT", "HTP_QRY__INSIDE_NAT;m;x");
		hm.put("NCM", "HTP_QRY_NCM;m;x");
		hm.put("transkey_hMac_Tk_PWD", "HTP_QRY_TRANSKEY_HMAC_TK_PWD;m;x");
		hm.put("transkey_Tk_PWD", "HTP_QRY_TRANSKEY_TK_PWD;m;f");
		hm.put("loginGubun", "HTP_QRY_LOGINGUBUN;m;x");
		hm.put("rSelect", "HTP_QRY_RSELECT;m;x");
		hm.put("NEXT_YN_EXT", "HTP_QRY_NEXT_YN_EXT;m;x");
		hm.put("RCV_ACNO", "HTP_QRY_RCV_ACNO;m;e");
		hm.put("DPKD_10", "HTP_QRY_DPKD_10;m;x");
		hm.put("Tk_PWD_check", "HTP_QRY_TK_PWD_CHECK;m;x");
		hm.put("PWD__E2E__", "HTP_QRY_PWD__E2E__;m;f");
		hm.put("NEW_DT", "HTP_QRY_NEW_DT;m;x");
		hm.put("ACT_MNG_BRCD", "HTP_QRY_ACT_MNG_BRCD;m;x");
		hm.put("CO_CUS_MST_ID", "HTP_QRY_CO_CUS_MST_ID;m;x");
		hm.put("TBL_NM", "HTP_QRY_TBL_NM;m;x");
		hm.put("ACTNO", "HTP_QRY_ACTNO;m;e");
		hm.put("TS_EXE_TM_DIS", "HTP_QRY_TS_EXE_TM_DIS;m;x");
		hm.put("ipinsideData", "HTP_QRY_IPINSIDEDATA;m;x");
		hm.put("ipinsideNAT", "HTP_QRY_IPINSIDENAT;m;x");
		hm.put("ipinsideCOMM", "HTP_QRY_IPINSIDECOMM;m;x");
		hm.put("DPS_INP_ACNO", "HTP_QRY_DPS_INP_ACNO;m;e");
		hm.put("_SYSEN_TRNO", "HTP_QRY__SYSEN_TRNO;m;x");
		hm.put("flag", "HTP_QRY_FLAG;m;x");
		hm.put("TRN_AM", "HTP_QRY_TRN_AM;m;x");
		hm.put("addDepYN", "HTP_QRY_ADDDEPYN;m;x");
		hm.put("sGoodsAccnoIndex", "HTP_QRY_SGOODSACCNOINDEX;m;x");
		hm.put("TS_GUBUN", "HTP_QRY_TS_GUBUN;m;x");
		hm.put("DPBAL_13", "HTP_QRY_DPBAL_13;m;x");
		hm.put("SCREEN_GB", "HTP_QRY_SCREEN_GB;m;x");
		hm.put("DETAIL_GB", "HTP_QRY_DETAIL_GB;m;x");
		hm.put("RCV_BKCD", "HTP_QRY_RCV_BKCD;m;x");
		hm.put("ACTPWNO_8", "HTP_QRY_ACTPWNO_8;m;f");
		hm.put("NEW_DPS_INP_ACNO", "HTP_QRY_NEW_DPS_INP_ACNO;m;e");
		hm.put("isIcheAccNo", "HTP_QRY_ISICHEACCNO;m;x");
		hm.put("NEW_INQ_ACNO", "HTP_QRY_NEW_INQ_ACNO;m;e");
		hm.put("ACTPWNO", "HTP_QRY_ACTPWNO;m;f");
		hm.put("TS_EXE_DT", "HTP_QRY_TS_EXE_DT;m;x");
		hm.put("WOORI_09", "HTP_QRY_WOORI_09;m;x");
		hm.put("PAYDACBR_3", "HTP_QRY_PAYDACBR_3;m;x");
		hm.put("RCVDACBR_3", "HTP_QRY_RCVDACBR_3;m;x");
		hm.put("PAYDACCMOD_1", "HTP_QRY_PAYDACCMOD_1;m;x");
		hm.put("RCV_LMT_ACNO", "HTP_QRY_RCV_LMT_ACNO;m;e");
		hm.put("useMemoYN", "HTP_QRY_USEMEMOYN;m;x");
		hm.put("WDRAVLBAL_13", "HTP_QRY_WDRAVLBAL_13;m;x");
		hm.put("PDCD", "HTP_QRY_PDCD;m;x");
		hm.put("EDDT", "HTP_QRY_EDDT;m;x");
		hm.put("STDT", "HTP_QRY_STDT;m;x");
		hm.put("TSRGSYN_1", "HTP_QRY_TSRGSYN_1;m;x");
		hm.put("reTry", "HTP_QRY_RETRY;m;x");
		hm.put("afudata", "HTP_QRY_AFUDATA;m;x");
		hm.put("privateIpUdata", "HTP_QRY_PRIVATEIPUDATA;m;x");
		hm.put("COST_CD", "HTP_QRY_COST_CD;m;x");
		hm.put("DOTCOM_MEMO_YN", "HTP_QRY_DOTCOM_MEMO_YN;m;x");
		hm.put("WDR_ACNO_MEMO_GUBUN", "HTP_QRY_WDR_ACNO_MEMO_GUBUN;m;x");
		hm.put("PBOK_KD", "HTP_QRY_PBOK_KD;m;x");
		hm.put("PRN_NO_13", "HTP_QRY_PRN_NO_13;m;x");
		hm.put("ACT_PWNO_USE_YN", "HTP_QRY_ACT_PWNO_USE_YN;m;x");
		hm.put("GUBUN", "HTP_QRY_GUBUN;m;x");
		hm.put("ACTNO_15", "HTP_QRY_ACTNO_15;m;e");
		hm.put("FEXEM_YN", "HTP_QRY_FEXEM_YN;m;x");
		hm.put("FAVOR_ACCTNO_CHK", "HTP_QRY_FAVOR_ACCTNO_CHK;m;x");
		hm.put("PROCDIV_2", "HTP_QRY_PROCDIV_2;m;x");
		hm.put("TEL_14", "HTP_QRY_TEL_14;m;f");
		hm.put("WDR_ACNO_TEXT", "HTP_QRY_WDR_ACNO_TEXT;m;x");
		hm.put("isCertLoginYN", "HTP_QRY_ISCERTLOGINYN;m;x");
		hm.put("CT_BAL", "HTP_QRY_CT_BAL;m;x");
		hm.put("PTN_PBOK_PRNG_TXT", "HTP_QRY_PTN_PBOK_PRNG_TXT;m;x");
		hm.put("HP_NO_1", "HTP_QRY_HP_NO_1;m;f");
		hm.put("TAX_CD", "HTP_QRY_TAX_CD;m;x");
		hm.put("END_DATE", "HTP_QRY_END_DATE;m;x");
		hm.put("CUR_CD_3", "HTP_QRY_CUR_CD_3;m;x");
		hm.put("SeqNO", "HTP_QRY_SEQNO;m;x");
		hm.put("HP_NO_3", "HTP_QRY_HP_NO_3;m;f");
		hm.put("HP_NO_2", "HTP_QRY_HP_NO_2;m;f");
		hm.put("INQ_YEAR", "HTP_QRY_INQ_YEAR;m;x");
		hm.put("INQ_MONTH", "HTP_QRY_INQ_MONTH;m;x");
		hm.put("START_DATE", "HTP_QRY_START_DATE;m;x");
		hm.put("INQ_STA_NO", "HTP_QRY_INQ_STA_NO;m;x");
		hm.put("tabFlag", "HTP_QRY_TABFLAG;m;x");
		hm.put("otherAcc", "HTP_QRY_OTHERACC;m;e");
		hm.put("INQ_SEQ_DIS", "HTP_QRY_INQ_SEQ_DIS;m;x");
		hm.put("sort", "HTP_QRY_SORT;m;x");
		hm.put("isOnlySearchTxt", "HTP_QRY_ISONLYSEARCHTXT;m;x");
		hm.put("IsMST", "HTP_QRY_ISMST;m;x");
		hm.put("START_DATEY", "HTP_QRY_START_DATEY;m;x");
		hm.put("START_DATEM", "HTP_QRY_START_DATEM;m;x");
		hm.put("START_DATED", "HTP_QRY_START_DATED;m;x");
		hm.put("step", "HTP_QRY_STEP;m;x");
		hm.put("TRNNO_3", "HTP_QRY_TRNNO_3;m;x");
		hm.put("TOT_DPBAL_13", "HTP_QRY_TOT_DPBAL_13;m;x");
		hm.put("TOT_LOANBAL_13", "HTP_QRY_TOT_LOANBAL_13;m;x");
		hm.put("END_DATED", "HTP_QRY_END_DATED;m;x");
		hm.put("END_DATEY", "HTP_QRY_END_DATEY;m;x");
		hm.put("END_DATEM", "HTP_QRY_END_DATEM;m;x");
		hm.put("Term", "HTP_QRY_TERM;m;x");
		hm.put("sorder", "HTP_QRY_SORDER;m;x");
		hm.put("check_seqno", "HTP_QRY_CHECK_SEQNO;m;x");
		hm.put("isFirstInqSvr", "HTP_QRY_ISFIRSTINQSVR;m;x");
		hm.put("INQ_TGT_DIS", "HTP_QRY_INQ_TGT_DIS;m;x");
		hm.put("EDDTM", "HTP_QRY_EDDTM;m;x");
		hm.put("STDTD", "HTP_QRY_STDTD;m;x");
		hm.put("STDTM", "HTP_QRY_STDTM;m;x");
		hm.put("STDTY", "HTP_QRY_STDTY;m;x");
		hm.put("EDDTY", "HTP_QRY_EDDTY;m;x");
		hm.put("EDDTD", "HTP_QRY_EDDTD;m;x");
		hm.put("check_date", "HTP_QRY_CHECK_DATE;m;x");
		hm.put("FXMRK_YN", "HTP_QRY_FXMRK_YN;m;x");
		hm.put("isOnlySwing", "HTP_QRY_ISONLYSWING;m;x");
		hm.put("sort1", "HTP_QRY_SORT1;m;x");
		hm.put("divTemp", "HTP_QRY_DIVTEMP;m;x");
		hm.put("RNPE_FNM", "HTP_QRY_RNPE_FNM;m;k");
		hm.put("CTIN_INQ_TRNDT", "HTP_QRY_CTIN_INQ_TRNDT;m;x");
		hm.put("CTIN_INQ_TRNO", "HTP_QRY_CTIN_INQ_TRNO;m;x");
		hm.put("girdDrawYn", "HTP_QRY_GIRDDRAWYN;m;x");
		hm.put("DAT_CNT", "HTP_QRY_DAT_CNT;m;x");
		hm.put("RSV_DT", "HTP_QRY_RSV_DT;m;x");
		hm.put("FEE", "HTP_QRY_FEE;m;x");
		hm.put("WDR_ACNO_TEXT_MEMO", "HTP_QRY_WDR_ACNO_TEXT_MEMO;m;x");
		hm.put("PRINT_DATA", "HTP_QRY_PRINT_DATA;m;x");
		hm.put("INQ_TGT_DIS_1", "HTP_QRY_INQ_TGT_DIS_1;m;x");
		hm.put("TRN_SRNO", "HTP_QRY_TRN_SRNO;m;x");
		hm.put("FAVOR_HP_NO", "HTP_QRY_FAVOR_HP_NO;m;f");
		hm.put("WBF_DUP_CHECK_KEY", "HTP_QRY_WBF_DUP_CHECK_KEY;m;x");
		hm.put("SIGN_KEYS", "HTP_QRY_SIGN_KEYS;m;x");
		hm.put("TRN_DT", "HTP_QRY_TRN_DT;m;x");
		hm.put("TRN_TM", "HTP_QRY_TRN_TM;m;x");
		hm.put("FAVOR_EML", "HTP_QRY_FAVOR_EML;m;f");
		hm.put("_RANDOM_NUM", "HTP_QRY__RANDOM_NUM;m;x");
		hm.put("INQ_SEQ_DIS_1", "HTP_QRY_INQ_SEQ_DIS_1;m;x");
		hm.put("ACT_PWNO_10", "HTP_QRY_ACT_PWNO_10;m;f");
		hm.put("isNotData", "HTP_QRY_ISNOTDATA;m;x");
		hm.put("TRNO", "HTP_QRY_TRNO;m;x");
		hm.put("TRN_INQ_MTD", "HTP_QRY_TRN_INQ_MTD;m;x");
		hm.put("INQ_STA_DD", "HTP_QRY_INQ_STA_DD;m;x");
		hm.put("WDR_ACNO_MEMO", "HTP_QRY_WDR_ACNO_MEMO;m;x");
		hm.put("DPPE_NM", "HTP_QRY_DPPE_NM;m;k");
		hm.put("isCodeInq", "HTP_QRY_ISCODEINQ;m;x");
		hm.put("P_RCVCNT", "HTP_QRY_P_RCVCNT;m;x");
		hm.put("CLNM_NO_ADD_SBJ", "HTP_QRY_CLNM_NO_ADD_SBJ;m;x");
		hm.put("TOTAL_CNT", "HTP_QRY_TOTAL_CNT;m;x");
		hm.put("NEXT_YN_HOST", "HTP_QRY_NEXT_YN_HOST;m;x");
		hm.put("TRN_TXT", "HTP_QRY_TRN_TXT;m;k");
		hm.put("RCV_AM", "HTP_QRY_RCV_AM;m;x");
		hm.put("RSTT_YN", "HTP_QRY_RSTT_YN;m;x");
		hm.put("PAY_AM", "HTP_QRY_PAY_AM;m;x");
		hm.put("isNoDate", "HTP_QRY_ISNODATE;m;x");
		hm.put("gridData", "HTP_QRY_GRIDDATA;m;x");
		hm.put("DIV_TRAN_GB", "HTP_QRY_DIV_TRAN_GB;m;x");
		hm.put("DIV_TRAN_CNT", "HTP_QRY_DIV_TRAN_CNT;m;x");
		hm.put("RECV_CNT", "HTP_QRY_RECV_CNT;m;x");
		hm.put("WOORI_YN", "HTP_QRY_WOORI_YN;m;x");
		hm.put("OBR_AM", "HTP_QRY_OBR_AM;m;x");
		hm.put("TR_DIS", "HTP_QRY_TR_DIS;m;x");
		hm.put("BRANCH", "HTP_QRY_BRANCH;m;x");
		hm.put("ExtUseYN", "HTP_QRY_EXTUSEYN;m;x");
		hm.put("INQ_TYPE_DIS_1", "HTP_QRY_INQ_TYPE_DIS_1;m;x");
		hm.put("PAYAVL_AM", "HTP_QRY_PAYAVL_AM;m;x");
		hm.put("PBOK_LN_LMT_AM_18", "HTP_QRY_PBOK_LN_LMT_AM_18;m;x");
		hm.put("TRN_MSG", "HTP_QRY_TRN_MSG;m;x");
		hm.put("BL_AM", "HTP_QRY_BL_AM;m;x");
		hm.put("AccNO", "HTP_QRY_ACCNO;m;e");
		hm.put("_ROOT_CHECK_RESULT", "HTP_QRY__ROOT_CHECK_RESULT;m;x");
		hm.put("_ROOT_CHECK_RESULT_CODE", "HTP_QRY__ROOT_CHECK_RESULT_CODE;m;x");
		hm.put("INQ_DT_BSDT_10", "HTP_QRY_INQ_DT_BSDT_10;m;x");
		hm.put("ACTPWNO_4", "HTP_QRY_ACTPWNO_4;m;f");
		hm.put("PSNBIZPENO_7", "HTP_QRY_PSNBIZPENO_7;m;x");
		hm.put("loginType", "HTP_QRY_LOGINTYPE;m;x");
		hm.put("DIV", "HTP_QRY_DIV;m;x");
		hm.put("ACTNO_14", "HTP_QRY_ACTNO_14;m;e");
		hm.put("LN_KD", "HTP_QRY_LN_KD;m;x");
		hm.put("E2E_FLAG", "HTP_QRY_E2E_FLAG;m;x");
		hm.put("TLBNK_UTZPE_IDF_NO", "HTP_QRY_TLBNK_UTZPE_IDF_NO;m;x");
		hm.put("custName", "HTP_QRY_CUSTNAME;m;k");
		hm.put("PAY_AVL_AM", "HTP_QRY_PAY_AVL_AM;m;x");
		hm.put("ONE_PRC_CN_3", "HTP_QRY_ONE_PRC_CN_3;m;e");
		hm.put("RAP_DSCD", "HTP_QRY_RAP_DSCD;m;x");
		hm.put("INQ_STA_DTD", "HTP_QRY_INQ_STA_DTD;m;x");
		hm.put("INQ_STA_DTM", "HTP_QRY_INQ_STA_DTM;m;x");
		hm.put("INQ_STA_DTY", "HTP_QRY_INQ_STA_DTY;m;x");
		hm.put("INQ_END_DTD", "HTP_QRY_INQ_END_DTD;m;x");
		hm.put("INQ_END_DTM", "HTP_QRY_INQ_END_DTM;m;x");
		hm.put("INQ_END_DTY", "HTP_QRY_INQ_END_DTY;m;x");
		hm.put("HP_NO", "HTP_QRY_HP_NO;m;f");
		hm.put("CUR_3", "HTP_QRY_CUR_3;m;x");
		hm.put("MEMBERS_ROW", "HTP_QRY_MEMBERS_ROW;m;x");
		hm.put("checkph", "HTP_QRY_CHECKPH;m;x");
		hm.put("chk_mobile", "HTP_QRY_CHK_MOBILE;m;x");
		hm.put("WDRACTNO_15", "HTP_QRY_WDRACTNO_15;m;e");
		hm.put("RSVEXEDY_8", "HTP_QRY_RSVEXEDY_8;m;x");
		hm.put("RCVNM", "HTP_QRY_RCVNM;m;x");
		hm.put("CTIN_TRN_SRNO", "HTP_QRY_CTIN_TRN_SRNO;m;x");
		hm.put("CTIN_DAT_OUP_YN", "HTP_QRY_CTIN_DAT_OUP_YN;m;x");
		hm.put("RCPENM_20", "HTP_QRY_RCPENM_20;m;k");
		hm.put("CNTR_CPRS", "HTP_QRY_CNTR_CPRS;m;x");
		hm.put("TRBK_GICD", "HTP_QRY_TRBK_GICD;m;x");
		hm.put("method_cert", "HTP_QRY_METHOD_CERT;m;x");
		hm.put("transkey_hMac_Tk_pup02", "HTP_QRY_TRANSKEY_HMAC_TK_PUP02;m;x");
		hm.put("transkey_Tk_pup02", "HTP_QRY_TRANSKEY_TK_PUP02;m;x");
		hm.put("CertSendReqCNTAN", "HTP_QRY_CERTSENDREQCNTAN;m;x");
		hm.put("CERT_DIS", "HTP_QRY_CERT_DIS;m;x");
		hm.put("CertSendReqCNTIOS", "HTP_QRY_CERTSENDREQCNTIOS;m;x");
		hm.put("ELTPAYNO_19", "HTP_QRY_ELTPAYNO_19;m;e");
		hm.put("IP_SEQ", "HTP_QRY_IP_SEQ;m;x");
		hm.put("TOTAL_CNT_2", "HTP_QRY_TOTAL_CNT_2;m;x");
		hm.put("MON_RENT_YN", "HTP_QRY_MON_RENT_YN;m;x");
		hm.put("NRSD_6_1", "HTP_QRY_NRSD_6_1;m;x");
		hm.put("NRSD_6_2", "HTP_QRY_NRSD_6_2;m;x");
		hm.put("RQ_STL_NO_4", "HTP_QRY_RQ_STL_NO_4;m;x");
		hm.put("IN_CLIENT_NAME_22", "HTP_QRY_IN_CLIENT_NAME_22;m;k");
		hm.put("FEE_5", "HTP_QRY_FEE_5;m;x");
		hm.put("lateTransDetail", "HTP_QRY_LATETRANSDETAIL;m;x");
		hm.put("CERT_SIGNED_USE", "HTP_QRY_CERT_SIGNED_USE;m;x");
		hm.put("MEMBERS_INQ", "HTP_QRY_MEMBERS_INQ;m;x");
		hm.put("MEMBERS_DIS_FEE", "HTP_QRY_MEMBERS_DIS_FEE;m;x");
		hm.put("CNTR_IST", "HTP_QRY_CNTR_IST;m;x");
		hm.put("CNTR_ICHE_YN", "HTP_QRY_CNTR_ICHE_YN;m;x");
		hm.put("CNTR_ACNO", "HTP_QRY_CNTR_ACNO;m;e");
		hm.put("CNTR_AM", "HTP_QRY_CNTR_AM;m;x");
		hm.put("RPS_PEN_YN", "HTP_QRY_RPS_PEN_YN;m;x");
		hm.put("IS_CHD_MSG_TS", "HTP_QRY_IS_CHD_MSG_TS;m;x");
		hm.put("WDR_NOTI_REG", "HTP_QRY_WDR_NOTI_REG;m;x");
		hm.put("WDR_NOTI_INOT_SMS_FR_TM", "HTP_QRY_WDR_NOTI_INOT_SMS_FR_TM;m;x");
		hm.put("COUNT_TRANS_FER_RES", "HTP_QRY_COUNT_TRANS_FER_RES;m;x");
		hm.put("COUNT_SUPPROT", "HTP_QRY_COUNT_SUPPROT;m;x");
		hm.put("WDR_NOTI_INOT_SMS_TO_TM", "HTP_QRY_WDR_NOTI_INOT_SMS_TO_TM;m;x");
		hm.put("WDR_NOTI_AUTO_YN", "HTP_QRY_WDR_NOTI_AUTO_YN;m;x");
		hm.put("WDR_NOTI_MONEY_INOUT", "HTP_QRY_WDR_NOTI_MONEY_INOUT;m;x");
		hm.put("WDR_NOTI_AMT_VIEW_YN", "HTP_QRY_WDR_NOTI_AMT_VIEW_YN;m;x");
		hm.put("COUNT_TRANS_FER", "HTP_QRY_COUNT_TRANS_FER;m;x");
		hm.put("WDR_NOTI_SEND_AMT_SLT", "HTP_QRY_WDR_NOTI_SEND_AMT_SLT;m;x");
		hm.put("WDR_NOTI_HP_NO1_12", "HTP_QRY_WDR_NOTI_HP_NO1_12;m;x");
		hm.put("WDR_NOTI_WDR_ACCT", "HTP_QRY_WDR_NOTI_WDR_ACCT;m;e");
		hm.put("WDR_NOTI_SEND_AMT", "HTP_QRY_WDR_NOTI_SEND_AMT;m;f");
		hm.put("lateTransTimetxt", "HTP_QRY_LATETRANSTIMETXT;m;x");
		hm.put("FEE_RCVCNT", "HTP_QRY_FEE_RCVCNT;m;x");
		hm.put("feeInqYN", "HTP_QRY_FEEINQYN;m;x");
		hm.put("MEMBERS_GBN", "HTP_QRY_MEMBERS_GBN;m;x");
		hm.put("TS_SUMTRANSFERRESAMT", "HTP_QRY_TS_SUMTRANSFERRESAMT;m;x");
		hm.put("favFavSize", "HTP_QRY_FAVFAVSIZE;m;x");
		hm.put("DanGi_YN", "HTP_QRY_DANGI_YN;m;x");
		hm.put("RCVBNKCD_2", "HTP_QRY_RCVBNKCD_2;m;x");
		hm.put("STL_DT_8", "HTP_QRY_STL_DT_8;m;x");
		hm.put("PBOKMNTNHIS_20", "HTP_QRY_PBOKMNTNHIS_20;m;x");
		hm.put("APV_APL_DIS", "HTP_QRY_APV_APL_DIS;m;x");
		hm.put("MMDA_YN", "HTP_QRY_MMDA_YN;m;x");
		hm.put("SER_NO_3", "HTP_QRY_SER_NO_3;m;x");
		hm.put("ACT_BL_18", "HTP_QRY_ACT_BL_18;m;x");
		hm.put("LOGIN_GBN", "HTP_QRY_LOGIN_GBN;m;x");
		hm.put("TRNAM_13", "HTP_QRY_TRNAM_13;m;x");
		hm.put("Accnick", "HTP_QRY_ACCNICK;m;x");
		hm.put("PBOK_KD_4", "HTP_QRY_PBOK_KD_4;m;x");
		hm.put("MBRCO_MBR_NO_15", "HTP_QRY_MBRCO_MBR_NO_15;m;x");
		hm.put("LN_MTD", "HTP_QRY_LN_MTD;m;x");
		hm.put("NTRNN_ACT_YN", "HTP_QRY_NTRNN_ACT_YN;m;x");
		hm.put("SMT_YN", "HTP_QRY_SMT_YN;m;x");
		hm.put("MMDA_INT_RCV_ACNO", "HTP_QRY_MMDA_INT_RCV_ACNO;m;e");
		hm.put("LOGIN_TYPE", "HTP_QRY_LOGIN_TYPE;m;x");
		hm.put("TODAY", "HTP_QRY_TODAY;m;x");
		hm.put("LIST_SER_NO_3", "HTP_QRY_LIST_SER_NO_3;m;x");
		hm.put("CUR_LIST_SER_NO_3", "HTP_QRY_CUR_LIST_SER_NO_3;m;x");
		hm.put("radioClick", "HTP_QRY_RADIOCLICK;m;x");
		hm.put("tempTODAY", "HTP_QRY_TEMPTODAY;m;x");
		hm.put("isFirst", "HTP_QRY_ISFIRST;m;x");
		hm.put("CLDOC_SRNO_2", "HTP_QRY_CLDOC_SRNO_2;m;x");
		hm.put("logout", "HTP_QRY_LOGOUT;m;x");
		hm.put("ITG_RQ_STL_NO_4", "HTP_QRY_ITG_RQ_STL_NO_4;m;x");
		hm.put("SEQ_NO_3", "HTP_QRY_SEQ_NO_3;m;x");
		hm.put("INQSTADY_8", "HTP_QRY_INQSTADY_8;m;x");
		hm.put("INQENDDY_8", "HTP_QRY_INQENDDY_8;m;x");
		hm.put("URL", "HTP_QRY_URL;m;x");
		hm.put("wdata", "HTP_QRY_WDATA;m;x");
		hm.put("ndata", "HTP_QRY_NDATA;m;x");
		hm.put("smart_popup", "HTP_QRY_SMART_POPUP;m;x");
		hm.put("Tk_ACT_PWNO_check", "HTP_QRY_TK_ACT_PWNO_CHECK;m;x");
		hm.put("transkey_Tk_ACT_PWNO", "HTP_QRY_TRANSKEY_TK_ACT_PWNO;m;f");
		hm.put("transkey_hMac_Tk_ACT_PWNO", "HTP_QRY_TRANSKEY_HMAC_TK_ACT_PWNO;m;f");
		hm.put("USER_SRNO", "HTP_QRY_USER_SRNO;m;x");
		hm.put("FND_CAUTION_LMS", "HTP_QRY_FND_CAUTION_LMS;m;x");
		hm.put("sort_group", "HTP_QRY_SORT_GROUP;m;x");
		hm.put("IN_BANK_CD_3", "HTP_QRY_IN_BANK_CD_3;m;x");
		hm.put("IN_AMOUNT_13", "HTP_QRY_IN_AMOUNT_13;m;x");
		hm.put("LCL", "HTP_QRY_LCL;m;x");
		hm.put("scrGubun", "HTP_QRY_SCRGUBUN;m;x");
		hm.put("pop_yn", "HTP_QRY_POP_YN;m;x");
		hm.put("ACCT_15", "HTP_QRY_ACCT_15;m;e");
		hm.put("sw", "HTP_QRY_SW;m;x");
		hm.put("E2E_RCV_ACNO", "HTP_QRY_E2E_RCV_ACNO;m;e");
		hm.put("Tk_pup02_check", "HTP_QRY_TK_PUP02_CHECK;m;x");
		hm.put("SERIALNO", "HTP_QRY_SERIALNO;m;x");
		hm.put("RCV_BKNM", "HTP_QRY_RCV_BKNM;m;x");
		hm.put("ACT_PWNO__E2E__", "HTP_QRY_ACT_PWNO__E2E__;m;f");
		hm.put("RCVACTNO_15", "HTP_QRY_RCVACTNO_15;m;e");
		hm.put("MO_ACNO", "HTP_QRY_MO_ACNO;m;e");
		hm.put("FX_RCV_ACNO", "HTP_QRY_FX_RCV_ACNO;m;e");
		hm.put("TranFrom", "HTP_QRY_TRANFROM;m;x");
		hm.put("Tk_PWD_checkbox", "HTP_QRY_TK_PWD_CHECKBOX;m;x");
		hm.put("lst_trn_dt", "HTP_QRY_LST_TRN_DT;m;x");
		hm.put("addDays", "HTP_QRY_ADDDAYS;m;x");
		hm.put("CLMNYNO_16", "HTP_QRY_CLMNYNO_16;m;x");
		hm.put("BFTRBL_13", "HTP_QRY_BFTRBL_13;m;x");
		hm.put("INQ_SQL_DIS_1", "HTP_QRY_INQ_SQL_DIS_1;m;x");
		hm.put("APV_YN", "HTP_QRY_APV_YN;m;x");
		hm.put("dis", "HTP_QRY_DIS;m;x");
		hm.put("NEXT_ROWS", "HTP_QRY_NEXT_ROWS;m;x");
		hm.put("E2E_EXEC_DT", "HTP_QRY_E2E_EXEC_DT;m;x");
		hm.put("RCVBNKNM_2", "HTP_QRY_RCVBNKNM_2;m;x");
		hm.put("CCD_SELECT_CDNO_IDX", "HTP_QRY_CCD_SELECT_CDNO_IDX;m;e");
		hm.put("RCV_BKCD_1", "HTP_QRY_RCV_BKCD_1;m;x");
		hm.put("RCV_BKCD_2", "HTP_QRY_RCV_BKCD_2;m;x");
		hm.put("Tk_ELTPAYNO_19_check", "HTP_QRY_TK_ELTPAYNO_19_CHECK;m;x");
		hm.put("ELTPAYNO_19_LOCAL", "HTP_QRY_ELTPAYNO_19_LOCAL;m;e");
		hm.put("transkey_Tk_ELTPAYNO_19", "HTP_QRY_TRANSKEY_TK_ELTPAYNO_19;m;x");
		hm.put("transkey_hMac_Tk_ELTPAYNO_19", "HTP_QRY_TRANSKEY_HMAC_TK_ELTPAYNO_19;m;x");
		hm.put("FNDTS_DIS", "HTP_QRY_FNDTS_DIS;m;x");
		hm.put("returnURL", "HTP_QRY_RETURNURL;m;x");
		hm.put("CUR_DATE", "HTP_QRY_CUR_DATE;m;x");
		hm.put("INQ_SQNO_3", "HTP_QRY_INQ_SQNO_3;m;x");
		hm.put("POPUP_PRC_DSCD_1", "HTP_QRY_POPUP_PRC_DSCD_1;m;x");
		hm.put("SelMonChoice", "HTP_QRY_SELMONCHOICE;m;x");
		hm.put("INQSTADY_8Y", "HTP_QRY_INQSTADY_8Y;m;x");
		hm.put("INQENDDY_8Y", "HTP_QRY_INQENDDY_8Y;m;x");
		hm.put("INQSTADY_8M", "HTP_QRY_INQSTADY_8M;m;x");
		hm.put("INQSTADY_8D", "HTP_QRY_INQSTADY_8D;m;x");
		hm.put("INQENDDY_8M", "HTP_QRY_INQENDDY_8M;m;x");
		hm.put("INQENDDY_8D", "HTP_QRY_INQENDDY_8D;m;x");
		hm.put("FEE_AM", "HTP_QRY_FEE_AM;m;x");
		hm.put("CCD_USE_RGN", "HTP_QRY_CCD_USE_RGN;m;x");
		hm.put("CCD_BANK_DIS", "HTP_QRY_CCD_BANK_DIS;m;x");
		hm.put("CCD_PERIOD", "HTP_QRY_CCD_PERIOD;m;x");
		hm.put("CCD_ISINQUIRED", "HTP_QRY_CCD_ISINQUIRED;m;x");
		hm.put("tempDate", "HTP_QRY_TEMPDATE;m;x");
		hm.put("IS_DETAIL_PRINT", "HTP_QRY_IS_DETAIL_PRINT;m;x");
		hm.put("before12month", "HTP_QRY_BEFORE12MONTH;m;x");
		hm.put("CCD_REQ_SIZE_IDX", "HTP_QRY_CCD_REQ_SIZE_IDX;m;x");
		hm.put("CCD_INQ_DIS", "HTP_QRY_CCD_INQ_DIS;m;x");
		hm.put("CCD_STL_BK_CD", "HTP_QRY_CCD_STL_BK_CD;m;x");
		hm.put("CCD_STL_USE_ACT", "HTP_QRY_CCD_STL_USE_ACT;m;x");
		hm.put("CCD_REQ_SIZE_1", "HTP_QRY_CCD_REQ_SIZE_1;m;x");
		hm.put("submit_gubun", "HTP_QRY_SUBMIT_GUBUN;m;x");
		hm.put("TS_BEFORETRANBAL", "HTP_QRY_TS_BEFORETRANBAL;m;x");
		hm.put("TS_SUMTRANSFERAMT", "HTP_QRY_TS_SUMTRANSFERAMT;m;x");
		hm.put("TS_SUMTRANSFERFEE", "HTP_QRY_TS_SUMTRANSFERFEE;m;x");
		hm.put("DSCD", "HTP_QRY_DSCD;m;x");
		hm.put("ELTPAYNO_19__E2E__", "HTP_QRY_ELTPAYNO_19__E2E__;m;e");
		hm.put("GROUP_CD", "HTP_QRY_GROUP_CD;m;x");
		hm.put("nextBtnYn", "HTP_QRY_NEXTBTNYN;m;x");
		hm.put("NEXT_SER_NO_3", "HTP_QRY_NEXT_SER_NO_3;m;x");
		hm.put("PRE_SER_NO_3", "HTP_QRY_PRE_SER_NO_3;m;x");
		hm.put("ScrtyWay", "HTP_QRY_SCRTYWAY;m;x");
		hm.put("TLM_NO", "HTP_QRY_TLM_NO;m;x");
		hm.put("BOK_TRN_DSCD", "HTP_QRY_BOK_TRN_DSCD;m;x");
		hm.put("KORBNK_R", "HTP_QRY_KORBNK_R;m;x");
		hm.put("Tk_pup02_checkbox", "HTP_QRY_TK_PUP02_CHECKBOX;m;x");
		hm.put("REQ_SEQ", "HTP_QRY_REQ_SEQ;m;x");
		hm.put("DELETE_NO", "HTP_QRY_DELETE_NO;m;x");
		hm.put("DELETE_SEQ", "HTP_QRY_DELETE_SEQ;m;x");
		hm.put("MEMBERS_POINT_AMT", "HTP_QRY_MEMBERS_POINT_AMT;m;x");
		hm.put("MEMBERS_COUNT", "HTP_QRY_MEMBERS_COUNT;m;x");
		hm.put("MEMBERS_SPC_CNT", "HTP_QRY_MEMBERS_SPC_CNT;m;x");
		hm.put("WOORI_BONUS_SPC_CNT", "HTP_QRY_WOORI_BONUS_SPC_CNT;m;x");
		hm.put("MEMBERS_CON_SPC_CNT", "HTP_QRY_MEMBERS_CON_SPC_CNT;m;x");
		hm.put("WOORI_BONUS_GRADE", "HTP_QRY_WOORI_BONUS_GRADE;m;x");
		hm.put("MEMBERS_FEE", "HTP_QRY_MEMBERS_FEE;m;x");
		hm.put("prdNm", "HTP_QRY_PRDNM;m;x");
		hm.put("USER_TYPE", "HTP_QRY_USER_TYPE;m;x");
		hm.put("CD_NO_16", "HTP_QRY_CD_NO_16;m;x");
		hm.put("btn_acct_hidden", "HTP_QRY_BTN_ACCT_HIDDEN;m;x");
		hm.put("prdCd", "HTP_QRY_PRDCD;m;x");
		hm.put("e_mail", "HTP_QRY_E_MAIL;m;f");
		hm.put("cdFm", "HTP_QRY_CDFM;m;e");
		hm.put("BKCD", "HTP_QRY_BKCD;m;x");
		hm.put("CRT_NO", "HTP_QRY_CRT_NO;m;x");
		hm.put("LN_ACNO_15", "HTP_QRY_LN_ACNO_15;m;e");
		hm.put("PLM_PDCD", "HTP_QRY_PLM_PDCD;m;x");
		hm.put("PRD_CD_9", "HTP_QRY_PRD_CD_9;m;x");
		hm.put("APVRQ_SEQ", "HTP_QRY_APVRQ_SEQ;m;x");
		hm.put("HpNoAuth", "HTP_QRY_HPNOAUTH;m;x");
		hm.put("ClipID", "HTP_QRY_CLIPID;m;x");
		hm.put("WIBEE_MONEY_YN", "HTP_QRY_WIBEE_MONEY_YN;m;x");
		hm.put("TRAN_INFO", "HTP_QRY_TRAN_INFO;m;x");
		hm.put("transkey_hMac_Tk_ACTPWNO_8", "HTP_QRY_TRANSKEY_HMAC_TK_ACTPWNO_8;m;f");
		hm.put("transkey_Tk_ACTPWNO_8", "HTP_QRY_TRANSKEY_TK_ACTPWNO_8;m;f");
		hm.put("Tk_ACTPWNO_8_check", "HTP_QRY_TK_ACTPWNO_8_CHECK;m;f");
		hm.put("ACT_PWNO_USG_YN", "HTP_QRY_ACT_PWNO_USG_YN;m;x");
		hm.put("INT_AM_11", "HTP_QRY_INT_AM_11;m;x");
		hm.put("AUTH_REASON", "HTP_QRY_AUTH_REASON;m;x");
		hm.put("y", "HTP_QRY_Y;m;x");
		hm.put("x", "HTP_QRY_X;m;x");
		hm.put("authUsedPhoneNo", "HTP_QRY_AUTHUSEDPHONENO;m;f");
		hm.put("transkey_Tk_pup03", "HTP_QRY_TRANSKEY_TK_PUP03;m;x");
		hm.put("transkey_hMac_Tk_pup03", "HTP_QRY_TRANSKEY_HMAC_TK_PUP03;m;x");
		hm.put("DPPENm_20", "HTP_QRY_DPPENM_20;m;k");
		hm.put("TAX_CD_TXT", "HTP_QRY_TAX_CD_TXT;m;x");
		hm.put("COST_CD_TXT", "HTP_QRY_COST_CD_TXT;m;x");
		hm.put("TS_CountTransFerRes", "HTP_QRY_TS_COUNTTRANSFERRES;m;x");
		hm.put("ediString", "HTP_QRY_EDISTRING;m;x");
		hm.put("ediicheday", "HTP_QRY_EDIICHEDAY;m;x");
		hm.put("edinum", "HTP_QRY_EDINUM;m;x");
		hm.put("ediresult", "HTP_QRY_EDIRESULT;m;x");
		hm.put("edicode", "HTP_QRY_EDICODE;m;x");
		hm.put("editrcode", "HTP_QRY_EDITRCODE;m;x");
		hm.put("edigumak", "HTP_QRY_EDIGUMAK;m;x");
		hm.put("GUNBUN", "HTP_QRY_GUNBUN;m;x");
		hm.put("BS_SIGNED_DATA", "HTP_QRY_BS_SIGNED_DATA;m;x");
		hm.put("BS_RANDOM_NUM", "HTP_QRY_BS_RANDOM_NUM;m;x");
		hm.put("ACTPWNO_8__E2E__", "HTP_QRY_ACTPWNO_8__E2E__;m;f");
		hm.put("WDR_PBOKMNTNHIS_20", "HTP_QRY_WDR_PBOKMNTNHIS_20;m;x");
		hm.put("E2E_RCVACTNO_15", "HTP_QRY_E2E_RCVACTNO_15;m;e");
		hm.put("clientSeq", "HTP_QRY_CLIENTSEQ;m;x");
		hm.put("APVRQ_DT", "HTP_QRY_APVRQ_DT;m;x");
		hm.put("strGoUrl", "HTP_QRY_STRGOURL;m;x");
		hm.put("DUP_CERT_YN", "HTP_QRY_DUP_CERT_YN;m;x");
		hm.put("ACT_BAL", "HTP_QRY_ACT_BAL;m;x");
		hm.put("q", "HTP_QRY_Q;m;x");
		hm.put("clientid", "HTP_QRY_CLIENTID;m;x");
		hm.put("balanceShortYN", "HTP_QRY_BALANCESHORTYN;m;x");
		hm.put("uid", "HTP_QRY_UID;m;x");
		hm.put("RNNM_NO", "HTP_QRY_RNNM_NO;m;x");
		hm.put("P_WDRACTNO_15", "HTP_QRY_P_WDRACTNO_15;m;e");
		hm.put("DELAY_TS_GUBUN", "HTP_QRY_DELAY_TS_GUBUN;m;x");
		hm.put("SCRT_MNS", "HTP_QRY_SCRT_MNS;m;x");
		hm.put("popIndex", "HTP_QRY_POPINDEX;m;x");
		hm.put("PRD_NM", "HTP_QRY_PRD_NM;m;x");
		hm.put("otc", "HTP_QRY_OTC;m;x");
		hm.put("__PAGE_TITLE__", "HTP_QRY___PAGE_TITLE__;m;x");
		hm.put("APP_YN", "HTP_QRY_APP_YN;m;x");
		hm.put("TS_SUMSUPPRTAMT", "HTP_QRY_TS_SUMSUPPRTAMT;m;x");
		hm.put("OTP_KIND", "HTP_QRY_OTP_KIND;m;x");
		hm.put("INQ_DIS", "HTP_QRY_INQ_DIS;m;x");
		hm.put("accInfoLst", "HTP_QRY_ACCINFOLST;d;e");
		hm.put("objectCLSID", "HTP_QRY_OBJECTCLSID;m;x");
		hm.put("resultMessage", "HTP_QRY_RESULTMESSAGE;m;x");
		hm.put("resultCode", "HTP_QRY_RESULTCODE;m;x");
		hm.put("objectName", "HTP_QRY_OBJECTNAME;m;x");
		hm.put("ctr_msg", "HTP_QRY_CTR_MSG;m;x");
		hm.put("msg", "HTP_QRY_MSG;m;x");
		hm.put("result", "HTP_QRY_RESULT;m;x");
		hm.put("iframeHtmlDataYN", "HTP_QRY_IFRAMEHTMLDATAYN;m;x");
		hm.put("iframeHtmlDataNum", "HTP_QRY_IFRAMEHTMLDATANUM;m;x");
		hm.put("SSN", "HTP_QRY_SSN;m;x");
		hm.put("isEng", "HTP_QRY_ISENG;m;x");
		hm.put("M_ID", "HTP_QRY_M_ID;m;x");
		hm.put("L_ID", "HTP_QRY_L_ID;m;x");
		hm.put("OBK_DIS", "HTP_QRY_OBK_DIS;m;x");
		hm.put("AUTH_MNS", "HTP_QRY_AUTH_MNS;m;x");
		hm.put("SMS_AUTH_USE_YN", "HTP_QRY_SMS_AUTH_USE_YN;m;x");
		hm.put("OTPCARDPSTNO_6", "HTP_QRY_OTPCARDPSTNO_6;m;x");
		hm.put("MBRCO_CD_2", "HTP_QRY_MBRCO_CD_2;m;x");
		hm.put("UMS_TMPL_CD", "HTP_QRY_UMS_TMPL_CD;m;x");
		hm.put("fua_name", "HTP_QRY_FUA_NAME;m;x");
		hm.put("WDR_PBOK_PRNG_TXT", "HTP_QRY_WDR_PBOK_PRNG_TXT;m;x");
		hm.put("TRANSFER_WORK_CD_2", "HTP_QRY_TRANSFER_WORK_CD_2;m;x");
		hm.put("TARGET_SERVICE_20", "HTP_QRY_TARGET_SERVICE_20;m;x");
		hm.put("FEE_AM_11", "HTP_QRY_FEE_AM_11;m;x");
		hm.put("TM_HNDPE_DT_OTP_YN", "HTP_QRY_TM_HNDPE_DT_OTP_YN;m;x");
		hm.put("lang", "HTP_QRY_LANG;m;x");
		hm.put("divType", "HTP_QRY_DIVTYPE;m;x");
		hm.put("rc", "HTP_QRY_RC;m;x");
		hm.put("CLEAR_SESSION_YN", "HTP_QRY_CLEAR_SESSION_YN;m;x");
		hm.put("ADD_AUTH_USE_YN", "HTP_QRY_ADD_AUTH_USE_YN;m;x");
		hm.put("strReUrl", "HTP_QRY_STRREURL;m;x");
		hm.put("OPNDY2_8", "HTP_QRY_OPNDY2_8;m;x");
		hm.put("worktype", "HTP_QRY_WORKTYPE;m;x");
		hm.put("qrystep", "HTP_QRY_QRYSTEP;m;x");
		hm.put("workstep", "HTP_QRY_WORKSTEP;m;x");
		hm.put("targetform", "HTP_QRY_TARGETFORM;m;x");
		hm.put("oneDayDropYn", "HTP_QRY_ONEDAYDROPYN;m;x");
		hm.put("gocontinue", "HTP_QRY_GOCONTINUE;m;x");
		hm.put("workdata", "HTP_QRY_WORKDATA;m;e");
		hm.put("workpageid", "HTP_QRY_WORKPAGEID;m;x");
		hm.put("_BIZCOM_YUIBTIME", "HTP_QRY__BIZCOM_YUIBTIME;m;x");
		hm.put("_BIZCOM_YUIBDATE", "HTP_QRY__BIZCOM_YUIBDATE;m;x");
		hm.put("R_BFTRBL_13", "HTP_QRY_R_BFTRBL_13;m;x");
		hm.put("TRN_BK_GIRO_CD_6", "HTP_QRY_TRN_BK_GIRO_CD_6;m;x");
		hm.put("VIEWTABLENM_22", "HTP_QRY_VIEWTABLENM_22;m;x");
		hm.put("dhs", "HTP_QRY_DHS;m;x");
		hm.put("payload", "HTP_QRY_PAYLOAD;m;x");
		hm.put("prk", "HTP_QRY_PRK;m;x");
		hm.put("dsk", "HTP_QRY_DSK;m;x");
		hm.put("PRD_CD", "HTP_QRY_PRD_CD;m;x");
		hm.put("fn_cb_addAuth", "HTP_QRY_FN_CB_ADDAUTH;m;x");
		hm.put("favAcNm", "HTP_QRY_FAVACNM;m;e");
		hm.put("TRNAM_13_KorAmt", "HTP_QRY_TRNAM_13_KORAMT;m;x");
		hm.put("favBkCd", "HTP_QRY_FAVBKCD;m;x");
		hm.put("Retired_Pay_YN", "HTP_QRY_RETIRED_PAY_YN;m;x");
		hm.put("favBkNm", "HTP_QRY_FAVBKNM;m;x");
		hm.put("favEmail", "HTP_QRY_FAVEMAIL;m;f");
		hm.put("favGrpCd", "HTP_QRY_FAVGRPCD;m;x");
		hm.put("favGrpNm", "HTP_QRY_FAVGRPNM;m;k");
		hm.put("favHpno", "HTP_QRY_FAVHPNO;m;f");
		hm.put("favRcvacNo", "HTP_QRY_FAVRCVACNO;m;e");
		hm.put("favUsNm", "HTP_QRY_FAVUSNM;m;k");
		hm.put("BACKKEY_CALL", "HTP_QRY_BACKKEY_CALL;m;x");
		hm.put("sendActArr", "HTP_QRY_SENDACTARR;m;f");
		hm.put("sendNmArr", "HTP_QRY_SENDNMARR;m;e");
		hm.put("prefee_YN", "HTP_QRY_PREFEE_YN;m;x");
		hm.put("HSM_SKIP", "HTP_QRY_HSM_SKIP;m;x");
		hm.put("POLICY_CHK_SKIP", "HTP_QRY_POLICY_CHK_SKIP;m;e");
		hm.put("KORBNK", "HTP_QRY_KORBNK;m;x");
		hm.put("RCVBNKCD_2_TAX", "HTP_QRY_RCVBNKCD_2_TAX;m;x");
		hm.put("login_page", "HTP_QRY_LOGIN_PAGE;m;x");
		hm.put("__TOP_PAGE_ID", "HTP_QRY___TOP_PAGE_ID;m;x");
		hm.put("prefee", "HTP_QRY_PREFEE;m;x");
		hm.put("APV_NO_LIST", "HTP_QRY_APV_NO_LIST;m;x");
		hm.put("OtpKind", "HTP_QRY_OTPKIND;m;x");
		hm.put("INQ_DIS_1", "HTP_QRY_INQ_DIS_1;m;x");
		hm.put("pushtype", "HTP_QRY_PUSHTYPE;m;x");
		hm.put("TRSEQ", "HTP_QRY_TRSEQ;m;x");
		hm.put("ERROR_CODE", "HTP_QRY_ERROR_CODE;m;x");
		hm.put("TEL_NUM", "HTP_QRY_TEL_NUM;m;f");
		hm.put("ERROR_TR", "HTP_QRY_ERROR_TR;m;x");
		hm.put("LST_XPR_DT", "HTP_QRY_LST_XPR_DT;m;x");
		hm.put("TS_PWNO_NOTRGS_YN_1", "HTP_QRY_TS_PWNO_NOTRGS_YN_1;m;x");
		hm.put("TCH_REQ_CHECK", "HTP_QRY_TCH_REQ_CHECK;m;x");
		hm.put("fromSite", "HTP_QRY_FROMSITE;m;x");
		hm.put("APP_HP_NO", "HTP_QRY_APP_HP_NO;m;f");
		hm.put("RNDNO_NO_6", "HTP_QRY_RNDNO_NO_6;m;x");
		hm.put("INQ_PRN_NO_16", "HTP_QRY_INQ_PRN_NO_16;m;x");
		hm.put("OTPCARDPWNO_6", "HTP_QRY_OTPCARDPWNO_6;m;f");
		hm.put("Tk_OTPCARDPWNO_6_check", "HTP_QRY_TK_OTPCARDPWNO_6_CHECK;m;f");
		hm.put("transkey_Tk_OTPCARDPWNO_6", "HTP_QRY_TRANSKEY_TK_OTPCARDPWNO_6;m;f");
		hm.put("transkey_hMac_Tk_OTPCARDPWNO_6", "HTP_QRY_TRANSKEY_HMAC_TK_OTPCARDPWNO_6;m;f");
		hm.put("_BIZCOM_YUIBLINE", "HTP_QRY__BIZCOM_YUIBLINE;m;x");
		hm.put("P_CURRTYPE", "HTP_QRY_P_CURRTYPE;m;x");
		hm.put("fileName", "HTP_QRY_FILENAME;m;x");
		hm.put("AIM_SRVC", "HTP_QRY_AIM_SRVC;m;x");
		hm.put("PIN_PWNO_6_REALVAL", "HTP_QRY_PIN_PWNO_6_REALVAL;m;f");
		hm.put("APVRQ_ID", "HTP_QRY_APVRQ_ID;m;x");
		hm.put("PWNO_6_REALVAL", "HTP_QRY_PWNO_6_REALVAL;m;f");
		hm.put("PWNO_8_REALVAL", "HTP_QRY_PWNO_8_REALVAL;m;f");
		hm.put("PWNO_6_1_REALVAL", "HTP_QRY_PWNO_6_1_REALVAL;m;f");
		hm.put("PWNO_6_2_REALVAL", "HTP_QRY_PWNO_6_2_REALVAL;m;f");
		hm.put("page", "HTP_QRY_PAGE;m;x");
		hm.put("OTPCARDPWNO_6__E2E__", "HTP_QRY_OTPCARDPWNO_6__E2E__;m;f");
		hm.put("CARD_NO_16", "HTP_QRY_CARD_NO_16;m;e");
		hm.put("token", "HTP_QRY_TOKEN;m;x");
		hm.put("RCVACTNO_15_MASK", "HTP_QRY_RCVACTNO_15_MASK;m;e");
		hm.put("IN_AMOUNT_13_COMMA", "HTP_QRY_IN_AMOUNT_13_COMMA;m;x");
		hm.put("TRNAM_13_COMMA", "HTP_QRY_TRNAM_13_COMMA;m;x");
		hm.put("IN_BANK_CD_3_STR", "HTP_QRY_IN_BANK_CD_3_STR;m;x");
		hm.put("ATS_MNG_NO", "HTP_QRY_ATS_MNG_NO;m;x");
		hm.put("COMMONCERT_TYPE", "HTP_QRY_COMMONCERT_TYPE;m;x");
		hm.put("INQ_EDT_10", "HTP_QRY_INQ_EDT_10;m;x");
		hm.put("INQ_SDT_10", "HTP_QRY_INQ_SDT_10;m;x");
		hm.put("itcsno", "HTP_QRY_ITCSNO;m;x");
		hm.put("CLMNYNO1_16", "HTP_QRY_CLMNYNO1_16;m;x");
		hm.put("certselect_tek_input1__E2E__", "HTP_QRY_CERTSELECT_TEK_INPUT1__E2E__;m;x");
		hm.put("PSNBZ_YN", "HTP_QRY_PSNBZ_YN;m;x");
		hm.put("SECU_CARD_RAN_NO_2", "HTP_QRY_SECU_CARD_RAN_NO_2;m;e");
		hm.put("RSV_YN", "HTP_QRY_RSV_YN;m;x");
		hm.put("NEW_RCKN_DT", "HTP_QRY_NEW_RCKN_DT;m;x");
		hm.put("P_name", "HTP_QRY_P_NAME;m;x");
		hm.put("CHK_CRT_NO", "HTP_QRY_CHK_CRT_NO;m;x");
		hm.put("PWNO_6", "HTP_QRY_PWNO_6;m;f");
		hm.put("ACT_NCM", "HTP_QRY_ACT_NCM;m;k");
		hm.put("AUTH_SVC_APP_CERT_HASH", "HTP_QRY_AUTH_SVC_APP_CERT_HASH;m;x");
		hm.put("AUTH_SVC_AUTH_TYPE", "HTP_QRY_AUTH_SVC_AUTH_TYPE;m;x");
		hm.put("AUTH_SVC_EVENT_ID", "HTP_QRY_AUTH_SVC_EVENT_ID;m;x");
		hm.put("BIOAUT_DIS_CD", "HTP_QRY_BIOAUT_DIS_CD;m;x");
		hm.put("AUTH_SVC_USER_ID", "HTP_QRY_AUTH_SVC_USER_ID;m;x");
		hm.put("AUTH_SVC_AUTH_TOKEN", "HTP_QRY_AUTH_SVC_AUTH_TOKEN;m;x");
		hm.put("AUTH_SVC_APP_ID", "HTP_QRY_AUTH_SVC_APP_ID;m;x");
		hm.put("IS_FIDO_USE", "HTP_QRY_IS_FIDO_USE;m;x");
		hm.put("BIOAUT_USE_CD", "HTP_QRY_BIOAUT_USE_CD;m;x");
		hm.put("transkey_hMac_Tk_PWNO_6", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6;m;f");
		hm.put("Tk_PWNO_6_check", "HTP_QRY_TK_PWNO_6_CHECK;m;f");
		hm.put("transkey_Tk_PWNO_6", "HTP_QRY_TRANSKEY_TK_PWNO_6;m;f");
		hm.put("CD_PRD_CD", "HTP_QRY_CD_PRD_CD;m;x");
		hm.put("USNM", "HTP_QRY_USNM;m;k");
		hm.put("INQ_PRN_NO_16_3", "HTP_QRY_INQ_PRN_NO_16_3;m;x");
		hm.put("INQ_PRN_NO_16_2", "HTP_QRY_INQ_PRN_NO_16_2;m;x");
		hm.put("INQ_PRN_NO_16_4", "HTP_QRY_INQ_PRN_NO_16_4;m;x");
		hm.put("INQ_PRN_NO_16_1", "HTP_QRY_INQ_PRN_NO_16_1;m;x");
		hm.put("JUMIN_NUMBER1", "HTP_QRY_JUMIN_NUMBER1;m;x");
		hm.put("s_signed", "HTP_QRY_S_SIGNED;m;k");
		hm.put("format", "HTP_QRY_FORMAT;m;x");
		hm.put("TRN_SRNO_12", "HTP_QRY_TRN_SRNO_12;m;x");
		hm.put("IMG_PWNO_6_2", "HTP_QRY_IMG_PWNO_6_2;m;f");
		hm.put("IMG_PWNO_6_1", "HTP_QRY_IMG_PWNO_6_1;m;f");
		hm.put("PWNO_6_1", "HTP_QRY_PWNO_6_1;m;f");
		hm.put("PWNO_6_2", "HTP_QRY_PWNO_6_2;m;f");
		hm.put("Tk_PWNO_6_1_check", "HTP_QRY_TK_PWNO_6_1_CHECK;m;f");
		hm.put("transkey_hMac_Tk_PWNO_6_2", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6_2;m;f");
		hm.put("transkey_hMac_Tk_PWNO_6_1", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6_1;m;f");
		hm.put("transkey_Tk_PWNO_6_2", "HTP_QRY_TRANSKEY_TK_PWNO_6_2;m;f");
		hm.put("transkey_Tk_PWNO_6_1", "HTP_QRY_TRANSKEY_TK_PWNO_6_1;m;f");
		hm.put("Tk_PWNO_6_2_check", "HTP_QRY_TK_PWNO_6_2_CHECK;m;x");
		hm.put("inspect", "HTP_QRY_INSPECT;m;x");
		hm.put("s_signedkey", "HTP_QRY_S_SIGNEDKEY;m;x");
		hm.put("FND_DEP_STEP", "HTP_QRY_FND_DEP_STEP;m;x");
		hm.put("TELCODE", "HTP_QRY_TELCODE;m;x");
		hm.put("PWNO_6__E2E__", "HTP_QRY_PWNO_6__E2E__;m;f");
		hm.put("GB", "HTP_QRY_GB;m;x");
		hm.put("MODE", "HTP_QRY_MODE;m;x");
		hm.put("sec_E2EPid", "HTP_QRY_SEC_E2EPID;m;x");
		hm.put("PSBZ_NO", "HTP_QRY_PSBZ_NO;m;e");
		hm.put("PWNO_6_2__E2E__", "HTP_QRY_PWNO_6_2__E2E__;m;f");
		hm.put("PWNO_6_1__E2E__", "HTP_QRY_PWNO_6_1__E2E__;m;f");
		hm.put("WIBEE_HMNY_DDU_RDU_AM", "HTP_QRY_WIBEE_HMNY_DDU_RDU_AM;m;x");
		hm.put("Tk_pup03_check", "HTP_QRY_TK_PUP03_CHECK;m;x");
		hm.put("rdo_AddAuthMns", "HTP_QRY_RDO_ADDAUTHMNS;m;x");
		hm.put("CONT_NO_DIS", "HTP_QRY_CONT_NO_DIS;m;x");
		hm.put("input_num24", "HTP_QRY_INPUT_NUM24;m;x");
		hm.put("input_num5", "HTP_QRY_INPUT_NUM5;m;x");
		hm.put("input_num7", "HTP_QRY_INPUT_NUM7;m;x");
		hm.put("input_num16", "HTP_QRY_INPUT_NUM16;m;x");
		hm.put("input_num26", "HTP_QRY_INPUT_NUM26;m;x");
		hm.put("input_num15", "HTP_QRY_INPUT_NUM15;m;x");
		hm.put("input_num10", "HTP_QRY_INPUT_NUM10;m;x");
		hm.put("input_num1", "HTP_QRY_INPUT_NUM1;m;x");
		hm.put("input_num21", "HTP_QRY_INPUT_NUM21;m;x");
		hm.put("input_num35", "HTP_QRY_INPUT_NUM35;m;x");
		hm.put("input_num17", "HTP_QRY_INPUT_NUM17;m;x");
		hm.put("input_num14", "HTP_QRY_INPUT_NUM14;m;x");
		hm.put("input_num32", "HTP_QRY_INPUT_NUM32;m;x");
		hm.put("input_num33", "HTP_QRY_INPUT_NUM33;m;x");
		hm.put("input_num12", "HTP_QRY_INPUT_NUM12;m;x");
		hm.put("input_num22", "HTP_QRY_INPUT_NUM22;m;x");
		hm.put("input_num20", "HTP_QRY_INPUT_NUM20;m;x");
		hm.put("input_num19", "HTP_QRY_INPUT_NUM19;m;x");
		hm.put("input_num23", "HTP_QRY_INPUT_NUM23;m;x");
		hm.put("input_num34", "HTP_QRY_INPUT_NUM34;m;x");
		hm.put("input_num30", "HTP_QRY_INPUT_NUM30;m;x");
		hm.put("input_num8", "HTP_QRY_INPUT_NUM8;m;x");
		hm.put("input_num18", "HTP_QRY_INPUT_NUM18;m;x");
		hm.put("input_num13", "HTP_QRY_INPUT_NUM13;m;x");
		hm.put("input_num28", "HTP_QRY_INPUT_NUM28;m;x");
		hm.put("input_num2", "HTP_QRY_INPUT_NUM2;m;x");
		hm.put("input_num3", "HTP_QRY_INPUT_NUM3;m;x");
		hm.put("input_num4", "HTP_QRY_INPUT_NUM4;m;x");
		hm.put("input_num27", "HTP_QRY_INPUT_NUM27;m;x");
		hm.put("input_num29", "HTP_QRY_INPUT_NUM29;m;x");
		hm.put("input_num25", "HTP_QRY_INPUT_NUM25;m;x");
		hm.put("input_num31", "HTP_QRY_INPUT_NUM31;m;x");
		hm.put("input_num6", "HTP_QRY_INPUT_NUM6;m;x");
		hm.put("BLDPY_BAS", "HTP_QRY_BLDPY_BAS;m;x");
		hm.put("input_num9", "HTP_QRY_INPUT_NUM9;m;x");
		hm.put("input_num11", "HTP_QRY_INPUT_NUM11;m;x");
		hm.put("MTS_NM", "HTP_QRY_MTS_NM;m;x");
		hm.put("S_PAGE", "HTP_QRY_S_PAGE;m;x");
		hm.put("RCVBNKNM", "HTP_QRY_RCVBNKNM;m;x");
		hm.put("acctBalance", "HTP_QRY_ACCTBALANCE;m;x");
		hm.put("monthLimit", "HTP_QRY_MONTHLIMIT;m;x");
		hm.put("possibleAmt", "HTP_QRY_POSSIBLEAMT;m;x");
		hm.put("MMDA_INT_RCPE_NM_22", "HTP_QRY_MMDA_INT_RCPE_NM_22;m;x");
		hm.put("actErrMsg", "HTP_QRY_ACTERRMSG;m;x");
		hm.put("MST_YN", "HTP_QRY_MST_YN;m;x");
		hm.put("INQ_DIS1_1", "HTP_QRY_INQ_DIS1_1;m;x");
		hm.put("INQ_KEY_20", "HTP_QRY_INQ_KEY_20;m;e");
		hm.put("EXEC", "HTP_QRY_EXEC;m;x");
		hm.put("RDU_FEE_AM_11", "HTP_QRY_RDU_FEE_AM_11;m;x");
		hm.put("WMB_RDU_AM_11", "HTP_QRY_WMB_RDU_AM_11;m;x");
		hm.put("ERROR_MSG_TXT", "HTP_QRY_ERROR_MSG_TXT;m;x");
		hm.put("RSP_TXT", "HTP_QRY_RSP_TXT;m;x");
		hm.put("TS_AM", "HTP_QRY_TS_AM;m;x");
		hm.put("ACTPRDNM", "HTP_QRY_ACTPRDNM;m;x");
		hm.put("ADVPE_EMP_NO_8", "HTP_QRY_ADVPE_EMP_NO_8;m;x");
		hm.put("SORT_DIS", "HTP_QRY_SORT_DIS;m;x");
		hm.put("WDR_BKNM", "HTP_QRY_WDR_BKNM;m;x");
		hm.put("INQ_GROUP", "HTP_QRY_INQ_GROUP;m;x");
		hm.put("BFAF_TR_BL_13", "HTP_QRY_BFAF_TR_BL_13;m;x");
		hm.put("hid_key_data", "HTP_QRY_HID_KEY_DATA;m;x");
		hm.put("ACC_NM", "HTP_QRY_ACC_NM;m;x");
		hm.put("CMS_NO", "HTP_QRY_CMS_NO;m;x");
		hm.put("HP_AUTH_UNQ_NO", "HTP_QRY_HP_AUTH_UNQ_NO;m;f");
		hm.put("SEARCH_DIS", "HTP_QRY_SEARCH_DIS;m;x");
		hm.put("query", "HTP_QRY_QUERY;m;x");
		hm.put("sel_SEARCH_DIS", "HTP_QRY_SEL_SEARCH_DIS;m;x");
		hm.put("sel_INQ_DIS", "HTP_QRY_SEL_INQ_DIS;m;x");
		hm.put("ATS_FND_INSV_SRVC_TYCD", "HTP_QRY_ATS_FND_INSV_SRVC_TYCD;m;x");
		hm.put("SqlType", "HTP_QRY_SQLTYPE;m;x");
		hm.put("FAULT", "HTP_QRY_FAULT;m;x");
		hm.put("RSVEXEDY_TIME", "HTP_QRY_RSVEXEDY_TIME;m;x");
		hm.put("STS", "HTP_QRY_STS;m;x");
		hm.put("TAB_FLAG", "HTP_QRY_TAB_FLAG;m;x");
		hm.put("TCH_AUTH_USE_YN", "HTP_QRY_TCH_AUTH_USE_YN;m;x");
		hm.put("TYPE", "HTP_QRY_TYPE;m;x");
		hm.put("WORK_CD_2", "HTP_QRY_WORK_CD_2;m;x");
		hm.put("FEE_BEAF_YN_1", "HTP_QRY_FEE_BEAF_YN_1;m;x");
		hm.put("doTran", "HTP_QRY_DOTRAN;m;x");
		hm.put("USER_NAME", "HTP_QRY_USER_NAME;m;k");
		hm.put("APPR_DIS", "HTP_QRY_APPR_DIS;m;x");
		hm.put("CAN_ONE_STOP_SVC_YN", "HTP_QRY_CAN_ONE_STOP_SVC_YN;m;x");
		hm.put("JUMIN_NUMBER2", "HTP_QRY_JUMIN_NUMBER2;m;x");
		hm.put("APVRQ_DT2", "HTP_QRY_APVRQ_DT2;m;x");
		hm.put("APVRQ_DT1", "HTP_QRY_APVRQ_DT1;m;x");
		hm.put("APV_APL_DIS2", "HTP_QRY_APV_APL_DIS2;m;x");
		hm.put("ADVPE_EMP_INFO", "HTP_QRY_ADVPE_EMP_INFO;m;x");
		hm.put("QR_ADVPE_NO", "HTP_QRY_QR_ADVPE_NO;m;x");
		hm.put("setHead", "HTP_QRY_SETHEAD;m;x");
		hm.put("WDR_ACNO_15", "HTP_QRY_WDR_ACNO_15;m;e");
		hm.put("CUS_NM", "HTP_QRY_CUS_NM;m;k");
		hm.put("PBOKMNTNHIS_TOT", "HTP_QRY_PBOKMNTNHIS_TOT;m;x");
		hm.put("TOT_CNT", "HTP_QRY_TOT_CNT;m;x");
		hm.put("PRD_KORL_NM", "HTP_QRY_PRD_KORL_NM;m;x");
		hm.put("WDR_ACNO_TEXT_TOT", "HTP_QRY_WDR_ACNO_TEXT_TOT;m;x");
		hm.put("ACT_PWNO_REALVAL", "HTP_QRY_ACT_PWNO_REALVAL;m;f");
		hm.put("ADVPE_EMP_SEARCH", "HTP_QRY_ADVPE_EMP_SEARCH;m;x");
		hm.put("FROM_DATE", "HTP_QRY_FROM_DATE;m;x");
		hm.put("preCnt", "HTP_QRY_PRECNT;m;x");
		hm.put("TO_DATE", "HTP_QRY_TO_DATE;m;x");
		hm.put("NXT_TRN_YN", "HTP_QRY_NXT_TRN_YN;m;x");
		hm.put("CTIN_INQ_SRNO", "HTP_QRY_CTIN_INQ_SRNO;m;x");
		hm.put("pageID", "HTP_QRY_PAGEID;m;x");
		hm.put("RMC_REQ_CHECK", "HTP_QRY_RMC_REQ_CHECK;m;x");
		hm.put("POLICY_TYPE", "HTP_QRY_POLICY_TYPE;m;x");
		hm.put("SERIAL", "HTP_QRY_SERIAL;m;x");
		hm.put("EMAIL", "HTP_QRY_EMAIL;m;f");
		hm.put("acctKind", "HTP_QRY_ACCTKIND;m;x");
		hm.put("TERM_ACTIVE_IDX", "HTP_QRY_TERM_ACTIVE_IDX;m;x");
		hm.put("TERM_FILE_TYPE", "HTP_QRY_TERM_FILE_TYPE;m;x");
		hm.put("selDate", "HTP_QRY_SELDATE;m;x");
		hm.put("TERM_PAGE", "HTP_QRY_TERM_PAGE;m;x");
		hm.put("TERM_VIEWTYPE", "HTP_QRY_TERM_VIEWTYPE;m;x");
		hm.put("TERM_TITLE", "HTP_QRY_TERM_TITLE;m;x");
		hm.put("tranFlag", "HTP_QRY_TRANFLAG;m;x");
		hm.put("TSDY_2", "HTP_QRY_TSDY_2;m;x");
		hm.put("TSFRQ_1", "HTP_QRY_TSFRQ_1;m;x");
		hm.put("val", "HTP_QRY_VAL;m;x");
		hm.put("id", "HTP_QRY_ID;m;x");
		hm.put("DPT_AUTH_USE_YN", "HTP_QRY_DPT_AUTH_USE_YN;m;x");
		hm.put("maxDate", "HTP_QRY_MAXDATE;m;x");
		hm.put("minDate", "HTP_QRY_MINDATE;m;x");
		hm.put("OPN_REST_LMT", "HTP_QRY_OPN_REST_LMT;m;x");
		hm.put("title", "HTP_QRY_TITLE;m;x");
		hm.put("ksP1", "HTP_QRY_KSP1;m;x");
		hm.put("ITPY_MECD", "HTP_QRY_ITPY_MECD;m;x");
		hm.put("ACT_HAIJI", "HTP_QRY_ACT_HAIJI;m;x");
		hm.put("accNum", "HTP_QRY_ACCNUM;m;e");
		hm.put("RQSPE_NM", "HTP_QRY_RQSPE_NM;m;x");
		hm.put("CD_IFOFR_AGR_YN", "HTP_QRY_CD_IFOFR_AGR_YN;m;x");
		hm.put("paramActKd", "HTP_QRY_PARAMACTKD;m;x");
		hm.put("FND_PDCD", "HTP_QRY_FND_PDCD;m;x");
		hm.put("OTPWD_AUTH_USE_YN", "HTP_QRY_OTPWD_AUTH_USE_YN;m;x");
		hm.put("CTGR_CD", "HTP_QRY_CTGR_CD;m;x");
		hm.put("CANC_ACNO", "HTP_QRY_CANC_ACNO;m;e");
		hm.put("RNPE_NM", "HTP_QRY_RNPE_NM;m;x");
		hm.put("SECU_FLAG", "HTP_QRY_SECU_FLAG;m;x");
		hm.put("TERM_CALLBACK", "HTP_QRY_TERM_CALLBACK;m;x");
		hm.put("USERDN", "HTP_QRY_USERDN;m;k");
		hm.put("Citygbn", "HTP_QRY_CITYGBN;m;x");
		hm.put("ATS_TITL", "HTP_QRY_ATS_TITL;m;x");
		hm.put("APPR1USERID1", "HTP_QRY_APPR1USERID1;m;x");
		hm.put("hid_enc_data", "HTP_QRY_HID_ENC_DATA;m;x");
		hm.put("report_name", "HTP_QRY_REPORT_NAME;m;x");
		hm.put("EML", "HTP_QRY_EML;m;f");
		hm.put("strCnUrl", "HTP_QRY_STRCNURL;m;x");
		hm.put("INT_BSDT", "HTP_QRY_INT_BSDT;m;x");
		hm.put("callback", "HTP_QRY_CALLBACK;m;x");
		hm.put("fromId", "HTP_QRY_FROMID;m;x");
		hm.put("toId", "HTP_QRY_TOID;m;x");
		hm.put("CCD_REQ_SIZE", "HTP_QRY_CCD_REQ_SIZE;m;x");
		hm.put("DPAC_BAL", "HTP_QRY_DPAC_BAL;m;x");
		hm.put("IGNORE", "HTP_QRY_IGNORE;m;x");
		hm.put("NATION_TEL_30", "HTP_QRY_NATION_TEL_30;m;x");
		hm.put("ADD_AUTH_MSG", "HTP_QRY_ADD_AUTH_MSG;m;x");
		hm.put("ADDRESS", "HTP_QRY_ADDRESS;m;e");
		hm.put("ZIP_CODE", "HTP_QRY_ZIP_CODE;m;x");
		hm.put("FAX", "HTP_QRY_FAX;m;x");
		hm.put("EUSER_NAME", "HTP_QRY_EUSER_NAME;m;k");
		hm.put("REG_SMART_YN", "HTP_QRY_REG_SMART_YN;m;x");
		hm.put("TSKD_1", "HTP_QRY_TSKD_1;m;x");
		hm.put("actKd", "HTP_QRY_ACTKD;m;x");
		hm.put("TSENDDY_8", "HTP_QRY_TSENDDY_8;m;x");
		hm.put("TSSTADY_8", "HTP_QRY_TSSTADY_8;m;x");
		hm.put("PRME_ITCD_LIST", "HTP_QRY_PRME_ITCD_LIST;m;x");
		hm.put("SUB_LIF_TEL", "HTP_QRY_SUB_LIF_TEL;m;x");
		hm.put("TPS_PDCD", "HTP_QRY_TPS_PDCD;m;x");
		hm.put("NATION_CD2", "HTP_QRY_NATION_CD2;m;x");
		hm.put("RESULT_STS_", "HTP_QRY_RESULT_STS_;m;x");
		hm.put("TOT_TRAMT", "HTP_QRY_TOT_TRAMT;m;x");
		hm.put("INQ_NUM", "HTP_QRY_INQ_NUM;m;x");
		hm.put("RESULT_STSA", "HTP_QRY_RESULT_STSA;m;x");
		hm.put("wibee_market_id_yn", "HTP_QRY_WIBEE_MARKET_ID_YN;m;x");
		hm.put("PWNO_RGS_DSCD", "HTP_QRY_PWNO_RGS_DSCD;m;x");
		hm.put("PWNO_8", "HTP_QRY_PWNO_8;m;f");
		hm.put("CLMNY_NO_50", "HTP_QRY_CLMNY_NO_50;m;x");
		hm.put("RDU_FEE_AM", "HTP_QRY_RDU_FEE_AM;m;x");
		hm.put("WMB_RDU_AM", "HTP_QRY_WMB_RDU_AM;m;x");
		hm.put("transkey_Tk_PWNO_8", "HTP_QRY_TRANSKEY_TK_PWNO_8;m;f");
		hm.put("Tk_PWNO_8_check", "HTP_QRY_TK_PWNO_8_CHECK;m;x");
		hm.put("transkey_hMac_Tk_PWNO_8", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_8;m;f");
		hm.put("WIBEE_MNY_DDU_AM", "HTP_QRY_WIBEE_MNY_DDU_AM;m;x");
		hm.put("SMRT_LN_JNNG_YN", "HTP_QRY_SMRT_LN_JNNG_YN;m;x");
		hm.put("T_CHECK", "HTP_QRY_T_CHECK;m;x");
		hm.put("DIS_FEE", "HTP_QRY_DIS_FEE;m;x");
		hm.put("NGO_BR_5", "HTP_QRY_NGO_BR_5;m;x");
		hm.put("CUS_ACNO", "HTP_QRY_CUS_ACNO;m;e");
		hm.put("INQ_EDT_10Y", "HTP_QRY_INQ_EDT_10Y;m;x");
		hm.put("INQ_SDT_10D", "HTP_QRY_INQ_SDT_10D;m;x");
		hm.put("INQ_SDT_10Y", "HTP_QRY_INQ_SDT_10Y;m;x");
		hm.put("INQ_SDT_10M", "HTP_QRY_INQ_SDT_10M;m;x");
		hm.put("INQ_EDT_10D", "HTP_QRY_INQ_EDT_10D;m;x");
		hm.put("INQ_EDT_10M", "HTP_QRY_INQ_EDT_10M;m;x");
		hm.put("standardDate2", "HTP_QRY_STANDARDDATE2;m;x");
		hm.put("standardDate1", "HTP_QRY_STANDARDDATE1;m;x");
		hm.put("oper1", "HTP_QRY_OPER1;m;x");
		hm.put("oper2", "HTP_QRY_OPER2;m;x");
		hm.put("TXPR_DSCD", "HTP_QRY_TXPR_DSCD;m;x");
		hm.put("RPY_AM", "HTP_QRY_RPY_AM;m;x");
		hm.put("CHRG_KDCD_2", "HTP_QRY_CHRG_KDCD_2;m;x");
		hm.put("USER_DN", "HTP_QRY_USER_DN;m;x");
		hm.put("PNT_INT_PYM_YN", "HTP_QRY_PNT_INT_PYM_YN;m;x");
		hm.put("MB_PNT_AM", "HTP_QRY_MB_PNT_AM;m;x");
		hm.put("PWNO_8__E2E__", "HTP_QRY_PWNO_8__E2E__;m;f");
		hm.put("HP_COM_CD", "HTP_QRY_HP_COM_CD;m;f");
		hm.put("INQ_TYPE", "HTP_QRY_INQ_TYPE;m;x");
		hm.put("NEXT_CNT", "HTP_QRY_NEXT_CNT;m;x");
		hm.put("SMSD_DSCD", "HTP_QRY_SMSD_DSCD;m;x");
		hm.put("bbsMode", "HTP_QRY_BBSMODE;m;x");
		hm.put("ARTICLE_ID", "HTP_QRY_ARTICLE_ID;m;x");
		hm.put("PUP_NAPL_EDT", "HTP_QRY_PUP_NAPL_EDT;m;x");
		hm.put("RSN_TXT", "HTP_QRY_RSN_TXT;m;x");
		hm.put("POPUP_ID", "HTP_QRY_POPUP_ID;m;x");
		hm.put("ACTPWNO_8_REALVAL", "HTP_QRY_ACTPWNO_8_REALVAL;m;f");
		hm.put("CERT_KIND", "HTP_QRY_CERT_KIND;m;x");
		hm.put("SMS_MSG", "HTP_QRY_SMS_MSG;m;x");
		hm.put("ksP2", "HTP_QRY_KSP2;m;x");
		hm.put("pageNo", "HTP_QRY_PAGENO;m;x");
		hm.put("RCV_ACCT_CD", "HTP_QRY_RCV_ACCT_CD;m;x");
		hm.put("TS_KDCD_2", "HTP_QRY_TS_KDCD_2;m;x");
		hm.put("HP_TLEN_NO", "HTP_QRY_HP_TLEN_NO;m;f");
		hm.put("returnValue", "HTP_QRY_RETURNVALUE;m;x");
		hm.put("TR_SEQ", "HTP_QRY_TR_SEQ;m;x");
		hm.put("HP_SRNO", "HTP_QRY_HP_SRNO;m;f");
		hm.put("RGSDY_8", "HTP_QRY_RGSDY_8;m;x");
		hm.put("ITPY_CYCD", "HTP_QRY_ITPY_CYCD;m;x");
		hm.put("focusId", "HTP_QRY_FOCUSID;m;x");
		hm.put("actKdKr", "HTP_QRY_ACTKDKR;m;x");
		hm.put("readonly", "HTP_QRY_READONLY;m;x");
		hm.put("msg2", "HTP_QRY_MSG2;m;x");
		hm.put("msg1", "HTP_QRY_MSG1;m;x");
		hm.put("frm", "HTP_QRY_FRM;m;x");
		hm.put("valFormat", "HTP_QRY_VALFORMAT;m;x");
		hm.put("PRD_ARG_SKIP_YN", "HTP_QRY_PRD_ARG_SKIP_YN;m;x");
		hm.put("Tk_PSBZ_NO_4_check", "HTP_QRY_TK_PSBZ_NO_4_CHECK;m;x");
		hm.put("transkey_hMac_Tk_PSBZ_NO_4", "HTP_QRY_TRANSKEY_HMAC_TK_PSBZ_NO_4;m;x");
		hm.put("transkey_Tk_PSBZ_NO_4", "HTP_QRY_TRANSKEY_TK_PSBZ_NO_4;m;x");
		hm.put("detaildata", "HTP_QRY_DETAILDATA;m;x");
		hm.put("masterdata", "HTP_QRY_MASTERDATA;m;x");
		hm.put("PSBZ_NO_4", "HTP_QRY_PSBZ_NO_4;m;x");
		hm.put("SVC_USER_ID", "HTP_QRY_SVC_USER_ID;m;x");
		hm.put("SVC_AUTH_TOKEN", "HTP_QRY_SVC_AUTH_TOKEN;m;x");
		hm.put("SVC_AUTH_TYPE", "HTP_QRY_SVC_AUTH_TYPE;m;x");
		hm.put("PAY_ACNO_15", "HTP_QRY_PAY_ACNO_15;m;e");
		hm.put("ENCY_WDR_ACT_PWNO", "HTP_QRY_ENCY_WDR_ACT_PWNO;m;f");
		hm.put("OBK_UNQ_NO", "HTP_QRY_OBK_UNQ_NO;m;x");
		hm.put("OUTCALL_USE_YN", "HTP_QRY_OUTCALL_USE_YN;m;x");
		hm.put("DOKDO_CLICK", "HTP_QRY_DOKDO_CLICK;m;x");
		hm.put("CUS_INF_HP_SER", "HTP_QRY_CUS_INF_HP_SER;m;x");
		hm.put("CUS_INF_HP_RGN", "HTP_QRY_CUS_INF_HP_RGN;m;x");
		hm.put("CPON_SMS_CHR_RQ_YN", "HTP_QRY_CPON_SMS_CHR_RQ_YN;m;x");
		hm.put("CUS_INF_HP_TLEN", "HTP_QRY_CUS_INF_HP_TLEN;m;x");
		hm.put("CARD_INQ_ERROR", "HTP_QRY_CARD_INQ_ERROR;m;e");
		hm.put("LPOINT_USE_YN", "HTP_QRY_LPOINT_USE_YN;m;x");
		hm.put("OBK_TS_YN", "HTP_QRY_OBK_TS_YN;m;x");
		hm.put("LPOINT_COP_MCNO", "HTP_QRY_LPOINT_COP_MCNO;m;x");
		hm.put("IS_SMTJOIN_VISIBLE", "HTP_QRY_IS_SMTJOIN_VISIBLE;m;x");
		hm.put("INQ_BAS_DT", "HTP_QRY_INQ_BAS_DT;m;x");
		hm.put("cddinfo_ins", "HTP_QRY_CDDINFO_INS;m;x");
		hm.put("WIBTALKC", "HTP_QRY_WIBTALKC;m;x");
		hm.put("returnFNDTSPWNO_8", "HTP_QRY_RETURNFNDTSPWNO_8;m;f");
		hm.put("VIEW_AUT", "HTP_QRY_VIEW_AUT;m;x");
		hm.put("sltChkBox", "HTP_QRY_SLTCHKBOX;m;x");
		hm.put("PRD_CD_9_1", "HTP_QRY_PRD_CD_9_1;m;x");
		hm.put("AccTitle", "HTP_QRY_ACCTITLE;m;x");
		hm.put("SEARCH_TXT", "HTP_QRY_SEARCH_TXT;m;x");
		hm.put("CTRTM_MCN", "HTP_QRY_CTRTM_MCN;m;x");
		hm.put("total", "HTP_QRY_TOTAL;m;x");
		hm.put("rcpenmdata", "HTP_QRY_RCPENMDATA;m;x");
		hm.put("RCV_PBOK_TXT", "HTP_QRY_RCV_PBOK_TXT;m;x");
		hm.put("DPI", "HTP_QRY_DPI;m;x");
		hm.put("pageNumber", "HTP_QRY_PAGENUMBER;m;x");
		hm.put("html5", "HTP_QRY_HTML5;m;x");
		hm.put("SHOW_NUM_USE_YN", "HTP_QRY_SHOW_NUM_USE_YN;m;x");
		hm.put("PRD_AGR_ITEMS", "HTP_QRY_PRD_AGR_ITEMS;m;x");
		hm.put("STL_DT", "HTP_QRY_STL_DT;m;x");
		hm.put("modActiveX", "HTP_QRY_MODACTIVEX;m;x");
		hm.put("UseOriginImage", "HTP_QRY_USEORIGINIMAGE;m;x");
		hm.put("isChartToImage", "HTP_QRY_ISCHARTTOIMAGE;m;x");
		hm.put("Accessibility", "HTP_QRY_ACCESSIBILITY;m;x");
		hm.put("DFR_YN", "HTP_QRY_DFR_YN;m;x");
		hm.put("APPR1MobCHK1", "HTP_QRY_APPR1MOBCHK1;m;x");
		hm.put("TRN_CNT", "HTP_QRY_TRN_CNT;m;x");
		hm.put("FEE_RDU_CD_3", "HTP_QRY_FEE_RDU_CD_3;m;x");
		hm.put("TOT_FEE_AM_11", "HTP_QRY_TOT_FEE_AM_11;m;x");
		hm.put("GRID_FIRST_CNT", "HTP_QRY_GRID_FIRST_CNT;m;x");
		hm.put("BF_RCV_INQ_CNT", "HTP_QRY_BF_RCV_INQ_CNT;m;x");
		hm.put("OBK_FEE_BY_CNT_11", "HTP_QRY_OBK_FEE_BY_CNT_11;m;x");
		hm.put("TBK_FEE_BY_CNT_11", "HTP_QRY_TBK_FEE_BY_CNT_11;m;x");
		hm.put("FeeInq_YN", "HTP_QRY_FEEINQ_YN;m;x");
		hm.put("FILE_LOAD_CNT", "HTP_QRY_FILE_LOAD_CNT;m;x");
		hm.put("LOG_MSG", "HTP_QRY_LOG_MSG;m;x");
		hm.put("APPR1USERHP1", "HTP_QRY_APPR1USERHP1;m;x");
		hm.put("PBOK_PRT_TXT_DIS", "HTP_QRY_PBOK_PRT_TXT_DIS;m;x");
		hm.put("RSV_TIME", "HTP_QRY_RSV_TIME;m;x");
		hm.put("AF_RCV_INQ_CNT", "HTP_QRY_AF_RCV_INQ_CNT;m;x");
		hm.put("RSV_TIME_CK", "HTP_QRY_RSV_TIME_CK;m;x");
		hm.put("gizaYN", "HTP_QRY_GIZAYN;m;x");
		hm.put("isErrDel_YN", "HTP_QRY_ISERRDEL_YN;m;x");
		hm.put("filedata", "HTP_QRY_FILEDATA;m;x");
		hm.put("tranData", "HTP_QRY_TRANDATA;m;x");
		hm.put("sCodes", "HTP_QRY_SCODES;m;x");
		hm.put("sValue2", "HTP_QRY_SVALUE2;m;x");
		hm.put("sValue3", "HTP_QRY_SVALUE3;m;x");
		hm.put("sendDataCnt", "HTP_QRY_SENDDATACNT;m;x");
		hm.put("sumTotActNo", "HTP_QRY_SUMTOTACTNO;m;e");
		hm.put("SVC_EVENT_ID", "HTP_QRY_SVC_EVENT_ID;m;x");
		hm.put("SVC_APP_CERT_HASH", "HTP_QRY_SVC_APP_CERT_HASH;m;x");
		hm.put("SVC_APP_ID", "HTP_QRY_SVC_APP_ID;m;x");
		hm.put("WDR_PBOK_TXT", "HTP_QRY_WDR_PBOK_TXT;m;x");
		hm.put("TS_TEM_UNCD", "HTP_QRY_TS_TEM_UNCD;m;x");
		hm.put("SVC_CD", "HTP_QRY_SVC_CD;m;x");
		hm.put("fromWhere", "HTP_QRY_FROMWHERE;m;x");
		hm.put("CODE", "HTP_QRY_CODE;m;x");
		hm.put("RCV_OWAC_NM", "HTP_QRY_RCV_OWAC_NM;m;k");
		hm.put("s", "HTP_QRY_S;m;x");
		hm.put("qrBrCd", "HTP_QRY_QRBRCD;m;x");
		hm.put("qrAdvpeNo", "HTP_QRY_QRADVPENO;m;x");
		hm.put("t", "HTP_QRY_T;m;x");
		hm.put("c", "HTP_QRY_C;m;x");
		hm.put("no", "HTP_QRY_NO;m;x");
		
		
		// ^\t([^\(]*)\(\"\.HTTP_QUERY\.([^\"]*)\", ([^,]*), ([^,]*),.*$
		// \thm.put\("\2", "\1;\3;\4"\);
		
		String tmpVal = null;
		
		if (src.exists()) {
			
			idxLn = 0L;
			
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
				
//				File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + "_mst.json");
				File wrFile = new File(TGT_PATH);
				
				OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);
				
				String rd_line = null;
				
				while ((rd_line = br.readLine()) != null
						
//						&& idxLn < 2
						
						) {
					
					idxLn++;
					
//					if(
//						idxLn == 398289
//						idxLn < 500000
//					) {
//						continue;
//					} 
					
					json = gs.fromJson(rd_line, JsonObject.class);
					
					
					/*** 	json 추가 구역  	***/
					
					// host_ip_addr
					json.addProperty("HOST_IP_ADDR", parseString(json.get("REMOTE_ADDR")));
					
					// host_domain
					json.addProperty("HOST_DOMAIN", parseString(json.get("SERVER_HOST"), "([a-zA-Z0-9_]*)\\.wooribank\\.com"));
					
					// parseHttpTime
					json = parseHttpTime(json, parseString(json.get("HTTP_TIME")));
					
					// parseRemoteUser
					json = parseRemoteUser(json, parseString(json.get("REMOTE_USER")));					
					
					// parseUserAgent
					json = parseUserAgent(json, parseString(json.get("USER_AGENT")));		
					
					
					// http parsing
					// http_query 존재 유무 체크
					
					String sReferer = null; 
					if( json.get("HTTP_REFERER") != null && !json.get("HTTP_REFERER").getAsString().trim().isEmpty() ) {
						sReferer = json.get("HTTP_REFERER").getAsString();
					}
					
					List<String> forEnc = null;
					List<String> forMask = null;
					
					// http_query_json_dummy
					if( json.get("HTTP_QUERY") != null ) {
						
							jsonHtpQry = parseLine(parseString(json.get("HTTP_QUERY")));
//							log.debug("jsonHtpQry : {}", jsonHtpQry);
							
						if(jsonHtpQry != null) {
							
							String htpQryDummy = gs.toJson(jsonHtpQry.get("HTTP_QUERY"));
							
							json.addProperty("HTTP_QUERY_JSON_DUMMY", htpQryDummy);
							TreeMap<String, String> tm = null;
							
							try {
								tm = KeyParseUtil.parseKeyValues(htpQryDummy);
							} catch(Exception e) {
								log.debug("error {} ln : {} ", idxLn, htpQryDummy);
								
								continue;
							}
							
//							log.debug("{}",KeyParseUtil.parseJsonPathKeys(htpQryDummy));
//							log.debug("{}", tm);
							
							int k = 0;
							
							JsonObject jsonHtpQryParses = new JsonObject(); 
							
							forEnc = new ArrayList<String>();
							forMask = new ArrayList<String>();
							
							for(String t : tm.keySet()) {
								
								k++;
//								System.out.println(t);
								
								if(hm.containsKey(t)) {
//									log.debug("{} = {}, {}", t, tm.get(t), hm.get(t));

									String tmp[] = hm.get(t).toString().split(";");
									
									jsonHtpQryParses.addProperty(tmp[0], tm.get(t));
									
									// move or dump
									switch(tmp[1]) {
									
									case "d":
									case "m":
										jsonHtpQryParses.addProperty(tmp[0], tm.get(t));
										break;										
									
									default:
										
									}									
									
									// enc, mask, full_mask
									switch(tmp[2]) {
									
									case "e":
										forEnc.add(tmp[0]);
										break;

									case "k":
									case "f":
										forMask.add(tmp[0]);
										break;										
									
									default:
										
									}
								}
							}
							
							// merge
							// json , jsonHtpQryParses , jsonAdds 
							
//							log.debug(jsonHtpQryParses.toString());
							
							
							JsonObject jsonAdds = new JsonObject();


							
							
//							CPNT_ID				// HTTP_QUERY.__ID or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
							String sId = getJsonValue(jsonHtpQryParses, "HTP_QRY_ID");
							
							tmpVal = ParseCase.parseCpntId(sId, sReferer);
							if(tmpVal != null) {
								jsonAdds.addProperty("CPNT_ID", tmpVal);
							}
							
//							CPNT_CN_INFO		// HTTP_QUERY.cc or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
							String sCc = getJsonValue(jsonHtpQryParses, "HTP_QRY_CC");
							tmpVal = ParseCase.parseCpntCnInfo(sCc, sReferer);
							if(tmpVal != null) {							
								jsonAdds.addProperty("CPNT_CN_INFO", tmpVal);
							}
							
//							PLM_PDCD			// HTTP_QUERY.PLM_PDCD 단순 파싱 
							String sPlmPdcd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PLM_PDCD");
							tmpVal = ParseCase.parsePlmPdcd(sPlmPdcd);
							if(tmpVal != null) {
								jsonAdds.addProperty("PLM_PDCD", tmpVal);
							}
							
//							PRD_CD				// HTTP_QUERY.PRD_CD or HTTP_REFERER에서 추출
							String sPrdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PRD_CD");
							tmpVal = ParseCase.parsePrdCd(sPrdCd, sReferer);
							if(tmpVal != null) {
								jsonAdds.addProperty("PRD_CD", tmpVal);
							}
							
//							EVENT_NO			// HTTP_QUERY.no 단순 파싱
							String eventNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_NO");
							tmpVal = ParseCase.parseEventNo(eventNo);
							if(tmpVal != null) {
								jsonAdds.addProperty("EVENT_NO", tmpVal);
							}

//							PSNZ_CHNL_KEY		// HTTP_QUERY.m 단순 파싱
							String psnzChnlKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_M");
							tmpVal = ParseCase.parsePsnzChnlKey(psnzChnlKey);
							if(tmpVal != null) {
								jsonAdds.addProperty("PSNZ_CHNL_KEY", tmpVal);
							}
							
							
//							PSNZ_AREA_KEY		// HTTP_QUERY.z 단순 파싱
							String psnzAreaKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_Z");
							tmpVal = ParseCase.parsePsnzAreaKey(psnzAreaKey);
							if(tmpVal != null) {
								jsonAdds.addProperty("PSNZ_AREA_KEY", tmpVal);
							}
							
							
//							PSNZ_SCNR_KEY		// HTTP_QUERY.s 단순 move
							String psnzScnrKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_S");
							if(psnzScnrKey != null) {
								jsonAdds.addProperty("PSNZ_SCNR_KEY", psnzScnrKey);
							}
							
							
//							PSNZ_CTNS_KEY		// HTTP_QUERY.c 단순 파싱
							String psnzCtnsKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_C");
							tmpVal = ParseCase.parsePsnzCtnsKey(psnzCtnsKey);
							if(tmpVal != null) {
								jsonAdds.addProperty("PSNZ_CTNS_KEY", tmpVal);
							}

							
//							PSNZ_TGT_KEY		// HTTP_QUERY.t 단순 파싱
							String psnzTgtKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_T");
							tmpVal = ParseCase.parsePsnzTgtKey(psnzTgtKey);
							if(tmpVal != null) {
								jsonAdds.addProperty("PSNZ_TGT_KEY", tmpVal);
							}
							
							
//							CMD_CD				// HTTP_QUERY.cmd 단순 파싱
							String cmdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_CMD");
							tmpVal = ParseCase.parseCmdCd(cmdCd);
							if(tmpVal != null) {
								jsonAdds.addProperty("CMD_CD", tmpVal);
							}
							
							
//							QR_BR_CD			// HTTP_QUERY.qrBrCd 단순 파싱
							String qrBrCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRBRCD");
							tmpVal = ParseCase.parseQrBrCd(qrBrCd);
							if(tmpVal != null) {
								jsonAdds.addProperty("QR_BR_CD", tmpVal);
							}
							
							
//							QR_ADVPE_NO			// HTTP_QUERY.qrAdvpeNo 단순 파싱
							String sQrAdvpeNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRADVPENO");
							String sQr_advpe_no = getJsonValue(jsonHtpQryParses, "HTP_QRY_QR_ADVPE_NO");
							tmpVal = ParseCase.parseQrAdvpeNo(sQrAdvpeNo, sQr_advpe_no);
							if(tmpVal != null) {
								jsonAdds.addProperty("QR_ADVPE_NO", tmpVal);
							}
							
							
//							INBK_SEARCH_TEXT	// HTTP_QUERY.query 단순 move	
							String inbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_QUERY");
							if(inbkSearchText != null) {
								jsonAdds.addProperty("INBK_SEARCH_TEXT", inbkSearchText);
							}
							
							
//							SMTBK_SEARCH_TEXT	// HTTP_QUERY.searchText 단순 move
							String smtbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_SEARCHTEXT"); 
							if(smtbkSearchText != null) {
								jsonAdds.addProperty("SMTBK_SEARCH_TEXT", smtbkSearchText);
							}
							
							
//							SEARCH_TEXT			// HTTP_QUERY.query or HTTP_QUERY.searchText 에서 추출 단순 파싱
							tmpVal = ParseCase.parseSearchText(inbkSearchText, smtbkSearchText);
							if(tmpVal != null) {
								jsonAdds.addProperty("SEARCH_TEXT", tmpVal);
							}
							
							
							
//							PAGE_ID				// HTTP_QUERY.withyou or HTTP_REFERER에서 추출 - 복합 파싱 
							String withyou = getJsonValue(jsonHtpQryParses, "HTP_QRY_WITHYOU");
							tmpVal = ParseCase.parsePageId(withyou, sReferer);
							if(tmpVal != null) {
								jsonAdds.addProperty("PAGE_ID", tmpVal);
							}
							
							
//							PAGE_STEP_ORDER		// HTTP_QUERY.__STEP or HTTP_REFERER에서 추출 - 복합 파싱, psnz_chnl_key == 30002 --> psnz_scnr_key
							String step = getJsonValue(jsonHtpQryParses, "HTP_QRY___STEP"); 
							
							if("30002".equals(psnzChnlKey)) {
								tmpVal = ParseCase.parsePageStepOrder(sReferer, psnzScnrKey, step);
								if(tmpVal != null) {
									jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
								}
							} else {
								tmpVal = ParseCase.parsePageStepOrder(sReferer, step);
								if(tmpVal != null) {
									jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
								}
							}
							

//							log.debug("jsonAdds :  {}", jsonAdds.toString());							
							
							
							if(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA") != null
									&& jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA") != null
									&& !jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA").isJsonNull()
									) {
								
								// acno : .HTTP_QUERY.ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.ACNO	+ 암호화	
								String acno = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "ACNO"); 
								String htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
								tmpVal = ParseCase.parseAcno(acno, htpAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("ACNO", tmpVal);
									forEnc.add("ACNO");
								}
								

								//	bkcd : .HTTP_QUERY.BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.BKCD
								String bkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "BKCD");
								String htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
								tmpVal = ParseCase.parseBkcd(bkcd, htpBkcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("BKCD", tmpVal);
								}

								
								//	inq_acno : .HTTP_QUERY.INQ_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.INQ_ACNO + 암호화 	
								String inqAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "INQ_ACNO");
								String htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
								tmpVal = ParseCase.parseInqAcno(inqAcNo, htpInqAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("INQ_ACNO", tmpVal);
									forEnc.add("INQ_ACNO");
								}
								
								
								// wdr_bkcd : .HTTP_QUERY.WDR_BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_BKCD
								String wdrBkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_BKCD");
								String htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
								tmpVal = ParseCase.parseWdrBkcd(wdrBkcd, htpWdrBkcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("WDR_BKCD", tmpVal);
								}
							
								
								// wdr_acno : .HTTP_QUERY.WDR_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_ACNO + 암호화	
								String wdrAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_ACNO");
								String htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
								tmpVal = ParseCase.parseInqAcno(wdrAcNo, htpWdrAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("WDR_ACNO", tmpVal);
									forEnc.add("WDR_ACNO");
								}
								
							} else {
								
								
								String htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
								tmpVal = ParseCase.parseAcno(htpAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("ACNO", tmpVal);
									forEnc.add("ACNO");
								}
								
								String htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
								tmpVal = ParseCase.parseBkcd(htpBkcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("BKCD", tmpVal);
								}
								
								String htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
								tmpVal = ParseCase.parseInqAcno(htpInqAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("INQ_ACNO", tmpVal);
									forEnc.add("INQ_ACNO");
								}
								
								String htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
								tmpVal = ParseCase.parseWdrBkcd(htpWdrBkcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("WDR_BKCD", tmpVal);
								}

								String htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
								tmpVal = ParseCase.parseInqAcno(htpWdrAcno);
								if(tmpVal != null) {
									jsonAdds.addProperty("WDR_ACNO", tmpVal);
									forEnc.add("WDR_ACNO");								
								}
							}
							
							forEnc.add("HTTP_QUERY");
							forEnc.add("HTTP_QUERY_JSON_DUMMY");
							
							
							// 만들어야 될것
							// json merge util
//							JsonUtil.merge(obj);
							
							
							// key 존재 유무 util + trim 포함
							// 일반 httpQry 암호화 처리 로직 추가							
							
							
							// 나머지 http 항목 머지
							// 항목 중에 암호화 대상 암호화 처리
					
							
//							log.debug("json : {}", json.toString());
//							log.debug("jsonHtpQryParses : {}", jsonHtpQryParses.toString());
//							log.debug("jsonAdds : {}", jsonAdds.toString());
							
							
							json = JsonUtil.merge(json, jsonAdds, jsonHtpQryParses);
							
							
//							log.debug("json total : {}", json.toString());
							
								
						} else { // jsonHtpQry가 null 일 경우 ( json화 가능한 포맷이 아니라서 파싱이 되지 않는 경우 )
							
							
							json.add("HTTP_QUERY_JSON_DUMMY", null);
							
//							cpnt_id				// HTTP_REFERER에서 __ID 추출
							tmpVal = ParseCase.parseCpntId(null, sReferer);
							if(tmpVal != null) {
								json.addProperty("CPNT_ID", tmpVal);
							}
							
//							cpnt_cn_info		// HTTP_REFERER에서 cc 추출
							tmpVal = ParseCase.parseCpntCnInfo(null, sReferer);
							if(tmpVal != null) {
								json.addProperty("CPNT_CN_INFO", tmpVal);
							}
							
//							prd_cd				// HTTP_REFERER에서 PRD_CD 추출
							tmpVal = ParseCase.parsePrdCd(null, sReferer);
							if(tmpVal != null) {
								json.addProperty("PRD_CD", tmpVal);
							}
							
							
//							page_id				// HTTP_REFERER에서 withyou 추출 - 복합 파싱
							tmpVal = ParseCase.parsePageId(null, sReferer);
							if(tmpVal != null) {
								json.addProperty("PAGE_ID", tmpVal);
							}
							
//							page_step_order		// HTTP_REFERER에서 __STEP 추출 - 복합 파싱
							tmpVal = ParseCase.parsePageStepOrder(sReferer, "" );
							if(tmpVal != null) {
								json.addProperty("PAGE_STEP_ORDER", tmpVal);
							}
							
							
//							log.debug("json : {}", json.toString());							
							
						}
							
					}

					
//					log.debug("forEnc : {}", forEnc != null ? forEnc.toString() : null);
//					log.debug("forMask : {}", forMask != null ? forMask.toString() : null);
					
//					log.debug(json.toString());			
					
					
					// 처리한 내역 file write
					
					String rsltStr = gs.toJson(json) + "\n";
					
					owr.write(rsltStr);
					
					
					JsonObject jtmp = json;
					
					boolean enc = true;
					
					if(enc == true && json != null) {
						
						if( forEnc != null && !forEnc.isEmpty() ) {
							for(String enckey : forEnc ) {
								
//								log.debug("enckey {} -- {}",enckey, json.get(enckey));
								
								if(jtmp.get(enckey) != null 
										&& !jtmp.get(enckey).isJsonNull()
										&& !jtmp.get(enckey).getAsString().trim().isEmpty()
								) {
									String encStr = DamoEncUtil.data_encryption(jtmp.get(enckey).getAsString(), "string");
									jtmp.addProperty(enckey, encStr);
								}
								
							}
						}
						
						if( forMask != null && !forMask.isEmpty() ) {
							
							for(String maskkey : forEnc ) {
							
								if(jtmp.get(maskkey) != null
										&& !jtmp.get(maskkey).isJsonNull()
										&& !jtmp.get(maskkey).getAsString().trim().isEmpty()
								) {
//									String maskStr = jtmp.get(maskkey).getAsString().replaceAll(".", "*");
									String maskStr = "*****";
//									log.debug(maskStr);					
									jtmp.addProperty(maskkey, maskStr);
								}
								
							}
						}						
						
					}
					

					
				}
				
				owr.close();
				br.close();
				
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				log.debug("{}",idxLn);
				e.printStackTrace();
			}
			
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}			
	
	

	// 향후 keys 받는 외부 함수로 인자 변경 처리
	public void fileLogOrgToMstJsonFileImdg(final String SRC_PATH, final String TGT_PATH) {

		StopWatch swch = new StopWatch("fileLogOrgToMstJsonFile");
		swch.start("step001");

//		Configuration jsonPathConf = Configuration.builder()
//				.mappingProvider(new GsonMappingProvider())
//				.jsonProvider(new GsonJsonProvider())
////				.options(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS)
//				.options(Option.SUPPRESS_EXCEPTIONS)
//				.build();
		
		
		File src = new File(SRC_PATH);
		
//		List<File> srcFiles = new ArrayList<File>();
//
//		try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(SRC_PATH), "*.{json}")) {
//
//			dirStream.forEach(path -> {
//				log.debug("path : {}", path.toString());
//				srcFiles.add(path.toFile());
//			});
//
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		}
		
		
		Gson gs = new Gson();
		JsonObject json = null;
		JsonObject jsonHtpQry = null;
		
		String rsltJsonStr = null;
		long idxLn = 0L;
		
		TreeMap<String, Object> hm = new TreeMap<String, Object>();
		
		hm.put("withyou", "HTP_QRY_WITHYOU;m;x");
		hm.put("_COM_SMT_UNIQUEID_FDS", "HTP_QRY__COM_SMT_UNIQUEID_FDS;m;x");
		hm.put("_COM_SMT_UNIQUEID", "HTP_QRY__COM_SMT_UNIQUEID;m;x");
		hm.put("isPhone", "HTP_QRY_ISPHONE;m;x");
		hm.put("_JSON_DATA", "HTP_QRY__JSON_DATA;d;e");
		hm.put("_COM_SSAID", "HTP_QRY__COM_SSAID;m;x");
		hm.put("_SYSTEM_MDI_KDCD", "HTP_QRY__SYSTEM_MDI_KDCD;m;x");
		hm.put("DEVICE_ID_GROUP", "HTP_QRY_DEVICE_ID_GROUP;m;x");
		hm.put("__ID", "HTP_QRY___ID;m;x");
		hm.put("PHONE_TYPE", "HTP_QRY_PHONE_TYPE;m;x");
		hm.put("transkey_i", "HTP_QRY_TRANSKEY_I;m;x");
		hm.put("transkey_inputs", "HTP_QRY_TRANSKEY_INPUTS;m;x");
		hm.put("transkeyUuid", "HTP_QRY_TRANSKEYUUID;m;x");
		hm.put("cmd", "HTP_QRY_CMD;m;x");
		hm.put("PID", "HTP_QRY_PID;m;x");
		hm.put("reqBizId", "HTP_QRY_REQBIZID;m;x");
		hm.put("CNCT_PATH", "HTP_QRY_CNCT_PATH;m;x");
		hm.put("svcGb", "HTP_QRY_SVCGB;m;x");
		hm.put("svcUrl", "HTP_QRY_SVCURL;m;x");
		hm.put("dontUseSes", "HTP_QRY_DONTUSESES;m;x");
		hm.put("datatype", "HTP_QRY_DATATYPE;m;x");
		hm.put("searchText", "HTP_QRY_SEARCHTEXT;m;x");
		hm.put("deviceGubn", "HTP_QRY_DEVICEGUBN;m;x");
		hm.put("charset", "HTP_QRY_CHARSET;m;x");
		hm.put("range", "HTP_QRY_RANGE;m;x");
		hm.put("collection", "HTP_QRY_COLLECTION;m;x");
		hm.put("INQ_ACNO", "HTP_QRY_INQ_ACNO;m;e");
		hm.put("cc", "HTP_QRY_CC;m;x");
		hm.put("target", "HTP_QRY_TARGET;m;x");
		hm.put("CUCD", "HTP_QRY_CUCD;m;x");
		hm.put("SBJCD_2", "HTP_QRY_SBJCD_2;m;x");
		hm.put("AccName", "HTP_QRY_ACCNAME;m;x");
		hm.put("USER_ID", "HTP_QRY_USER_ID;m;x");
		hm.put("AccGbn", "HTP_QRY_ACCGBN;m;x");
		hm.put("__E2E_UNIQUE__", "HTP_QRY___E2E_UNIQUE__;m;x");
		hm.put("__E2E_RESULT__", "HTP_QRY___E2E_RESULT__;m;x");
		hm.put("INQ_END_DT", "HTP_QRY_INQ_END_DT;m;x");
		hm.put("STR_NM", "HTP_QRY_STR_NM;m;e");
		hm.put("CUCD_3", "HTP_QRY_CUCD_3;m;x");
		hm.put("PBOK_BAL", "HTP_QRY_PBOK_BAL;m;x");
		hm.put("ACT_PWNO", "HTP_QRY_ACT_PWNO;m;f");
		hm.put("__STEP", "HTP_QRY___STEP;m;x");
		hm.put("LN_ACNO", "HTP_QRY_LN_ACNO;m;e");
		hm.put("CRCD_3", "HTP_QRY_CRCD_3;m;x");
		hm.put("INQ_STA_DT", "HTP_QRY_INQ_STA_DT;m;x");
		hm.put("OWAC_FNM", "HTP_QRY_OWAC_FNM;m;k");
		hm.put("PSNBZ_RGS_YN", "HTP_QRY_PSNBZ_RGS_YN;m;x");
		hm.put("WDR_ACNO", "HTP_QRY_WDR_ACNO;m;e");
		hm.put("ACNO", "HTP_QRY_ACNO;m;e");
		hm.put("VID_MSG", "HTP_QRY_VID_MSG;m;x");
		hm.put("NEW_ACNO", "HTP_QRY_NEW_ACNO;m;e");
		hm.put("m", "HTP_QRY_M;m;x");
		hm.put("afwdata", "HTP_QRY_AFWDATA;m;x");
		hm.put("z", "HTP_QRY_Z;m;x");
		hm.put("ac", "HTP_QRY_AC;m;x");
		hm.put("INQ_ACNO_15", "HTP_QRY_INQ_ACNO_15;m;e");
		hm.put("defSelAcctNo", "HTP_QRY_DEFSELACCTNO;m;e");
		hm.put("PWD", "HTP_QRY_PWD;m;f");
		hm.put("SBJCD_3", "HTP_QRY_SBJCD_3;m;x");
		hm.put("_INSIDE_NAT", "HTP_QRY__INSIDE_NAT;m;x");
		hm.put("NCM", "HTP_QRY_NCM;m;x");
		hm.put("transkey_hMac_Tk_PWD", "HTP_QRY_TRANSKEY_HMAC_TK_PWD;m;x");
		hm.put("transkey_Tk_PWD", "HTP_QRY_TRANSKEY_TK_PWD;m;f");
		hm.put("loginGubun", "HTP_QRY_LOGINGUBUN;m;x");
		hm.put("rSelect", "HTP_QRY_RSELECT;m;x");
		hm.put("NEXT_YN_EXT", "HTP_QRY_NEXT_YN_EXT;m;x");
		hm.put("RCV_ACNO", "HTP_QRY_RCV_ACNO;m;e");
		hm.put("DPKD_10", "HTP_QRY_DPKD_10;m;x");
		hm.put("Tk_PWD_check", "HTP_QRY_TK_PWD_CHECK;m;x");
		hm.put("PWD__E2E__", "HTP_QRY_PWD__E2E__;m;f");
		hm.put("NEW_DT", "HTP_QRY_NEW_DT;m;x");
		hm.put("ACT_MNG_BRCD", "HTP_QRY_ACT_MNG_BRCD;m;x");
		hm.put("CO_CUS_MST_ID", "HTP_QRY_CO_CUS_MST_ID;m;x");
		hm.put("TBL_NM", "HTP_QRY_TBL_NM;m;x");
		hm.put("ACTNO", "HTP_QRY_ACTNO;m;e");
		hm.put("TS_EXE_TM_DIS", "HTP_QRY_TS_EXE_TM_DIS;m;x");
		hm.put("ipinsideData", "HTP_QRY_IPINSIDEDATA;m;x");
		hm.put("ipinsideNAT", "HTP_QRY_IPINSIDENAT;m;x");
		hm.put("ipinsideCOMM", "HTP_QRY_IPINSIDECOMM;m;x");
		hm.put("DPS_INP_ACNO", "HTP_QRY_DPS_INP_ACNO;m;e");
		hm.put("_SYSEN_TRNO", "HTP_QRY__SYSEN_TRNO;m;x");
		hm.put("flag", "HTP_QRY_FLAG;m;x");
		hm.put("TRN_AM", "HTP_QRY_TRN_AM;m;x");
		hm.put("addDepYN", "HTP_QRY_ADDDEPYN;m;x");
		hm.put("sGoodsAccnoIndex", "HTP_QRY_SGOODSACCNOINDEX;m;x");
		hm.put("TS_GUBUN", "HTP_QRY_TS_GUBUN;m;x");
		hm.put("DPBAL_13", "HTP_QRY_DPBAL_13;m;x");
		hm.put("SCREEN_GB", "HTP_QRY_SCREEN_GB;m;x");
		hm.put("DETAIL_GB", "HTP_QRY_DETAIL_GB;m;x");
		hm.put("RCV_BKCD", "HTP_QRY_RCV_BKCD;m;x");
		hm.put("ACTPWNO_8", "HTP_QRY_ACTPWNO_8;m;f");
		hm.put("NEW_DPS_INP_ACNO", "HTP_QRY_NEW_DPS_INP_ACNO;m;e");
		hm.put("isIcheAccNo", "HTP_QRY_ISICHEACCNO;m;x");
		hm.put("NEW_INQ_ACNO", "HTP_QRY_NEW_INQ_ACNO;m;e");
		hm.put("ACTPWNO", "HTP_QRY_ACTPWNO;m;f");
		hm.put("TS_EXE_DT", "HTP_QRY_TS_EXE_DT;m;x");
		hm.put("WOORI_09", "HTP_QRY_WOORI_09;m;x");
		hm.put("PAYDACBR_3", "HTP_QRY_PAYDACBR_3;m;x");
		hm.put("RCVDACBR_3", "HTP_QRY_RCVDACBR_3;m;x");
		hm.put("PAYDACCMOD_1", "HTP_QRY_PAYDACCMOD_1;m;x");
		hm.put("RCV_LMT_ACNO", "HTP_QRY_RCV_LMT_ACNO;m;e");
		hm.put("useMemoYN", "HTP_QRY_USEMEMOYN;m;x");
		hm.put("WDRAVLBAL_13", "HTP_QRY_WDRAVLBAL_13;m;x");
		hm.put("PDCD", "HTP_QRY_PDCD;m;x");
		hm.put("EDDT", "HTP_QRY_EDDT;m;x");
		hm.put("STDT", "HTP_QRY_STDT;m;x");
		hm.put("TSRGSYN_1", "HTP_QRY_TSRGSYN_1;m;x");
		hm.put("reTry", "HTP_QRY_RETRY;m;x");
		hm.put("afudata", "HTP_QRY_AFUDATA;m;x");
		hm.put("privateIpUdata", "HTP_QRY_PRIVATEIPUDATA;m;x");
		hm.put("COST_CD", "HTP_QRY_COST_CD;m;x");
		hm.put("DOTCOM_MEMO_YN", "HTP_QRY_DOTCOM_MEMO_YN;m;x");
		hm.put("WDR_ACNO_MEMO_GUBUN", "HTP_QRY_WDR_ACNO_MEMO_GUBUN;m;x");
		hm.put("PBOK_KD", "HTP_QRY_PBOK_KD;m;x");
		hm.put("PRN_NO_13", "HTP_QRY_PRN_NO_13;m;x");
		hm.put("ACT_PWNO_USE_YN", "HTP_QRY_ACT_PWNO_USE_YN;m;x");
		hm.put("GUBUN", "HTP_QRY_GUBUN;m;x");
		hm.put("ACTNO_15", "HTP_QRY_ACTNO_15;m;e");
		hm.put("FEXEM_YN", "HTP_QRY_FEXEM_YN;m;x");
		hm.put("FAVOR_ACCTNO_CHK", "HTP_QRY_FAVOR_ACCTNO_CHK;m;x");
		hm.put("PROCDIV_2", "HTP_QRY_PROCDIV_2;m;x");
		hm.put("TEL_14", "HTP_QRY_TEL_14;m;f");
		hm.put("WDR_ACNO_TEXT", "HTP_QRY_WDR_ACNO_TEXT;m;x");
		hm.put("isCertLoginYN", "HTP_QRY_ISCERTLOGINYN;m;x");
		hm.put("CT_BAL", "HTP_QRY_CT_BAL;m;x");
		hm.put("PTN_PBOK_PRNG_TXT", "HTP_QRY_PTN_PBOK_PRNG_TXT;m;x");
		hm.put("HP_NO_1", "HTP_QRY_HP_NO_1;m;f");
		hm.put("TAX_CD", "HTP_QRY_TAX_CD;m;x");
		hm.put("END_DATE", "HTP_QRY_END_DATE;m;x");
		hm.put("CUR_CD_3", "HTP_QRY_CUR_CD_3;m;x");
		hm.put("SeqNO", "HTP_QRY_SEQNO;m;x");
		hm.put("HP_NO_3", "HTP_QRY_HP_NO_3;m;f");
		hm.put("HP_NO_2", "HTP_QRY_HP_NO_2;m;f");
		hm.put("INQ_YEAR", "HTP_QRY_INQ_YEAR;m;x");
		hm.put("INQ_MONTH", "HTP_QRY_INQ_MONTH;m;x");
		hm.put("START_DATE", "HTP_QRY_START_DATE;m;x");
		hm.put("INQ_STA_NO", "HTP_QRY_INQ_STA_NO;m;x");
		hm.put("tabFlag", "HTP_QRY_TABFLAG;m;x");
		hm.put("otherAcc", "HTP_QRY_OTHERACC;m;e");
		hm.put("INQ_SEQ_DIS", "HTP_QRY_INQ_SEQ_DIS;m;x");
		hm.put("sort", "HTP_QRY_SORT;m;x");
		hm.put("isOnlySearchTxt", "HTP_QRY_ISONLYSEARCHTXT;m;x");
		hm.put("IsMST", "HTP_QRY_ISMST;m;x");
		hm.put("START_DATEY", "HTP_QRY_START_DATEY;m;x");
		hm.put("START_DATEM", "HTP_QRY_START_DATEM;m;x");
		hm.put("START_DATED", "HTP_QRY_START_DATED;m;x");
		hm.put("step", "HTP_QRY_STEP;m;x");
		hm.put("TRNNO_3", "HTP_QRY_TRNNO_3;m;x");
		hm.put("TOT_DPBAL_13", "HTP_QRY_TOT_DPBAL_13;m;x");
		hm.put("TOT_LOANBAL_13", "HTP_QRY_TOT_LOANBAL_13;m;x");
		hm.put("END_DATED", "HTP_QRY_END_DATED;m;x");
		hm.put("END_DATEY", "HTP_QRY_END_DATEY;m;x");
		hm.put("END_DATEM", "HTP_QRY_END_DATEM;m;x");
		hm.put("Term", "HTP_QRY_TERM;m;x");
		hm.put("sorder", "HTP_QRY_SORDER;m;x");
		hm.put("check_seqno", "HTP_QRY_CHECK_SEQNO;m;x");
		hm.put("isFirstInqSvr", "HTP_QRY_ISFIRSTINQSVR;m;x");
		hm.put("INQ_TGT_DIS", "HTP_QRY_INQ_TGT_DIS;m;x");
		hm.put("EDDTM", "HTP_QRY_EDDTM;m;x");
		hm.put("STDTD", "HTP_QRY_STDTD;m;x");
		hm.put("STDTM", "HTP_QRY_STDTM;m;x");
		hm.put("STDTY", "HTP_QRY_STDTY;m;x");
		hm.put("EDDTY", "HTP_QRY_EDDTY;m;x");
		hm.put("EDDTD", "HTP_QRY_EDDTD;m;x");
		hm.put("check_date", "HTP_QRY_CHECK_DATE;m;x");
		hm.put("FXMRK_YN", "HTP_QRY_FXMRK_YN;m;x");
		hm.put("isOnlySwing", "HTP_QRY_ISONLYSWING;m;x");
		hm.put("sort1", "HTP_QRY_SORT1;m;x");
		hm.put("divTemp", "HTP_QRY_DIVTEMP;m;x");
		hm.put("RNPE_FNM", "HTP_QRY_RNPE_FNM;m;k");
		hm.put("CTIN_INQ_TRNDT", "HTP_QRY_CTIN_INQ_TRNDT;m;x");
		hm.put("CTIN_INQ_TRNO", "HTP_QRY_CTIN_INQ_TRNO;m;x");
		hm.put("girdDrawYn", "HTP_QRY_GIRDDRAWYN;m;x");
		hm.put("DAT_CNT", "HTP_QRY_DAT_CNT;m;x");
		hm.put("RSV_DT", "HTP_QRY_RSV_DT;m;x");
		hm.put("FEE", "HTP_QRY_FEE;m;x");
		hm.put("WDR_ACNO_TEXT_MEMO", "HTP_QRY_WDR_ACNO_TEXT_MEMO;m;x");
		hm.put("PRINT_DATA", "HTP_QRY_PRINT_DATA;m;x");
		hm.put("INQ_TGT_DIS_1", "HTP_QRY_INQ_TGT_DIS_1;m;x");
		hm.put("TRN_SRNO", "HTP_QRY_TRN_SRNO;m;x");
		hm.put("FAVOR_HP_NO", "HTP_QRY_FAVOR_HP_NO;m;f");
		hm.put("WBF_DUP_CHECK_KEY", "HTP_QRY_WBF_DUP_CHECK_KEY;m;x");
		hm.put("SIGN_KEYS", "HTP_QRY_SIGN_KEYS;m;x");
		hm.put("TRN_DT", "HTP_QRY_TRN_DT;m;x");
		hm.put("TRN_TM", "HTP_QRY_TRN_TM;m;x");
		hm.put("FAVOR_EML", "HTP_QRY_FAVOR_EML;m;f");
		hm.put("_RANDOM_NUM", "HTP_QRY__RANDOM_NUM;m;x");
		hm.put("INQ_SEQ_DIS_1", "HTP_QRY_INQ_SEQ_DIS_1;m;x");
		hm.put("ACT_PWNO_10", "HTP_QRY_ACT_PWNO_10;m;f");
		hm.put("isNotData", "HTP_QRY_ISNOTDATA;m;x");
		hm.put("TRNO", "HTP_QRY_TRNO;m;x");
		hm.put("TRN_INQ_MTD", "HTP_QRY_TRN_INQ_MTD;m;x");
		hm.put("INQ_STA_DD", "HTP_QRY_INQ_STA_DD;m;x");
		hm.put("WDR_ACNO_MEMO", "HTP_QRY_WDR_ACNO_MEMO;m;x");
		hm.put("DPPE_NM", "HTP_QRY_DPPE_NM;m;k");
		hm.put("isCodeInq", "HTP_QRY_ISCODEINQ;m;x");
		hm.put("P_RCVCNT", "HTP_QRY_P_RCVCNT;m;x");
		hm.put("CLNM_NO_ADD_SBJ", "HTP_QRY_CLNM_NO_ADD_SBJ;m;x");
		hm.put("TOTAL_CNT", "HTP_QRY_TOTAL_CNT;m;x");
		hm.put("NEXT_YN_HOST", "HTP_QRY_NEXT_YN_HOST;m;x");
		hm.put("TRN_TXT", "HTP_QRY_TRN_TXT;m;k");
		hm.put("RCV_AM", "HTP_QRY_RCV_AM;m;x");
		hm.put("RSTT_YN", "HTP_QRY_RSTT_YN;m;x");
		hm.put("PAY_AM", "HTP_QRY_PAY_AM;m;x");
		hm.put("isNoDate", "HTP_QRY_ISNODATE;m;x");
		hm.put("gridData", "HTP_QRY_GRIDDATA;m;x");
		hm.put("DIV_TRAN_GB", "HTP_QRY_DIV_TRAN_GB;m;x");
		hm.put("DIV_TRAN_CNT", "HTP_QRY_DIV_TRAN_CNT;m;x");
		hm.put("RECV_CNT", "HTP_QRY_RECV_CNT;m;x");
		hm.put("WOORI_YN", "HTP_QRY_WOORI_YN;m;x");
		hm.put("OBR_AM", "HTP_QRY_OBR_AM;m;x");
		hm.put("TR_DIS", "HTP_QRY_TR_DIS;m;x");
		hm.put("BRANCH", "HTP_QRY_BRANCH;m;x");
		hm.put("ExtUseYN", "HTP_QRY_EXTUSEYN;m;x");
		hm.put("INQ_TYPE_DIS_1", "HTP_QRY_INQ_TYPE_DIS_1;m;x");
		hm.put("PAYAVL_AM", "HTP_QRY_PAYAVL_AM;m;x");
		hm.put("PBOK_LN_LMT_AM_18", "HTP_QRY_PBOK_LN_LMT_AM_18;m;x");
		hm.put("TRN_MSG", "HTP_QRY_TRN_MSG;m;x");
		hm.put("BL_AM", "HTP_QRY_BL_AM;m;x");
		hm.put("AccNO", "HTP_QRY_ACCNO;m;e");
		hm.put("_ROOT_CHECK_RESULT", "HTP_QRY__ROOT_CHECK_RESULT;m;x");
		hm.put("_ROOT_CHECK_RESULT_CODE", "HTP_QRY__ROOT_CHECK_RESULT_CODE;m;x");
		hm.put("INQ_DT_BSDT_10", "HTP_QRY_INQ_DT_BSDT_10;m;x");
		hm.put("ACTPWNO_4", "HTP_QRY_ACTPWNO_4;m;f");
		hm.put("PSNBIZPENO_7", "HTP_QRY_PSNBIZPENO_7;m;x");
		hm.put("loginType", "HTP_QRY_LOGINTYPE;m;x");
		hm.put("DIV", "HTP_QRY_DIV;m;x");
		hm.put("ACTNO_14", "HTP_QRY_ACTNO_14;m;e");
		hm.put("LN_KD", "HTP_QRY_LN_KD;m;x");
		hm.put("E2E_FLAG", "HTP_QRY_E2E_FLAG;m;x");
		hm.put("TLBNK_UTZPE_IDF_NO", "HTP_QRY_TLBNK_UTZPE_IDF_NO;m;x");
		hm.put("custName", "HTP_QRY_CUSTNAME;m;k");
		hm.put("PAY_AVL_AM", "HTP_QRY_PAY_AVL_AM;m;x");
		hm.put("ONE_PRC_CN_3", "HTP_QRY_ONE_PRC_CN_3;m;e");
		hm.put("RAP_DSCD", "HTP_QRY_RAP_DSCD;m;x");
		hm.put("INQ_STA_DTD", "HTP_QRY_INQ_STA_DTD;m;x");
		hm.put("INQ_STA_DTM", "HTP_QRY_INQ_STA_DTM;m;x");
		hm.put("INQ_STA_DTY", "HTP_QRY_INQ_STA_DTY;m;x");
		hm.put("INQ_END_DTD", "HTP_QRY_INQ_END_DTD;m;x");
		hm.put("INQ_END_DTM", "HTP_QRY_INQ_END_DTM;m;x");
		hm.put("INQ_END_DTY", "HTP_QRY_INQ_END_DTY;m;x");
		hm.put("HP_NO", "HTP_QRY_HP_NO;m;f");
		hm.put("CUR_3", "HTP_QRY_CUR_3;m;x");
		hm.put("MEMBERS_ROW", "HTP_QRY_MEMBERS_ROW;m;x");
		hm.put("checkph", "HTP_QRY_CHECKPH;m;x");
		hm.put("chk_mobile", "HTP_QRY_CHK_MOBILE;m;x");
		hm.put("WDRACTNO_15", "HTP_QRY_WDRACTNO_15;m;e");
		hm.put("RSVEXEDY_8", "HTP_QRY_RSVEXEDY_8;m;x");
		hm.put("RCVNM", "HTP_QRY_RCVNM;m;x");
		hm.put("CTIN_TRN_SRNO", "HTP_QRY_CTIN_TRN_SRNO;m;x");
		hm.put("CTIN_DAT_OUP_YN", "HTP_QRY_CTIN_DAT_OUP_YN;m;x");
		hm.put("RCPENM_20", "HTP_QRY_RCPENM_20;m;k");
		hm.put("CNTR_CPRS", "HTP_QRY_CNTR_CPRS;m;x");
		hm.put("TRBK_GICD", "HTP_QRY_TRBK_GICD;m;x");
		hm.put("method_cert", "HTP_QRY_METHOD_CERT;m;x");
		hm.put("transkey_hMac_Tk_pup02", "HTP_QRY_TRANSKEY_HMAC_TK_PUP02;m;x");
		hm.put("transkey_Tk_pup02", "HTP_QRY_TRANSKEY_TK_PUP02;m;x");
		hm.put("CertSendReqCNTAN", "HTP_QRY_CERTSENDREQCNTAN;m;x");
		hm.put("CERT_DIS", "HTP_QRY_CERT_DIS;m;x");
		hm.put("CertSendReqCNTIOS", "HTP_QRY_CERTSENDREQCNTIOS;m;x");
		hm.put("ELTPAYNO_19", "HTP_QRY_ELTPAYNO_19;m;e");
		hm.put("IP_SEQ", "HTP_QRY_IP_SEQ;m;x");
		hm.put("TOTAL_CNT_2", "HTP_QRY_TOTAL_CNT_2;m;x");
		hm.put("MON_RENT_YN", "HTP_QRY_MON_RENT_YN;m;x");
		hm.put("NRSD_6_1", "HTP_QRY_NRSD_6_1;m;x");
		hm.put("NRSD_6_2", "HTP_QRY_NRSD_6_2;m;x");
		hm.put("RQ_STL_NO_4", "HTP_QRY_RQ_STL_NO_4;m;x");
		hm.put("IN_CLIENT_NAME_22", "HTP_QRY_IN_CLIENT_NAME_22;m;k");
		hm.put("FEE_5", "HTP_QRY_FEE_5;m;x");
		hm.put("lateTransDetail", "HTP_QRY_LATETRANSDETAIL;m;x");
		hm.put("CERT_SIGNED_USE", "HTP_QRY_CERT_SIGNED_USE;m;x");
		hm.put("MEMBERS_INQ", "HTP_QRY_MEMBERS_INQ;m;x");
		hm.put("MEMBERS_DIS_FEE", "HTP_QRY_MEMBERS_DIS_FEE;m;x");
		hm.put("CNTR_IST", "HTP_QRY_CNTR_IST;m;x");
		hm.put("CNTR_ICHE_YN", "HTP_QRY_CNTR_ICHE_YN;m;x");
		hm.put("CNTR_ACNO", "HTP_QRY_CNTR_ACNO;m;e");
		hm.put("CNTR_AM", "HTP_QRY_CNTR_AM;m;x");
		hm.put("RPS_PEN_YN", "HTP_QRY_RPS_PEN_YN;m;x");
		hm.put("IS_CHD_MSG_TS", "HTP_QRY_IS_CHD_MSG_TS;m;x");
		hm.put("WDR_NOTI_REG", "HTP_QRY_WDR_NOTI_REG;m;x");
		hm.put("WDR_NOTI_INOT_SMS_FR_TM", "HTP_QRY_WDR_NOTI_INOT_SMS_FR_TM;m;x");
		hm.put("COUNT_TRANS_FER_RES", "HTP_QRY_COUNT_TRANS_FER_RES;m;x");
		hm.put("COUNT_SUPPROT", "HTP_QRY_COUNT_SUPPROT;m;x");
		hm.put("WDR_NOTI_INOT_SMS_TO_TM", "HTP_QRY_WDR_NOTI_INOT_SMS_TO_TM;m;x");
		hm.put("WDR_NOTI_AUTO_YN", "HTP_QRY_WDR_NOTI_AUTO_YN;m;x");
		hm.put("WDR_NOTI_MONEY_INOUT", "HTP_QRY_WDR_NOTI_MONEY_INOUT;m;x");
		hm.put("WDR_NOTI_AMT_VIEW_YN", "HTP_QRY_WDR_NOTI_AMT_VIEW_YN;m;x");
		hm.put("COUNT_TRANS_FER", "HTP_QRY_COUNT_TRANS_FER;m;x");
		hm.put("WDR_NOTI_SEND_AMT_SLT", "HTP_QRY_WDR_NOTI_SEND_AMT_SLT;m;x");
		hm.put("WDR_NOTI_HP_NO1_12", "HTP_QRY_WDR_NOTI_HP_NO1_12;m;x");
		hm.put("WDR_NOTI_WDR_ACCT", "HTP_QRY_WDR_NOTI_WDR_ACCT;m;e");
		hm.put("WDR_NOTI_SEND_AMT", "HTP_QRY_WDR_NOTI_SEND_AMT;m;f");
		hm.put("lateTransTimetxt", "HTP_QRY_LATETRANSTIMETXT;m;x");
		hm.put("FEE_RCVCNT", "HTP_QRY_FEE_RCVCNT;m;x");
		hm.put("feeInqYN", "HTP_QRY_FEEINQYN;m;x");
		hm.put("MEMBERS_GBN", "HTP_QRY_MEMBERS_GBN;m;x");
		hm.put("TS_SUMTRANSFERRESAMT", "HTP_QRY_TS_SUMTRANSFERRESAMT;m;x");
		hm.put("favFavSize", "HTP_QRY_FAVFAVSIZE;m;x");
		hm.put("DanGi_YN", "HTP_QRY_DANGI_YN;m;x");
		hm.put("RCVBNKCD_2", "HTP_QRY_RCVBNKCD_2;m;x");
		hm.put("STL_DT_8", "HTP_QRY_STL_DT_8;m;x");
		hm.put("PBOKMNTNHIS_20", "HTP_QRY_PBOKMNTNHIS_20;m;x");
		hm.put("APV_APL_DIS", "HTP_QRY_APV_APL_DIS;m;x");
		hm.put("MMDA_YN", "HTP_QRY_MMDA_YN;m;x");
		hm.put("SER_NO_3", "HTP_QRY_SER_NO_3;m;x");
		hm.put("ACT_BL_18", "HTP_QRY_ACT_BL_18;m;x");
		hm.put("LOGIN_GBN", "HTP_QRY_LOGIN_GBN;m;x");
		hm.put("TRNAM_13", "HTP_QRY_TRNAM_13;m;x");
		hm.put("Accnick", "HTP_QRY_ACCNICK;m;x");
		hm.put("PBOK_KD_4", "HTP_QRY_PBOK_KD_4;m;x");
		hm.put("MBRCO_MBR_NO_15", "HTP_QRY_MBRCO_MBR_NO_15;m;x");
		hm.put("LN_MTD", "HTP_QRY_LN_MTD;m;x");
		hm.put("NTRNN_ACT_YN", "HTP_QRY_NTRNN_ACT_YN;m;x");
		hm.put("SMT_YN", "HTP_QRY_SMT_YN;m;x");
		hm.put("MMDA_INT_RCV_ACNO", "HTP_QRY_MMDA_INT_RCV_ACNO;m;e");
		hm.put("LOGIN_TYPE", "HTP_QRY_LOGIN_TYPE;m;x");
		hm.put("TODAY", "HTP_QRY_TODAY;m;x");
		hm.put("LIST_SER_NO_3", "HTP_QRY_LIST_SER_NO_3;m;x");
		hm.put("CUR_LIST_SER_NO_3", "HTP_QRY_CUR_LIST_SER_NO_3;m;x");
		hm.put("radioClick", "HTP_QRY_RADIOCLICK;m;x");
		hm.put("tempTODAY", "HTP_QRY_TEMPTODAY;m;x");
		hm.put("isFirst", "HTP_QRY_ISFIRST;m;x");
		hm.put("CLDOC_SRNO_2", "HTP_QRY_CLDOC_SRNO_2;m;x");
		hm.put("logout", "HTP_QRY_LOGOUT;m;x");
		hm.put("ITG_RQ_STL_NO_4", "HTP_QRY_ITG_RQ_STL_NO_4;m;x");
		hm.put("SEQ_NO_3", "HTP_QRY_SEQ_NO_3;m;x");
		hm.put("INQSTADY_8", "HTP_QRY_INQSTADY_8;m;x");
		hm.put("INQENDDY_8", "HTP_QRY_INQENDDY_8;m;x");
		hm.put("URL", "HTP_QRY_URL;m;x");
		hm.put("wdata", "HTP_QRY_WDATA;m;x");
		hm.put("ndata", "HTP_QRY_NDATA;m;x");
		hm.put("smart_popup", "HTP_QRY_SMART_POPUP;m;x");
		hm.put("Tk_ACT_PWNO_check", "HTP_QRY_TK_ACT_PWNO_CHECK;m;x");
		hm.put("transkey_Tk_ACT_PWNO", "HTP_QRY_TRANSKEY_TK_ACT_PWNO;m;f");
		hm.put("transkey_hMac_Tk_ACT_PWNO", "HTP_QRY_TRANSKEY_HMAC_TK_ACT_PWNO;m;f");
		hm.put("USER_SRNO", "HTP_QRY_USER_SRNO;m;x");
		hm.put("FND_CAUTION_LMS", "HTP_QRY_FND_CAUTION_LMS;m;x");
		hm.put("sort_group", "HTP_QRY_SORT_GROUP;m;x");
		hm.put("IN_BANK_CD_3", "HTP_QRY_IN_BANK_CD_3;m;x");
		hm.put("IN_AMOUNT_13", "HTP_QRY_IN_AMOUNT_13;m;x");
		hm.put("LCL", "HTP_QRY_LCL;m;x");
		hm.put("scrGubun", "HTP_QRY_SCRGUBUN;m;x");
		hm.put("pop_yn", "HTP_QRY_POP_YN;m;x");
		hm.put("ACCT_15", "HTP_QRY_ACCT_15;m;e");
		hm.put("sw", "HTP_QRY_SW;m;x");
		hm.put("E2E_RCV_ACNO", "HTP_QRY_E2E_RCV_ACNO;m;e");
		hm.put("Tk_pup02_check", "HTP_QRY_TK_PUP02_CHECK;m;x");
		hm.put("SERIALNO", "HTP_QRY_SERIALNO;m;x");
		hm.put("RCV_BKNM", "HTP_QRY_RCV_BKNM;m;x");
		hm.put("ACT_PWNO__E2E__", "HTP_QRY_ACT_PWNO__E2E__;m;f");
		hm.put("RCVACTNO_15", "HTP_QRY_RCVACTNO_15;m;e");
		hm.put("MO_ACNO", "HTP_QRY_MO_ACNO;m;e");
		hm.put("FX_RCV_ACNO", "HTP_QRY_FX_RCV_ACNO;m;e");
		hm.put("TranFrom", "HTP_QRY_TRANFROM;m;x");
		hm.put("Tk_PWD_checkbox", "HTP_QRY_TK_PWD_CHECKBOX;m;x");
		hm.put("lst_trn_dt", "HTP_QRY_LST_TRN_DT;m;x");
		hm.put("addDays", "HTP_QRY_ADDDAYS;m;x");
		hm.put("CLMNYNO_16", "HTP_QRY_CLMNYNO_16;m;x");
		hm.put("BFTRBL_13", "HTP_QRY_BFTRBL_13;m;x");
		hm.put("INQ_SQL_DIS_1", "HTP_QRY_INQ_SQL_DIS_1;m;x");
		hm.put("APV_YN", "HTP_QRY_APV_YN;m;x");
		hm.put("dis", "HTP_QRY_DIS;m;x");
		hm.put("NEXT_ROWS", "HTP_QRY_NEXT_ROWS;m;x");
		hm.put("E2E_EXEC_DT", "HTP_QRY_E2E_EXEC_DT;m;x");
		hm.put("RCVBNKNM_2", "HTP_QRY_RCVBNKNM_2;m;x");
		hm.put("CCD_SELECT_CDNO_IDX", "HTP_QRY_CCD_SELECT_CDNO_IDX;m;e");
		hm.put("RCV_BKCD_1", "HTP_QRY_RCV_BKCD_1;m;x");
		hm.put("RCV_BKCD_2", "HTP_QRY_RCV_BKCD_2;m;x");
		hm.put("Tk_ELTPAYNO_19_check", "HTP_QRY_TK_ELTPAYNO_19_CHECK;m;x");
		hm.put("ELTPAYNO_19_LOCAL", "HTP_QRY_ELTPAYNO_19_LOCAL;m;e");
		hm.put("transkey_Tk_ELTPAYNO_19", "HTP_QRY_TRANSKEY_TK_ELTPAYNO_19;m;x");
		hm.put("transkey_hMac_Tk_ELTPAYNO_19", "HTP_QRY_TRANSKEY_HMAC_TK_ELTPAYNO_19;m;x");
		hm.put("FNDTS_DIS", "HTP_QRY_FNDTS_DIS;m;x");
		hm.put("returnURL", "HTP_QRY_RETURNURL;m;x");
		hm.put("CUR_DATE", "HTP_QRY_CUR_DATE;m;x");
		hm.put("INQ_SQNO_3", "HTP_QRY_INQ_SQNO_3;m;x");
		hm.put("POPUP_PRC_DSCD_1", "HTP_QRY_POPUP_PRC_DSCD_1;m;x");
		hm.put("SelMonChoice", "HTP_QRY_SELMONCHOICE;m;x");
		hm.put("INQSTADY_8Y", "HTP_QRY_INQSTADY_8Y;m;x");
		hm.put("INQENDDY_8Y", "HTP_QRY_INQENDDY_8Y;m;x");
		hm.put("INQSTADY_8M", "HTP_QRY_INQSTADY_8M;m;x");
		hm.put("INQSTADY_8D", "HTP_QRY_INQSTADY_8D;m;x");
		hm.put("INQENDDY_8M", "HTP_QRY_INQENDDY_8M;m;x");
		hm.put("INQENDDY_8D", "HTP_QRY_INQENDDY_8D;m;x");
		hm.put("FEE_AM", "HTP_QRY_FEE_AM;m;x");
		hm.put("CCD_USE_RGN", "HTP_QRY_CCD_USE_RGN;m;x");
		hm.put("CCD_BANK_DIS", "HTP_QRY_CCD_BANK_DIS;m;x");
		hm.put("CCD_PERIOD", "HTP_QRY_CCD_PERIOD;m;x");
		hm.put("CCD_ISINQUIRED", "HTP_QRY_CCD_ISINQUIRED;m;x");
		hm.put("tempDate", "HTP_QRY_TEMPDATE;m;x");
		hm.put("IS_DETAIL_PRINT", "HTP_QRY_IS_DETAIL_PRINT;m;x");
		hm.put("before12month", "HTP_QRY_BEFORE12MONTH;m;x");
		hm.put("CCD_REQ_SIZE_IDX", "HTP_QRY_CCD_REQ_SIZE_IDX;m;x");
		hm.put("CCD_INQ_DIS", "HTP_QRY_CCD_INQ_DIS;m;x");
		hm.put("CCD_STL_BK_CD", "HTP_QRY_CCD_STL_BK_CD;m;x");
		hm.put("CCD_STL_USE_ACT", "HTP_QRY_CCD_STL_USE_ACT;m;x");
		hm.put("CCD_REQ_SIZE_1", "HTP_QRY_CCD_REQ_SIZE_1;m;x");
		hm.put("submit_gubun", "HTP_QRY_SUBMIT_GUBUN;m;x");
		hm.put("TS_BEFORETRANBAL", "HTP_QRY_TS_BEFORETRANBAL;m;x");
		hm.put("TS_SUMTRANSFERAMT", "HTP_QRY_TS_SUMTRANSFERAMT;m;x");
		hm.put("TS_SUMTRANSFERFEE", "HTP_QRY_TS_SUMTRANSFERFEE;m;x");
		hm.put("DSCD", "HTP_QRY_DSCD;m;x");
		hm.put("ELTPAYNO_19__E2E__", "HTP_QRY_ELTPAYNO_19__E2E__;m;e");
		hm.put("GROUP_CD", "HTP_QRY_GROUP_CD;m;x");
		hm.put("nextBtnYn", "HTP_QRY_NEXTBTNYN;m;x");
		hm.put("NEXT_SER_NO_3", "HTP_QRY_NEXT_SER_NO_3;m;x");
		hm.put("PRE_SER_NO_3", "HTP_QRY_PRE_SER_NO_3;m;x");
		hm.put("ScrtyWay", "HTP_QRY_SCRTYWAY;m;x");
		hm.put("TLM_NO", "HTP_QRY_TLM_NO;m;x");
		hm.put("BOK_TRN_DSCD", "HTP_QRY_BOK_TRN_DSCD;m;x");
		hm.put("KORBNK_R", "HTP_QRY_KORBNK_R;m;x");
		hm.put("Tk_pup02_checkbox", "HTP_QRY_TK_PUP02_CHECKBOX;m;x");
		hm.put("REQ_SEQ", "HTP_QRY_REQ_SEQ;m;x");
		hm.put("DELETE_NO", "HTP_QRY_DELETE_NO;m;x");
		hm.put("DELETE_SEQ", "HTP_QRY_DELETE_SEQ;m;x");
		hm.put("MEMBERS_POINT_AMT", "HTP_QRY_MEMBERS_POINT_AMT;m;x");
		hm.put("MEMBERS_COUNT", "HTP_QRY_MEMBERS_COUNT;m;x");
		hm.put("MEMBERS_SPC_CNT", "HTP_QRY_MEMBERS_SPC_CNT;m;x");
		hm.put("WOORI_BONUS_SPC_CNT", "HTP_QRY_WOORI_BONUS_SPC_CNT;m;x");
		hm.put("MEMBERS_CON_SPC_CNT", "HTP_QRY_MEMBERS_CON_SPC_CNT;m;x");
		hm.put("WOORI_BONUS_GRADE", "HTP_QRY_WOORI_BONUS_GRADE;m;x");
		hm.put("MEMBERS_FEE", "HTP_QRY_MEMBERS_FEE;m;x");
		hm.put("prdNm", "HTP_QRY_PRDNM;m;x");
		hm.put("USER_TYPE", "HTP_QRY_USER_TYPE;m;x");
		hm.put("CD_NO_16", "HTP_QRY_CD_NO_16;m;x");
		hm.put("btn_acct_hidden", "HTP_QRY_BTN_ACCT_HIDDEN;m;x");
		hm.put("prdCd", "HTP_QRY_PRDCD;m;x");
		hm.put("e_mail", "HTP_QRY_E_MAIL;m;f");
		hm.put("cdFm", "HTP_QRY_CDFM;m;e");
		hm.put("BKCD", "HTP_QRY_BKCD;m;x");
		hm.put("CRT_NO", "HTP_QRY_CRT_NO;m;x");
		hm.put("LN_ACNO_15", "HTP_QRY_LN_ACNO_15;m;e");
		hm.put("PLM_PDCD", "HTP_QRY_PLM_PDCD;m;x");
		hm.put("PRD_CD_9", "HTP_QRY_PRD_CD_9;m;x");
		hm.put("APVRQ_SEQ", "HTP_QRY_APVRQ_SEQ;m;x");
		hm.put("HpNoAuth", "HTP_QRY_HPNOAUTH;m;x");
		hm.put("ClipID", "HTP_QRY_CLIPID;m;x");
		hm.put("WIBEE_MONEY_YN", "HTP_QRY_WIBEE_MONEY_YN;m;x");
		hm.put("TRAN_INFO", "HTP_QRY_TRAN_INFO;m;x");
		hm.put("transkey_hMac_Tk_ACTPWNO_8", "HTP_QRY_TRANSKEY_HMAC_TK_ACTPWNO_8;m;f");
		hm.put("transkey_Tk_ACTPWNO_8", "HTP_QRY_TRANSKEY_TK_ACTPWNO_8;m;f");
		hm.put("Tk_ACTPWNO_8_check", "HTP_QRY_TK_ACTPWNO_8_CHECK;m;f");
		hm.put("ACT_PWNO_USG_YN", "HTP_QRY_ACT_PWNO_USG_YN;m;x");
		hm.put("INT_AM_11", "HTP_QRY_INT_AM_11;m;x");
		hm.put("AUTH_REASON", "HTP_QRY_AUTH_REASON;m;x");
		hm.put("y", "HTP_QRY_Y;m;x");
		hm.put("x", "HTP_QRY_X;m;x");
		hm.put("authUsedPhoneNo", "HTP_QRY_AUTHUSEDPHONENO;m;f");
		hm.put("transkey_Tk_pup03", "HTP_QRY_TRANSKEY_TK_PUP03;m;x");
		hm.put("transkey_hMac_Tk_pup03", "HTP_QRY_TRANSKEY_HMAC_TK_PUP03;m;x");
		hm.put("DPPENm_20", "HTP_QRY_DPPENM_20;m;k");
		hm.put("TAX_CD_TXT", "HTP_QRY_TAX_CD_TXT;m;x");
		hm.put("COST_CD_TXT", "HTP_QRY_COST_CD_TXT;m;x");
		hm.put("TS_CountTransFerRes", "HTP_QRY_TS_COUNTTRANSFERRES;m;x");
		hm.put("ediString", "HTP_QRY_EDISTRING;m;x");
		hm.put("ediicheday", "HTP_QRY_EDIICHEDAY;m;x");
		hm.put("edinum", "HTP_QRY_EDINUM;m;x");
		hm.put("ediresult", "HTP_QRY_EDIRESULT;m;x");
		hm.put("edicode", "HTP_QRY_EDICODE;m;x");
		hm.put("editrcode", "HTP_QRY_EDITRCODE;m;x");
		hm.put("edigumak", "HTP_QRY_EDIGUMAK;m;x");
		hm.put("GUNBUN", "HTP_QRY_GUNBUN;m;x");
		hm.put("BS_SIGNED_DATA", "HTP_QRY_BS_SIGNED_DATA;m;x");
		hm.put("BS_RANDOM_NUM", "HTP_QRY_BS_RANDOM_NUM;m;x");
		hm.put("ACTPWNO_8__E2E__", "HTP_QRY_ACTPWNO_8__E2E__;m;f");
		hm.put("WDR_PBOKMNTNHIS_20", "HTP_QRY_WDR_PBOKMNTNHIS_20;m;x");
		hm.put("E2E_RCVACTNO_15", "HTP_QRY_E2E_RCVACTNO_15;m;e");
		hm.put("clientSeq", "HTP_QRY_CLIENTSEQ;m;x");
		hm.put("APVRQ_DT", "HTP_QRY_APVRQ_DT;m;x");
		hm.put("strGoUrl", "HTP_QRY_STRGOURL;m;x");
		hm.put("DUP_CERT_YN", "HTP_QRY_DUP_CERT_YN;m;x");
		hm.put("ACT_BAL", "HTP_QRY_ACT_BAL;m;x");
		hm.put("q", "HTP_QRY_Q;m;x");
		hm.put("clientid", "HTP_QRY_CLIENTID;m;x");
		hm.put("balanceShortYN", "HTP_QRY_BALANCESHORTYN;m;x");
		hm.put("uid", "HTP_QRY_UID;m;x");
		hm.put("RNNM_NO", "HTP_QRY_RNNM_NO;m;x");
		hm.put("P_WDRACTNO_15", "HTP_QRY_P_WDRACTNO_15;m;e");
		hm.put("DELAY_TS_GUBUN", "HTP_QRY_DELAY_TS_GUBUN;m;x");
		hm.put("SCRT_MNS", "HTP_QRY_SCRT_MNS;m;x");
		hm.put("popIndex", "HTP_QRY_POPINDEX;m;x");
		hm.put("PRD_NM", "HTP_QRY_PRD_NM;m;x");
		hm.put("otc", "HTP_QRY_OTC;m;x");
		hm.put("__PAGE_TITLE__", "HTP_QRY___PAGE_TITLE__;m;x");
		hm.put("APP_YN", "HTP_QRY_APP_YN;m;x");
		hm.put("TS_SUMSUPPRTAMT", "HTP_QRY_TS_SUMSUPPRTAMT;m;x");
		hm.put("OTP_KIND", "HTP_QRY_OTP_KIND;m;x");
		hm.put("INQ_DIS", "HTP_QRY_INQ_DIS;m;x");
		hm.put("accInfoLst", "HTP_QRY_ACCINFOLST;d;e");
		hm.put("objectCLSID", "HTP_QRY_OBJECTCLSID;m;x");
		hm.put("resultMessage", "HTP_QRY_RESULTMESSAGE;m;x");
		hm.put("resultCode", "HTP_QRY_RESULTCODE;m;x");
		hm.put("objectName", "HTP_QRY_OBJECTNAME;m;x");
		hm.put("ctr_msg", "HTP_QRY_CTR_MSG;m;x");
		hm.put("msg", "HTP_QRY_MSG;m;x");
		hm.put("result", "HTP_QRY_RESULT;m;x");
		hm.put("iframeHtmlDataYN", "HTP_QRY_IFRAMEHTMLDATAYN;m;x");
		hm.put("iframeHtmlDataNum", "HTP_QRY_IFRAMEHTMLDATANUM;m;x");
		hm.put("SSN", "HTP_QRY_SSN;m;x");
		hm.put("isEng", "HTP_QRY_ISENG;m;x");
		hm.put("M_ID", "HTP_QRY_M_ID;m;x");
		hm.put("L_ID", "HTP_QRY_L_ID;m;x");
		hm.put("OBK_DIS", "HTP_QRY_OBK_DIS;m;x");
		hm.put("AUTH_MNS", "HTP_QRY_AUTH_MNS;m;x");
		hm.put("SMS_AUTH_USE_YN", "HTP_QRY_SMS_AUTH_USE_YN;m;x");
		hm.put("OTPCARDPSTNO_6", "HTP_QRY_OTPCARDPSTNO_6;m;x");
		hm.put("MBRCO_CD_2", "HTP_QRY_MBRCO_CD_2;m;x");
		hm.put("UMS_TMPL_CD", "HTP_QRY_UMS_TMPL_CD;m;x");
		hm.put("fua_name", "HTP_QRY_FUA_NAME;m;x");
		hm.put("WDR_PBOK_PRNG_TXT", "HTP_QRY_WDR_PBOK_PRNG_TXT;m;x");
		hm.put("TRANSFER_WORK_CD_2", "HTP_QRY_TRANSFER_WORK_CD_2;m;x");
		hm.put("TARGET_SERVICE_20", "HTP_QRY_TARGET_SERVICE_20;m;x");
		hm.put("FEE_AM_11", "HTP_QRY_FEE_AM_11;m;x");
		hm.put("TM_HNDPE_DT_OTP_YN", "HTP_QRY_TM_HNDPE_DT_OTP_YN;m;x");
		hm.put("lang", "HTP_QRY_LANG;m;x");
		hm.put("divType", "HTP_QRY_DIVTYPE;m;x");
		hm.put("rc", "HTP_QRY_RC;m;x");
		hm.put("CLEAR_SESSION_YN", "HTP_QRY_CLEAR_SESSION_YN;m;x");
		hm.put("ADD_AUTH_USE_YN", "HTP_QRY_ADD_AUTH_USE_YN;m;x");
		hm.put("strReUrl", "HTP_QRY_STRREURL;m;x");
		hm.put("OPNDY2_8", "HTP_QRY_OPNDY2_8;m;x");
		hm.put("worktype", "HTP_QRY_WORKTYPE;m;x");
		hm.put("qrystep", "HTP_QRY_QRYSTEP;m;x");
		hm.put("workstep", "HTP_QRY_WORKSTEP;m;x");
		hm.put("targetform", "HTP_QRY_TARGETFORM;m;x");
		hm.put("oneDayDropYn", "HTP_QRY_ONEDAYDROPYN;m;x");
		hm.put("gocontinue", "HTP_QRY_GOCONTINUE;m;x");
		hm.put("workdata", "HTP_QRY_WORKDATA;m;e");
		hm.put("workpageid", "HTP_QRY_WORKPAGEID;m;x");
		hm.put("_BIZCOM_YUIBTIME", "HTP_QRY__BIZCOM_YUIBTIME;m;x");
		hm.put("_BIZCOM_YUIBDATE", "HTP_QRY__BIZCOM_YUIBDATE;m;x");
		hm.put("R_BFTRBL_13", "HTP_QRY_R_BFTRBL_13;m;x");
		hm.put("TRN_BK_GIRO_CD_6", "HTP_QRY_TRN_BK_GIRO_CD_6;m;x");
		hm.put("VIEWTABLENM_22", "HTP_QRY_VIEWTABLENM_22;m;x");
		hm.put("dhs", "HTP_QRY_DHS;m;x");
		hm.put("payload", "HTP_QRY_PAYLOAD;m;x");
		hm.put("prk", "HTP_QRY_PRK;m;x");
		hm.put("dsk", "HTP_QRY_DSK;m;x");
		hm.put("PRD_CD", "HTP_QRY_PRD_CD;m;x");
		hm.put("fn_cb_addAuth", "HTP_QRY_FN_CB_ADDAUTH;m;x");
		hm.put("favAcNm", "HTP_QRY_FAVACNM;m;e");
		hm.put("TRNAM_13_KorAmt", "HTP_QRY_TRNAM_13_KORAMT;m;x");
		hm.put("favBkCd", "HTP_QRY_FAVBKCD;m;x");
		hm.put("Retired_Pay_YN", "HTP_QRY_RETIRED_PAY_YN;m;x");
		hm.put("favBkNm", "HTP_QRY_FAVBKNM;m;x");
		hm.put("favEmail", "HTP_QRY_FAVEMAIL;m;f");
		hm.put("favGrpCd", "HTP_QRY_FAVGRPCD;m;x");
		hm.put("favGrpNm", "HTP_QRY_FAVGRPNM;m;k");
		hm.put("favHpno", "HTP_QRY_FAVHPNO;m;f");
		hm.put("favRcvacNo", "HTP_QRY_FAVRCVACNO;m;e");
		hm.put("favUsNm", "HTP_QRY_FAVUSNM;m;k");
		hm.put("BACKKEY_CALL", "HTP_QRY_BACKKEY_CALL;m;x");
		hm.put("sendActArr", "HTP_QRY_SENDACTARR;m;f");
		hm.put("sendNmArr", "HTP_QRY_SENDNMARR;m;e");
		hm.put("prefee_YN", "HTP_QRY_PREFEE_YN;m;x");
		hm.put("HSM_SKIP", "HTP_QRY_HSM_SKIP;m;x");
		hm.put("POLICY_CHK_SKIP", "HTP_QRY_POLICY_CHK_SKIP;m;e");
		hm.put("KORBNK", "HTP_QRY_KORBNK;m;x");
		hm.put("RCVBNKCD_2_TAX", "HTP_QRY_RCVBNKCD_2_TAX;m;x");
		hm.put("login_page", "HTP_QRY_LOGIN_PAGE;m;x");
		hm.put("__TOP_PAGE_ID", "HTP_QRY___TOP_PAGE_ID;m;x");
		hm.put("prefee", "HTP_QRY_PREFEE;m;x");
		hm.put("APV_NO_LIST", "HTP_QRY_APV_NO_LIST;m;x");
		hm.put("OtpKind", "HTP_QRY_OTPKIND;m;x");
		hm.put("INQ_DIS_1", "HTP_QRY_INQ_DIS_1;m;x");
		hm.put("pushtype", "HTP_QRY_PUSHTYPE;m;x");
		hm.put("TRSEQ", "HTP_QRY_TRSEQ;m;x");
		hm.put("ERROR_CODE", "HTP_QRY_ERROR_CODE;m;x");
		hm.put("TEL_NUM", "HTP_QRY_TEL_NUM;m;f");
		hm.put("ERROR_TR", "HTP_QRY_ERROR_TR;m;x");
		hm.put("LST_XPR_DT", "HTP_QRY_LST_XPR_DT;m;x");
		hm.put("TS_PWNO_NOTRGS_YN_1", "HTP_QRY_TS_PWNO_NOTRGS_YN_1;m;x");
		hm.put("TCH_REQ_CHECK", "HTP_QRY_TCH_REQ_CHECK;m;x");
		hm.put("fromSite", "HTP_QRY_FROMSITE;m;x");
		hm.put("APP_HP_NO", "HTP_QRY_APP_HP_NO;m;f");
		hm.put("RNDNO_NO_6", "HTP_QRY_RNDNO_NO_6;m;x");
		hm.put("INQ_PRN_NO_16", "HTP_QRY_INQ_PRN_NO_16;m;x");
		hm.put("OTPCARDPWNO_6", "HTP_QRY_OTPCARDPWNO_6;m;f");
		hm.put("Tk_OTPCARDPWNO_6_check", "HTP_QRY_TK_OTPCARDPWNO_6_CHECK;m;f");
		hm.put("transkey_Tk_OTPCARDPWNO_6", "HTP_QRY_TRANSKEY_TK_OTPCARDPWNO_6;m;f");
		hm.put("transkey_hMac_Tk_OTPCARDPWNO_6", "HTP_QRY_TRANSKEY_HMAC_TK_OTPCARDPWNO_6;m;f");
		hm.put("_BIZCOM_YUIBLINE", "HTP_QRY__BIZCOM_YUIBLINE;m;x");
		hm.put("P_CURRTYPE", "HTP_QRY_P_CURRTYPE;m;x");
		hm.put("fileName", "HTP_QRY_FILENAME;m;x");
		hm.put("AIM_SRVC", "HTP_QRY_AIM_SRVC;m;x");
		hm.put("PIN_PWNO_6_REALVAL", "HTP_QRY_PIN_PWNO_6_REALVAL;m;f");
		hm.put("APVRQ_ID", "HTP_QRY_APVRQ_ID;m;x");
		hm.put("PWNO_6_REALVAL", "HTP_QRY_PWNO_6_REALVAL;m;f");
		hm.put("PWNO_8_REALVAL", "HTP_QRY_PWNO_8_REALVAL;m;f");
		hm.put("PWNO_6_1_REALVAL", "HTP_QRY_PWNO_6_1_REALVAL;m;f");
		hm.put("PWNO_6_2_REALVAL", "HTP_QRY_PWNO_6_2_REALVAL;m;f");
		hm.put("page", "HTP_QRY_PAGE;m;x");
		hm.put("OTPCARDPWNO_6__E2E__", "HTP_QRY_OTPCARDPWNO_6__E2E__;m;f");
		hm.put("CARD_NO_16", "HTP_QRY_CARD_NO_16;m;e");
		hm.put("token", "HTP_QRY_TOKEN;m;x");
		hm.put("RCVACTNO_15_MASK", "HTP_QRY_RCVACTNO_15_MASK;m;e");
		hm.put("IN_AMOUNT_13_COMMA", "HTP_QRY_IN_AMOUNT_13_COMMA;m;x");
		hm.put("TRNAM_13_COMMA", "HTP_QRY_TRNAM_13_COMMA;m;x");
		hm.put("IN_BANK_CD_3_STR", "HTP_QRY_IN_BANK_CD_3_STR;m;x");
		hm.put("ATS_MNG_NO", "HTP_QRY_ATS_MNG_NO;m;x");
		hm.put("COMMONCERT_TYPE", "HTP_QRY_COMMONCERT_TYPE;m;x");
		hm.put("INQ_EDT_10", "HTP_QRY_INQ_EDT_10;m;x");
		hm.put("INQ_SDT_10", "HTP_QRY_INQ_SDT_10;m;x");
		hm.put("itcsno", "HTP_QRY_ITCSNO;m;x");
		hm.put("CLMNYNO1_16", "HTP_QRY_CLMNYNO1_16;m;x");
		hm.put("certselect_tek_input1__E2E__", "HTP_QRY_CERTSELECT_TEK_INPUT1__E2E__;m;x");
		hm.put("PSNBZ_YN", "HTP_QRY_PSNBZ_YN;m;x");
		hm.put("SECU_CARD_RAN_NO_2", "HTP_QRY_SECU_CARD_RAN_NO_2;m;e");
		hm.put("RSV_YN", "HTP_QRY_RSV_YN;m;x");
		hm.put("NEW_RCKN_DT", "HTP_QRY_NEW_RCKN_DT;m;x");
		hm.put("P_name", "HTP_QRY_P_NAME;m;x");
		hm.put("CHK_CRT_NO", "HTP_QRY_CHK_CRT_NO;m;x");
		hm.put("PWNO_6", "HTP_QRY_PWNO_6;m;f");
		hm.put("ACT_NCM", "HTP_QRY_ACT_NCM;m;k");
		hm.put("AUTH_SVC_APP_CERT_HASH", "HTP_QRY_AUTH_SVC_APP_CERT_HASH;m;x");
		hm.put("AUTH_SVC_AUTH_TYPE", "HTP_QRY_AUTH_SVC_AUTH_TYPE;m;x");
		hm.put("AUTH_SVC_EVENT_ID", "HTP_QRY_AUTH_SVC_EVENT_ID;m;x");
		hm.put("BIOAUT_DIS_CD", "HTP_QRY_BIOAUT_DIS_CD;m;x");
		hm.put("AUTH_SVC_USER_ID", "HTP_QRY_AUTH_SVC_USER_ID;m;x");
		hm.put("AUTH_SVC_AUTH_TOKEN", "HTP_QRY_AUTH_SVC_AUTH_TOKEN;m;x");
		hm.put("AUTH_SVC_APP_ID", "HTP_QRY_AUTH_SVC_APP_ID;m;x");
		hm.put("IS_FIDO_USE", "HTP_QRY_IS_FIDO_USE;m;x");
		hm.put("BIOAUT_USE_CD", "HTP_QRY_BIOAUT_USE_CD;m;x");
		hm.put("transkey_hMac_Tk_PWNO_6", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6;m;f");
		hm.put("Tk_PWNO_6_check", "HTP_QRY_TK_PWNO_6_CHECK;m;f");
		hm.put("transkey_Tk_PWNO_6", "HTP_QRY_TRANSKEY_TK_PWNO_6;m;f");
		hm.put("CD_PRD_CD", "HTP_QRY_CD_PRD_CD;m;x");
		hm.put("USNM", "HTP_QRY_USNM;m;k");
		hm.put("INQ_PRN_NO_16_3", "HTP_QRY_INQ_PRN_NO_16_3;m;x");
		hm.put("INQ_PRN_NO_16_2", "HTP_QRY_INQ_PRN_NO_16_2;m;x");
		hm.put("INQ_PRN_NO_16_4", "HTP_QRY_INQ_PRN_NO_16_4;m;x");
		hm.put("INQ_PRN_NO_16_1", "HTP_QRY_INQ_PRN_NO_16_1;m;x");
		hm.put("JUMIN_NUMBER1", "HTP_QRY_JUMIN_NUMBER1;m;x");
		hm.put("s_signed", "HTP_QRY_S_SIGNED;m;k");
		hm.put("format", "HTP_QRY_FORMAT;m;x");
		hm.put("TRN_SRNO_12", "HTP_QRY_TRN_SRNO_12;m;x");
		hm.put("IMG_PWNO_6_2", "HTP_QRY_IMG_PWNO_6_2;m;f");
		hm.put("IMG_PWNO_6_1", "HTP_QRY_IMG_PWNO_6_1;m;f");
		hm.put("PWNO_6_1", "HTP_QRY_PWNO_6_1;m;f");
		hm.put("PWNO_6_2", "HTP_QRY_PWNO_6_2;m;f");
		hm.put("Tk_PWNO_6_1_check", "HTP_QRY_TK_PWNO_6_1_CHECK;m;f");
		hm.put("transkey_hMac_Tk_PWNO_6_2", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6_2;m;f");
		hm.put("transkey_hMac_Tk_PWNO_6_1", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_6_1;m;f");
		hm.put("transkey_Tk_PWNO_6_2", "HTP_QRY_TRANSKEY_TK_PWNO_6_2;m;f");
		hm.put("transkey_Tk_PWNO_6_1", "HTP_QRY_TRANSKEY_TK_PWNO_6_1;m;f");
		hm.put("Tk_PWNO_6_2_check", "HTP_QRY_TK_PWNO_6_2_CHECK;m;x");
		hm.put("inspect", "HTP_QRY_INSPECT;m;x");
		hm.put("s_signedkey", "HTP_QRY_S_SIGNEDKEY;m;x");
		hm.put("FND_DEP_STEP", "HTP_QRY_FND_DEP_STEP;m;x");
		hm.put("TELCODE", "HTP_QRY_TELCODE;m;x");
		hm.put("PWNO_6__E2E__", "HTP_QRY_PWNO_6__E2E__;m;f");
		hm.put("GB", "HTP_QRY_GB;m;x");
		hm.put("MODE", "HTP_QRY_MODE;m;x");
		hm.put("sec_E2EPid", "HTP_QRY_SEC_E2EPID;m;x");
		hm.put("PSBZ_NO", "HTP_QRY_PSBZ_NO;m;e");
		hm.put("PWNO_6_2__E2E__", "HTP_QRY_PWNO_6_2__E2E__;m;f");
		hm.put("PWNO_6_1__E2E__", "HTP_QRY_PWNO_6_1__E2E__;m;f");
		hm.put("WIBEE_HMNY_DDU_RDU_AM", "HTP_QRY_WIBEE_HMNY_DDU_RDU_AM;m;x");
		hm.put("Tk_pup03_check", "HTP_QRY_TK_PUP03_CHECK;m;x");
		hm.put("rdo_AddAuthMns", "HTP_QRY_RDO_ADDAUTHMNS;m;x");
		hm.put("CONT_NO_DIS", "HTP_QRY_CONT_NO_DIS;m;x");
		hm.put("input_num24", "HTP_QRY_INPUT_NUM24;m;x");
		hm.put("input_num5", "HTP_QRY_INPUT_NUM5;m;x");
		hm.put("input_num7", "HTP_QRY_INPUT_NUM7;m;x");
		hm.put("input_num16", "HTP_QRY_INPUT_NUM16;m;x");
		hm.put("input_num26", "HTP_QRY_INPUT_NUM26;m;x");
		hm.put("input_num15", "HTP_QRY_INPUT_NUM15;m;x");
		hm.put("input_num10", "HTP_QRY_INPUT_NUM10;m;x");
		hm.put("input_num1", "HTP_QRY_INPUT_NUM1;m;x");
		hm.put("input_num21", "HTP_QRY_INPUT_NUM21;m;x");
		hm.put("input_num35", "HTP_QRY_INPUT_NUM35;m;x");
		hm.put("input_num17", "HTP_QRY_INPUT_NUM17;m;x");
		hm.put("input_num14", "HTP_QRY_INPUT_NUM14;m;x");
		hm.put("input_num32", "HTP_QRY_INPUT_NUM32;m;x");
		hm.put("input_num33", "HTP_QRY_INPUT_NUM33;m;x");
		hm.put("input_num12", "HTP_QRY_INPUT_NUM12;m;x");
		hm.put("input_num22", "HTP_QRY_INPUT_NUM22;m;x");
		hm.put("input_num20", "HTP_QRY_INPUT_NUM20;m;x");
		hm.put("input_num19", "HTP_QRY_INPUT_NUM19;m;x");
		hm.put("input_num23", "HTP_QRY_INPUT_NUM23;m;x");
		hm.put("input_num34", "HTP_QRY_INPUT_NUM34;m;x");
		hm.put("input_num30", "HTP_QRY_INPUT_NUM30;m;x");
		hm.put("input_num8", "HTP_QRY_INPUT_NUM8;m;x");
		hm.put("input_num18", "HTP_QRY_INPUT_NUM18;m;x");
		hm.put("input_num13", "HTP_QRY_INPUT_NUM13;m;x");
		hm.put("input_num28", "HTP_QRY_INPUT_NUM28;m;x");
		hm.put("input_num2", "HTP_QRY_INPUT_NUM2;m;x");
		hm.put("input_num3", "HTP_QRY_INPUT_NUM3;m;x");
		hm.put("input_num4", "HTP_QRY_INPUT_NUM4;m;x");
		hm.put("input_num27", "HTP_QRY_INPUT_NUM27;m;x");
		hm.put("input_num29", "HTP_QRY_INPUT_NUM29;m;x");
		hm.put("input_num25", "HTP_QRY_INPUT_NUM25;m;x");
		hm.put("input_num31", "HTP_QRY_INPUT_NUM31;m;x");
		hm.put("input_num6", "HTP_QRY_INPUT_NUM6;m;x");
		hm.put("BLDPY_BAS", "HTP_QRY_BLDPY_BAS;m;x");
		hm.put("input_num9", "HTP_QRY_INPUT_NUM9;m;x");
		hm.put("input_num11", "HTP_QRY_INPUT_NUM11;m;x");
		hm.put("MTS_NM", "HTP_QRY_MTS_NM;m;x");
		hm.put("S_PAGE", "HTP_QRY_S_PAGE;m;x");
		hm.put("RCVBNKNM", "HTP_QRY_RCVBNKNM;m;x");
		hm.put("acctBalance", "HTP_QRY_ACCTBALANCE;m;x");
		hm.put("monthLimit", "HTP_QRY_MONTHLIMIT;m;x");
		hm.put("possibleAmt", "HTP_QRY_POSSIBLEAMT;m;x");
		hm.put("MMDA_INT_RCPE_NM_22", "HTP_QRY_MMDA_INT_RCPE_NM_22;m;x");
		hm.put("actErrMsg", "HTP_QRY_ACTERRMSG;m;x");
		hm.put("MST_YN", "HTP_QRY_MST_YN;m;x");
		hm.put("INQ_DIS1_1", "HTP_QRY_INQ_DIS1_1;m;x");
		hm.put("INQ_KEY_20", "HTP_QRY_INQ_KEY_20;m;e");
		hm.put("EXEC", "HTP_QRY_EXEC;m;x");
		hm.put("RDU_FEE_AM_11", "HTP_QRY_RDU_FEE_AM_11;m;x");
		hm.put("WMB_RDU_AM_11", "HTP_QRY_WMB_RDU_AM_11;m;x");
		hm.put("ERROR_MSG_TXT", "HTP_QRY_ERROR_MSG_TXT;m;x");
		hm.put("RSP_TXT", "HTP_QRY_RSP_TXT;m;x");
		hm.put("TS_AM", "HTP_QRY_TS_AM;m;x");
		hm.put("ACTPRDNM", "HTP_QRY_ACTPRDNM;m;x");
		hm.put("ADVPE_EMP_NO_8", "HTP_QRY_ADVPE_EMP_NO_8;m;x");
		hm.put("SORT_DIS", "HTP_QRY_SORT_DIS;m;x");
		hm.put("WDR_BKNM", "HTP_QRY_WDR_BKNM;m;x");
		hm.put("INQ_GROUP", "HTP_QRY_INQ_GROUP;m;x");
		hm.put("BFAF_TR_BL_13", "HTP_QRY_BFAF_TR_BL_13;m;x");
		hm.put("hid_key_data", "HTP_QRY_HID_KEY_DATA;m;x");
		hm.put("ACC_NM", "HTP_QRY_ACC_NM;m;x");
		hm.put("CMS_NO", "HTP_QRY_CMS_NO;m;x");
		hm.put("HP_AUTH_UNQ_NO", "HTP_QRY_HP_AUTH_UNQ_NO;m;f");
		hm.put("SEARCH_DIS", "HTP_QRY_SEARCH_DIS;m;x");
		hm.put("query", "HTP_QRY_QUERY;m;x");
		hm.put("sel_SEARCH_DIS", "HTP_QRY_SEL_SEARCH_DIS;m;x");
		hm.put("sel_INQ_DIS", "HTP_QRY_SEL_INQ_DIS;m;x");
		hm.put("ATS_FND_INSV_SRVC_TYCD", "HTP_QRY_ATS_FND_INSV_SRVC_TYCD;m;x");
		hm.put("SqlType", "HTP_QRY_SQLTYPE;m;x");
		hm.put("FAULT", "HTP_QRY_FAULT;m;x");
		hm.put("RSVEXEDY_TIME", "HTP_QRY_RSVEXEDY_TIME;m;x");
		hm.put("STS", "HTP_QRY_STS;m;x");
		hm.put("TAB_FLAG", "HTP_QRY_TAB_FLAG;m;x");
		hm.put("TCH_AUTH_USE_YN", "HTP_QRY_TCH_AUTH_USE_YN;m;x");
		hm.put("TYPE", "HTP_QRY_TYPE;m;x");
		hm.put("WORK_CD_2", "HTP_QRY_WORK_CD_2;m;x");
		hm.put("FEE_BEAF_YN_1", "HTP_QRY_FEE_BEAF_YN_1;m;x");
		hm.put("doTran", "HTP_QRY_DOTRAN;m;x");
		hm.put("USER_NAME", "HTP_QRY_USER_NAME;m;k");
		hm.put("APPR_DIS", "HTP_QRY_APPR_DIS;m;x");
		hm.put("CAN_ONE_STOP_SVC_YN", "HTP_QRY_CAN_ONE_STOP_SVC_YN;m;x");
		hm.put("JUMIN_NUMBER2", "HTP_QRY_JUMIN_NUMBER2;m;x");
		hm.put("APVRQ_DT2", "HTP_QRY_APVRQ_DT2;m;x");
		hm.put("APVRQ_DT1", "HTP_QRY_APVRQ_DT1;m;x");
		hm.put("APV_APL_DIS2", "HTP_QRY_APV_APL_DIS2;m;x");
		hm.put("ADVPE_EMP_INFO", "HTP_QRY_ADVPE_EMP_INFO;m;x");
		hm.put("QR_ADVPE_NO", "HTP_QRY_QR_ADVPE_NO;m;x");
		hm.put("setHead", "HTP_QRY_SETHEAD;m;x");
		hm.put("WDR_ACNO_15", "HTP_QRY_WDR_ACNO_15;m;e");
		hm.put("CUS_NM", "HTP_QRY_CUS_NM;m;k");
		hm.put("PBOKMNTNHIS_TOT", "HTP_QRY_PBOKMNTNHIS_TOT;m;x");
		hm.put("TOT_CNT", "HTP_QRY_TOT_CNT;m;x");
		hm.put("PRD_KORL_NM", "HTP_QRY_PRD_KORL_NM;m;x");
		hm.put("WDR_ACNO_TEXT_TOT", "HTP_QRY_WDR_ACNO_TEXT_TOT;m;x");
		hm.put("ACT_PWNO_REALVAL", "HTP_QRY_ACT_PWNO_REALVAL;m;f");
		hm.put("ADVPE_EMP_SEARCH", "HTP_QRY_ADVPE_EMP_SEARCH;m;x");
		hm.put("FROM_DATE", "HTP_QRY_FROM_DATE;m;x");
		hm.put("preCnt", "HTP_QRY_PRECNT;m;x");
		hm.put("TO_DATE", "HTP_QRY_TO_DATE;m;x");
		hm.put("NXT_TRN_YN", "HTP_QRY_NXT_TRN_YN;m;x");
		hm.put("CTIN_INQ_SRNO", "HTP_QRY_CTIN_INQ_SRNO;m;x");
		hm.put("pageID", "HTP_QRY_PAGEID;m;x");
		hm.put("RMC_REQ_CHECK", "HTP_QRY_RMC_REQ_CHECK;m;x");
		hm.put("POLICY_TYPE", "HTP_QRY_POLICY_TYPE;m;x");
		hm.put("SERIAL", "HTP_QRY_SERIAL;m;x");
		hm.put("EMAIL", "HTP_QRY_EMAIL;m;f");
		hm.put("acctKind", "HTP_QRY_ACCTKIND;m;x");
		hm.put("TERM_ACTIVE_IDX", "HTP_QRY_TERM_ACTIVE_IDX;m;x");
		hm.put("TERM_FILE_TYPE", "HTP_QRY_TERM_FILE_TYPE;m;x");
		hm.put("selDate", "HTP_QRY_SELDATE;m;x");
		hm.put("TERM_PAGE", "HTP_QRY_TERM_PAGE;m;x");
		hm.put("TERM_VIEWTYPE", "HTP_QRY_TERM_VIEWTYPE;m;x");
		hm.put("TERM_TITLE", "HTP_QRY_TERM_TITLE;m;x");
		hm.put("tranFlag", "HTP_QRY_TRANFLAG;m;x");
		hm.put("TSDY_2", "HTP_QRY_TSDY_2;m;x");
		hm.put("TSFRQ_1", "HTP_QRY_TSFRQ_1;m;x");
		hm.put("val", "HTP_QRY_VAL;m;x");
		hm.put("id", "HTP_QRY_ID;m;x");
		hm.put("DPT_AUTH_USE_YN", "HTP_QRY_DPT_AUTH_USE_YN;m;x");
		hm.put("maxDate", "HTP_QRY_MAXDATE;m;x");
		hm.put("minDate", "HTP_QRY_MINDATE;m;x");
		hm.put("OPN_REST_LMT", "HTP_QRY_OPN_REST_LMT;m;x");
		hm.put("title", "HTP_QRY_TITLE;m;x");
		hm.put("ksP1", "HTP_QRY_KSP1;m;x");
		hm.put("ITPY_MECD", "HTP_QRY_ITPY_MECD;m;x");
		hm.put("ACT_HAIJI", "HTP_QRY_ACT_HAIJI;m;x");
		hm.put("accNum", "HTP_QRY_ACCNUM;m;e");
		hm.put("RQSPE_NM", "HTP_QRY_RQSPE_NM;m;x");
		hm.put("CD_IFOFR_AGR_YN", "HTP_QRY_CD_IFOFR_AGR_YN;m;x");
		hm.put("paramActKd", "HTP_QRY_PARAMACTKD;m;x");
		hm.put("FND_PDCD", "HTP_QRY_FND_PDCD;m;x");
		hm.put("OTPWD_AUTH_USE_YN", "HTP_QRY_OTPWD_AUTH_USE_YN;m;x");
		hm.put("CTGR_CD", "HTP_QRY_CTGR_CD;m;x");
		hm.put("CANC_ACNO", "HTP_QRY_CANC_ACNO;m;e");
		hm.put("RNPE_NM", "HTP_QRY_RNPE_NM;m;x");
		hm.put("SECU_FLAG", "HTP_QRY_SECU_FLAG;m;x");
		hm.put("TERM_CALLBACK", "HTP_QRY_TERM_CALLBACK;m;x");
		hm.put("USERDN", "HTP_QRY_USERDN;m;k");
		hm.put("Citygbn", "HTP_QRY_CITYGBN;m;x");
		hm.put("ATS_TITL", "HTP_QRY_ATS_TITL;m;x");
		hm.put("APPR1USERID1", "HTP_QRY_APPR1USERID1;m;x");
		hm.put("hid_enc_data", "HTP_QRY_HID_ENC_DATA;m;x");
		hm.put("report_name", "HTP_QRY_REPORT_NAME;m;x");
		hm.put("EML", "HTP_QRY_EML;m;f");
		hm.put("strCnUrl", "HTP_QRY_STRCNURL;m;x");
		hm.put("INT_BSDT", "HTP_QRY_INT_BSDT;m;x");
		hm.put("callback", "HTP_QRY_CALLBACK;m;x");
		hm.put("fromId", "HTP_QRY_FROMID;m;x");
		hm.put("toId", "HTP_QRY_TOID;m;x");
		hm.put("CCD_REQ_SIZE", "HTP_QRY_CCD_REQ_SIZE;m;x");
		hm.put("DPAC_BAL", "HTP_QRY_DPAC_BAL;m;x");
		hm.put("IGNORE", "HTP_QRY_IGNORE;m;x");
		hm.put("NATION_TEL_30", "HTP_QRY_NATION_TEL_30;m;x");
		hm.put("ADD_AUTH_MSG", "HTP_QRY_ADD_AUTH_MSG;m;x");
		hm.put("ADDRESS", "HTP_QRY_ADDRESS;m;e");
		hm.put("ZIP_CODE", "HTP_QRY_ZIP_CODE;m;x");
		hm.put("FAX", "HTP_QRY_FAX;m;x");
		hm.put("EUSER_NAME", "HTP_QRY_EUSER_NAME;m;k");
		hm.put("REG_SMART_YN", "HTP_QRY_REG_SMART_YN;m;x");
		hm.put("TSKD_1", "HTP_QRY_TSKD_1;m;x");
		hm.put("actKd", "HTP_QRY_ACTKD;m;x");
		hm.put("TSENDDY_8", "HTP_QRY_TSENDDY_8;m;x");
		hm.put("TSSTADY_8", "HTP_QRY_TSSTADY_8;m;x");
		hm.put("PRME_ITCD_LIST", "HTP_QRY_PRME_ITCD_LIST;m;x");
		hm.put("SUB_LIF_TEL", "HTP_QRY_SUB_LIF_TEL;m;x");
		hm.put("TPS_PDCD", "HTP_QRY_TPS_PDCD;m;x");
		hm.put("NATION_CD2", "HTP_QRY_NATION_CD2;m;x");
		hm.put("RESULT_STS_", "HTP_QRY_RESULT_STS_;m;x");
		hm.put("TOT_TRAMT", "HTP_QRY_TOT_TRAMT;m;x");
		hm.put("INQ_NUM", "HTP_QRY_INQ_NUM;m;x");
		hm.put("RESULT_STSA", "HTP_QRY_RESULT_STSA;m;x");
		hm.put("wibee_market_id_yn", "HTP_QRY_WIBEE_MARKET_ID_YN;m;x");
		hm.put("PWNO_RGS_DSCD", "HTP_QRY_PWNO_RGS_DSCD;m;x");
		hm.put("PWNO_8", "HTP_QRY_PWNO_8;m;f");
		hm.put("CLMNY_NO_50", "HTP_QRY_CLMNY_NO_50;m;x");
		hm.put("RDU_FEE_AM", "HTP_QRY_RDU_FEE_AM;m;x");
		hm.put("WMB_RDU_AM", "HTP_QRY_WMB_RDU_AM;m;x");
		hm.put("transkey_Tk_PWNO_8", "HTP_QRY_TRANSKEY_TK_PWNO_8;m;f");
		hm.put("Tk_PWNO_8_check", "HTP_QRY_TK_PWNO_8_CHECK;m;x");
		hm.put("transkey_hMac_Tk_PWNO_8", "HTP_QRY_TRANSKEY_HMAC_TK_PWNO_8;m;f");
		hm.put("WIBEE_MNY_DDU_AM", "HTP_QRY_WIBEE_MNY_DDU_AM;m;x");
		hm.put("SMRT_LN_JNNG_YN", "HTP_QRY_SMRT_LN_JNNG_YN;m;x");
		hm.put("T_CHECK", "HTP_QRY_T_CHECK;m;x");
		hm.put("DIS_FEE", "HTP_QRY_DIS_FEE;m;x");
		hm.put("NGO_BR_5", "HTP_QRY_NGO_BR_5;m;x");
		hm.put("CUS_ACNO", "HTP_QRY_CUS_ACNO;m;e");
		hm.put("INQ_EDT_10Y", "HTP_QRY_INQ_EDT_10Y;m;x");
		hm.put("INQ_SDT_10D", "HTP_QRY_INQ_SDT_10D;m;x");
		hm.put("INQ_SDT_10Y", "HTP_QRY_INQ_SDT_10Y;m;x");
		hm.put("INQ_SDT_10M", "HTP_QRY_INQ_SDT_10M;m;x");
		hm.put("INQ_EDT_10D", "HTP_QRY_INQ_EDT_10D;m;x");
		hm.put("INQ_EDT_10M", "HTP_QRY_INQ_EDT_10M;m;x");
		hm.put("standardDate2", "HTP_QRY_STANDARDDATE2;m;x");
		hm.put("standardDate1", "HTP_QRY_STANDARDDATE1;m;x");
		hm.put("oper1", "HTP_QRY_OPER1;m;x");
		hm.put("oper2", "HTP_QRY_OPER2;m;x");
		hm.put("TXPR_DSCD", "HTP_QRY_TXPR_DSCD;m;x");
		hm.put("RPY_AM", "HTP_QRY_RPY_AM;m;x");
		hm.put("CHRG_KDCD_2", "HTP_QRY_CHRG_KDCD_2;m;x");
		hm.put("USER_DN", "HTP_QRY_USER_DN;m;x");
		hm.put("PNT_INT_PYM_YN", "HTP_QRY_PNT_INT_PYM_YN;m;x");
		hm.put("MB_PNT_AM", "HTP_QRY_MB_PNT_AM;m;x");
		hm.put("PWNO_8__E2E__", "HTP_QRY_PWNO_8__E2E__;m;f");
		hm.put("HP_COM_CD", "HTP_QRY_HP_COM_CD;m;f");
		hm.put("INQ_TYPE", "HTP_QRY_INQ_TYPE;m;x");
		hm.put("NEXT_CNT", "HTP_QRY_NEXT_CNT;m;x");
		hm.put("SMSD_DSCD", "HTP_QRY_SMSD_DSCD;m;x");
		hm.put("bbsMode", "HTP_QRY_BBSMODE;m;x");
		hm.put("ARTICLE_ID", "HTP_QRY_ARTICLE_ID;m;x");
		hm.put("PUP_NAPL_EDT", "HTP_QRY_PUP_NAPL_EDT;m;x");
		hm.put("RSN_TXT", "HTP_QRY_RSN_TXT;m;x");
		hm.put("POPUP_ID", "HTP_QRY_POPUP_ID;m;x");
		hm.put("ACTPWNO_8_REALVAL", "HTP_QRY_ACTPWNO_8_REALVAL;m;f");
		hm.put("CERT_KIND", "HTP_QRY_CERT_KIND;m;x");
		hm.put("SMS_MSG", "HTP_QRY_SMS_MSG;m;x");
		hm.put("ksP2", "HTP_QRY_KSP2;m;x");
		hm.put("pageNo", "HTP_QRY_PAGENO;m;x");
		hm.put("RCV_ACCT_CD", "HTP_QRY_RCV_ACCT_CD;m;x");
		hm.put("TS_KDCD_2", "HTP_QRY_TS_KDCD_2;m;x");
		hm.put("HP_TLEN_NO", "HTP_QRY_HP_TLEN_NO;m;f");
		hm.put("returnValue", "HTP_QRY_RETURNVALUE;m;x");
		hm.put("TR_SEQ", "HTP_QRY_TR_SEQ;m;x");
		hm.put("HP_SRNO", "HTP_QRY_HP_SRNO;m;f");
		hm.put("RGSDY_8", "HTP_QRY_RGSDY_8;m;x");
		hm.put("ITPY_CYCD", "HTP_QRY_ITPY_CYCD;m;x");
		hm.put("focusId", "HTP_QRY_FOCUSID;m;x");
		hm.put("actKdKr", "HTP_QRY_ACTKDKR;m;x");
		hm.put("readonly", "HTP_QRY_READONLY;m;x");
		hm.put("msg2", "HTP_QRY_MSG2;m;x");
		hm.put("msg1", "HTP_QRY_MSG1;m;x");
		hm.put("frm", "HTP_QRY_FRM;m;x");
		hm.put("valFormat", "HTP_QRY_VALFORMAT;m;x");
		hm.put("PRD_ARG_SKIP_YN", "HTP_QRY_PRD_ARG_SKIP_YN;m;x");
		hm.put("Tk_PSBZ_NO_4_check", "HTP_QRY_TK_PSBZ_NO_4_CHECK;m;x");
		hm.put("transkey_hMac_Tk_PSBZ_NO_4", "HTP_QRY_TRANSKEY_HMAC_TK_PSBZ_NO_4;m;x");
		hm.put("transkey_Tk_PSBZ_NO_4", "HTP_QRY_TRANSKEY_TK_PSBZ_NO_4;m;x");
		hm.put("detaildata", "HTP_QRY_DETAILDATA;m;x");
		hm.put("masterdata", "HTP_QRY_MASTERDATA;m;x");
		hm.put("PSBZ_NO_4", "HTP_QRY_PSBZ_NO_4;m;x");
		hm.put("SVC_USER_ID", "HTP_QRY_SVC_USER_ID;m;x");
		hm.put("SVC_AUTH_TOKEN", "HTP_QRY_SVC_AUTH_TOKEN;m;x");
		hm.put("SVC_AUTH_TYPE", "HTP_QRY_SVC_AUTH_TYPE;m;x");
		hm.put("PAY_ACNO_15", "HTP_QRY_PAY_ACNO_15;m;e");
		hm.put("ENCY_WDR_ACT_PWNO", "HTP_QRY_ENCY_WDR_ACT_PWNO;m;f");
		hm.put("OBK_UNQ_NO", "HTP_QRY_OBK_UNQ_NO;m;x");
		hm.put("OUTCALL_USE_YN", "HTP_QRY_OUTCALL_USE_YN;m;x");
		hm.put("DOKDO_CLICK", "HTP_QRY_DOKDO_CLICK;m;x");
		hm.put("CUS_INF_HP_SER", "HTP_QRY_CUS_INF_HP_SER;m;x");
		hm.put("CUS_INF_HP_RGN", "HTP_QRY_CUS_INF_HP_RGN;m;x");
		hm.put("CPON_SMS_CHR_RQ_YN", "HTP_QRY_CPON_SMS_CHR_RQ_YN;m;x");
		hm.put("CUS_INF_HP_TLEN", "HTP_QRY_CUS_INF_HP_TLEN;m;x");
		hm.put("CARD_INQ_ERROR", "HTP_QRY_CARD_INQ_ERROR;m;e");
		hm.put("LPOINT_USE_YN", "HTP_QRY_LPOINT_USE_YN;m;x");
		hm.put("OBK_TS_YN", "HTP_QRY_OBK_TS_YN;m;x");
		hm.put("LPOINT_COP_MCNO", "HTP_QRY_LPOINT_COP_MCNO;m;x");
		hm.put("IS_SMTJOIN_VISIBLE", "HTP_QRY_IS_SMTJOIN_VISIBLE;m;x");
		hm.put("INQ_BAS_DT", "HTP_QRY_INQ_BAS_DT;m;x");
		hm.put("cddinfo_ins", "HTP_QRY_CDDINFO_INS;m;x");
		hm.put("WIBTALKC", "HTP_QRY_WIBTALKC;m;x");
		hm.put("returnFNDTSPWNO_8", "HTP_QRY_RETURNFNDTSPWNO_8;m;f");
		hm.put("VIEW_AUT", "HTP_QRY_VIEW_AUT;m;x");
		hm.put("sltChkBox", "HTP_QRY_SLTCHKBOX;m;x");
		hm.put("PRD_CD_9_1", "HTP_QRY_PRD_CD_9_1;m;x");
		hm.put("AccTitle", "HTP_QRY_ACCTITLE;m;x");
		hm.put("SEARCH_TXT", "HTP_QRY_SEARCH_TXT;m;x");
		hm.put("CTRTM_MCN", "HTP_QRY_CTRTM_MCN;m;x");
		hm.put("total", "HTP_QRY_TOTAL;m;x");
		hm.put("rcpenmdata", "HTP_QRY_RCPENMDATA;m;x");
		hm.put("RCV_PBOK_TXT", "HTP_QRY_RCV_PBOK_TXT;m;x");
		hm.put("DPI", "HTP_QRY_DPI;m;x");
		hm.put("pageNumber", "HTP_QRY_PAGENUMBER;m;x");
		hm.put("html5", "HTP_QRY_HTML5;m;x");
		hm.put("SHOW_NUM_USE_YN", "HTP_QRY_SHOW_NUM_USE_YN;m;x");
		hm.put("PRD_AGR_ITEMS", "HTP_QRY_PRD_AGR_ITEMS;m;x");
		hm.put("STL_DT", "HTP_QRY_STL_DT;m;x");
		hm.put("modActiveX", "HTP_QRY_MODACTIVEX;m;x");
		hm.put("UseOriginImage", "HTP_QRY_USEORIGINIMAGE;m;x");
		hm.put("isChartToImage", "HTP_QRY_ISCHARTTOIMAGE;m;x");
		hm.put("Accessibility", "HTP_QRY_ACCESSIBILITY;m;x");
		hm.put("DFR_YN", "HTP_QRY_DFR_YN;m;x");
		hm.put("APPR1MobCHK1", "HTP_QRY_APPR1MOBCHK1;m;x");
		hm.put("TRN_CNT", "HTP_QRY_TRN_CNT;m;x");
		hm.put("FEE_RDU_CD_3", "HTP_QRY_FEE_RDU_CD_3;m;x");
		hm.put("TOT_FEE_AM_11", "HTP_QRY_TOT_FEE_AM_11;m;x");
		hm.put("GRID_FIRST_CNT", "HTP_QRY_GRID_FIRST_CNT;m;x");
		hm.put("BF_RCV_INQ_CNT", "HTP_QRY_BF_RCV_INQ_CNT;m;x");
		hm.put("OBK_FEE_BY_CNT_11", "HTP_QRY_OBK_FEE_BY_CNT_11;m;x");
		hm.put("TBK_FEE_BY_CNT_11", "HTP_QRY_TBK_FEE_BY_CNT_11;m;x");
		hm.put("FeeInq_YN", "HTP_QRY_FEEINQ_YN;m;x");
		hm.put("FILE_LOAD_CNT", "HTP_QRY_FILE_LOAD_CNT;m;x");
		hm.put("LOG_MSG", "HTP_QRY_LOG_MSG;m;x");
		hm.put("APPR1USERHP1", "HTP_QRY_APPR1USERHP1;m;x");
		hm.put("PBOK_PRT_TXT_DIS", "HTP_QRY_PBOK_PRT_TXT_DIS;m;x");
		hm.put("RSV_TIME", "HTP_QRY_RSV_TIME;m;x");
		hm.put("AF_RCV_INQ_CNT", "HTP_QRY_AF_RCV_INQ_CNT;m;x");
		hm.put("RSV_TIME_CK", "HTP_QRY_RSV_TIME_CK;m;x");
		hm.put("gizaYN", "HTP_QRY_GIZAYN;m;x");
		hm.put("isErrDel_YN", "HTP_QRY_ISERRDEL_YN;m;x");
		hm.put("filedata", "HTP_QRY_FILEDATA;m;x");
		hm.put("tranData", "HTP_QRY_TRANDATA;m;x");
		hm.put("sCodes", "HTP_QRY_SCODES;m;x");
		hm.put("sValue2", "HTP_QRY_SVALUE2;m;x");
		hm.put("sValue3", "HTP_QRY_SVALUE3;m;x");
		hm.put("sendDataCnt", "HTP_QRY_SENDDATACNT;m;x");
		hm.put("sumTotActNo", "HTP_QRY_SUMTOTACTNO;m;e");
		hm.put("SVC_EVENT_ID", "HTP_QRY_SVC_EVENT_ID;m;x");
		hm.put("SVC_APP_CERT_HASH", "HTP_QRY_SVC_APP_CERT_HASH;m;x");
		hm.put("SVC_APP_ID", "HTP_QRY_SVC_APP_ID;m;x");
		hm.put("WDR_PBOK_TXT", "HTP_QRY_WDR_PBOK_TXT;m;x");
		hm.put("TS_TEM_UNCD", "HTP_QRY_TS_TEM_UNCD;m;x");
		hm.put("SVC_CD", "HTP_QRY_SVC_CD;m;x");
		hm.put("fromWhere", "HTP_QRY_FROMWHERE;m;x");
		hm.put("CODE", "HTP_QRY_CODE;m;x");
		hm.put("RCV_OWAC_NM", "HTP_QRY_RCV_OWAC_NM;m;k");
		hm.put("s", "HTP_QRY_S;m;x");
		hm.put("qrBrCd", "HTP_QRY_QRBRCD;m;x");
		hm.put("qrAdvpeNo", "HTP_QRY_QRADVPENO;m;x");
		hm.put("t", "HTP_QRY_T;m;x");
		hm.put("c", "HTP_QRY_C;m;x");
		hm.put("no", "HTP_QRY_NO;m;x");
		
		
		// ^\t([^\(]*)\(\"\.HTTP_QUERY\.([^\"]*)\", ([^,]*), ([^,]*),.*$
		// \thm.put\("\2", "\1;\3;\4"\);
		
		String tmpVal = null;
		
		if (src.exists()) {
			
			idxLn = 0L;
			
			try (Connection conn = DriverManager.getConnection("jdbc:ignite:thin://10.214.121.67:10800,10.214.121.68:10800,10.214.121.69:10800;lazy=true;distributedJoins=true")) {
				
	            try (Statement stmt = conn.createStatement()) {
	                stmt.executeUpdate("SET STREAMING ON");
	            }			
			
				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
					
	//				File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + "_mst.json");
					File wrFile = new File(TGT_PATH);
					
					OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET);
					
					String rd_line = null;
					
					while ((rd_line = br.readLine()) != null
							
//							&& idxLn < 5
							
							) {
						
						idxLn++;
						
	//					if(
	//						idxLn == 398289
	//						idxLn < 500000
	//					) {
	//						continue;
	//					} 
						
						json = gs.fromJson(rd_line, JsonObject.class);
						
						
						/*** 	json 추가 구역  	***/
						
						// host_ip_addr
						json.addProperty("HOST_IP_ADDR", parseString(json.get("REMOTE_ADDR")));
						
						// host_domain
						json.addProperty("HOST_DOMAIN", parseString(json.get("SERVER_HOST"), "([a-zA-Z0-9_]*)\\.wooribank\\.com"));
						
						// parseHttpTime
						json = parseHttpTime(json, parseString(json.get("HTTP_TIME")));
						
						// parseRemoteUser
						json = parseRemoteUser(json, parseString(json.get("REMOTE_USER")));					
						
						// parseUserAgent
						json = parseUserAgent(json, parseString(json.get("USER_AGENT")));		
						
						
						// http parsing
						// http_query 존재 유무 체크
						
						String sReferer = null; 
						if( json.get("HTTP_REFERER") != null && !json.get("HTTP_REFERER").getAsString().trim().isEmpty() ) {
							sReferer = json.get("HTTP_REFERER").getAsString();
						}
						
						List<String> forEnc = null;
						List<String> forMask = null;
						
						// http_query_json_dummy
						if( json.get("HTTP_QUERY") != null ) {
							
								jsonHtpQry = parseLine(parseString(json.get("HTTP_QUERY")));
	//							log.debug("jsonHtpQry : {}", jsonHtpQry);
								
							if(jsonHtpQry != null) {
								
								String htpQryDummy = gs.toJson(jsonHtpQry.get("HTTP_QUERY"));
								
								json.addProperty("HTTP_QUERY_JSON_DUMMY", htpQryDummy);
								TreeMap<String, String> tm = null;
								
								try {
									tm = KeyParseUtil.parseKeyValues(htpQryDummy);
								} catch(Exception e) {
									log.debug("error {} ln : {} ", idxLn, htpQryDummy);
									
									continue;
								}
								
	//							log.debug("{}",KeyParseUtil.parseJsonPathKeys(htpQryDummy));
	//							log.debug("{}", tm);
								
								int k = 0;
								
								JsonObject jsonHtpQryParses = new JsonObject(); 
								
								forEnc = new ArrayList<String>();
								forMask = new ArrayList<String>();
								
								for(String t : tm.keySet()) {
									
									k++;
	//								System.out.println(t);
									
									if(hm.containsKey(t)) {
	//									log.debug("{} = {}, {}", t, tm.get(t), hm.get(t));
	
										String tmp[] = hm.get(t).toString().split(";");
										
										jsonHtpQryParses.addProperty(tmp[0], tm.get(t));
										
										// move or dump
										switch(tmp[1]) {
										
										case "d":
										case "m":
											jsonHtpQryParses.addProperty(tmp[0], tm.get(t));
											break;										
										
										default:
											
										}									
										
										// enc, mask, full_mask
										switch(tmp[2]) {
										
										case "e":
											forEnc.add(tmp[0]);
											break;
	
										case "k":
										case "f":
											forMask.add(tmp[0]);
											break;										
										
										default:
											
										}
									}
								}
								
								// merge
								// json , jsonHtpQryParses , jsonAdds 
								
	//							log.debug(jsonHtpQryParses.toString());
								
								
								JsonObject jsonAdds = new JsonObject();
	
	
								
								
	//							CPNT_ID				// HTTP_QUERY.__ID or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
								String sId = getJsonValue(jsonHtpQryParses, "HTP_QRY_ID");
								
								tmpVal = ParseCase.parseCpntId(sId, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("CPNT_ID", tmpVal);
								}
								
	//							CPNT_CN_INFO		// HTTP_QUERY.cc or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
								String sCc = getJsonValue(jsonHtpQryParses, "HTP_QRY_CC");
								tmpVal = ParseCase.parseCpntCnInfo(sCc, sReferer);
								if(tmpVal != null) {							
									jsonAdds.addProperty("CPNT_CN_INFO", tmpVal);
								}
								
	//							PLM_PDCD			// HTTP_QUERY.PLM_PDCD 단순 파싱 
								String sPlmPdcd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PLM_PDCD");
								tmpVal = ParseCase.parsePlmPdcd(sPlmPdcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("PLM_PDCD", tmpVal);
								}
								
	//							PRD_CD				// HTTP_QUERY.PRD_CD or HTTP_REFERER에서 추출
								String sPrdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PRD_CD");
								tmpVal = ParseCase.parsePrdCd(sPrdCd, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("PRD_CD", tmpVal);
								}
								
	//							EVENT_NO			// HTTP_QUERY.no 단순 파싱
								String eventNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_NO");
								tmpVal = ParseCase.parseEventNo(eventNo);
								if(tmpVal != null) {
									jsonAdds.addProperty("EVENT_NO", tmpVal);
								}
	
	//							PSNZ_CHNL_KEY		// HTTP_QUERY.m 단순 파싱
								String psnzChnlKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_M");
								tmpVal = ParseCase.parsePsnzChnlKey(psnzChnlKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_CHNL_KEY", tmpVal);
								}
								
								
	//							PSNZ_AREA_KEY		// HTTP_QUERY.z 단순 파싱
								String psnzAreaKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_Z");
								tmpVal = ParseCase.parsePsnzAreaKey(psnzAreaKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_AREA_KEY", tmpVal);
								}
								
								
	//							PSNZ_SCNR_KEY		// HTTP_QUERY.s 단순 move
								String psnzScnrKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_S");
								if(psnzScnrKey != null) {
									jsonAdds.addProperty("PSNZ_SCNR_KEY", psnzScnrKey);
								}
								
								
	//							PSNZ_CTNS_KEY		// HTTP_QUERY.c 단순 파싱
								String psnzCtnsKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_C");
								tmpVal = ParseCase.parsePsnzCtnsKey(psnzCtnsKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_CTNS_KEY", tmpVal);
								}
	
								
	//							PSNZ_TGT_KEY		// HTTP_QUERY.t 단순 파싱
								String psnzTgtKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_T");
								tmpVal = ParseCase.parsePsnzTgtKey(psnzTgtKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_TGT_KEY", tmpVal);
								}
								
								
	//							CMD_CD				// HTTP_QUERY.cmd 단순 파싱
								String cmdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_CMD");
								tmpVal = ParseCase.parseCmdCd(cmdCd);
								if(tmpVal != null) {
									jsonAdds.addProperty("CMD_CD", tmpVal);
								}
								
								
	//							QR_BR_CD			// HTTP_QUERY.qrBrCd 단순 파싱
								String qrBrCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRBRCD");
								tmpVal = ParseCase.parseQrBrCd(qrBrCd);
								if(tmpVal != null) {
									jsonAdds.addProperty("QR_BR_CD", tmpVal);
								}
								
								
	//							QR_ADVPE_NO			// HTTP_QUERY.qrAdvpeNo 단순 파싱
								String sQrAdvpeNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRADVPENO");
								String sQr_advpe_no = getJsonValue(jsonHtpQryParses, "HTP_QRY_QR_ADVPE_NO");
								tmpVal = ParseCase.parseQrAdvpeNo(sQrAdvpeNo, sQr_advpe_no);
								if(tmpVal != null) {
									jsonAdds.addProperty("QR_ADVPE_NO", tmpVal);
								}
								
								
	//							INBK_SEARCH_TEXT	// HTTP_QUERY.query 단순 move	
								String inbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_QUERY");
								if(inbkSearchText != null) {
									jsonAdds.addProperty("INBK_SEARCH_TEXT", inbkSearchText);
								}
								
								
	//							SMTBK_SEARCH_TEXT	// HTTP_QUERY.searchText 단순 move
								String smtbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_SEARCHTEXT"); 
								if(smtbkSearchText != null) {
									jsonAdds.addProperty("SMTBK_SEARCH_TEXT", smtbkSearchText);
								}
								
								
	//							SEARCH_TEXT			// HTTP_QUERY.query or HTTP_QUERY.searchText 에서 추출 단순 파싱
								tmpVal = ParseCase.parseSearchText(inbkSearchText, smtbkSearchText);
								if(tmpVal != null) {
									jsonAdds.addProperty("SEARCH_TEXT", tmpVal);
								}
								
								
								
	//							PAGE_ID				// HTTP_QUERY.withyou or HTTP_REFERER에서 추출 - 복합 파싱 
								String withyou = getJsonValue(jsonHtpQryParses, "HTP_QRY_WITHYOU");
								tmpVal = ParseCase.parsePageId(withyou, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("PAGE_ID", tmpVal);
								}
								
								
	//							PAGE_STEP_ORDER		// HTTP_QUERY.__STEP or HTTP_REFERER에서 추출 - 복합 파싱, psnz_chnl_key == 30002 --> psnz_scnr_key
								String step = getJsonValue(jsonHtpQryParses, "HTP_QRY___STEP"); 
								
								if("30002".equals(psnzChnlKey)) {
									tmpVal = ParseCase.parsePageStepOrder(sReferer, psnzScnrKey, step);
									if(tmpVal != null) {
										jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
									}
								} else {
									tmpVal = ParseCase.parsePageStepOrder(sReferer, step);
									if(tmpVal != null) {
										jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
									}
								}
								
	
	//							log.debug("jsonAdds :  {}", jsonAdds.toString());							
								
								
								if(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA") != null
										&& jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA") != null
										&& !jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA").isJsonNull()
										) {
									
									// acno : .HTTP_QUERY.ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.ACNO	+ 암호화	
									String acno = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "ACNO"); 
									String htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
									tmpVal = ParseCase.parseAcno(acno, htpAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("ACNO", tmpVal);
										forEnc.add("ACNO");
									}
									
	
									//	bkcd : .HTTP_QUERY.BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.BKCD
									String bkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "BKCD");
									String htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
									tmpVal = ParseCase.parseBkcd(bkcd, htpBkcd);
									if(tmpVal != null) {
										jsonAdds.addProperty("BKCD", tmpVal);
									}
	
									
									//	inq_acno : .HTTP_QUERY.INQ_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.INQ_ACNO + 암호화 	
									String inqAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "INQ_ACNO");
									String htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
									tmpVal = ParseCase.parseInqAcno(inqAcNo, htpInqAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("INQ_ACNO", tmpVal);
										forEnc.add("INQ_ACNO");
									}
									
									
									// wdr_bkcd : .HTTP_QUERY.WDR_BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_BKCD
									String wdrBkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_BKCD");
									String htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
									tmpVal = ParseCase.parseWdrBkcd(wdrBkcd, htpWdrBkcd);
									if(tmpVal != null) {
										jsonAdds.addProperty("WDR_BKCD", tmpVal);
									}
								
									
									// wdr_acno : .HTTP_QUERY.WDR_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_ACNO + 암호화	
									String wdrAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_ACNO");
									String htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
									tmpVal = ParseCase.parseInqAcno(wdrAcNo, htpWdrAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("WDR_ACNO", tmpVal);
										forEnc.add("WDR_ACNO");
									}
									
								} else {
									
									
									String htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
									tmpVal = ParseCase.parseAcno(htpAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("ACNO", tmpVal);
										forEnc.add("ACNO");
									}
									
									String htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
									tmpVal = ParseCase.parseBkcd(htpBkcd);
									if(tmpVal != null) {
										jsonAdds.addProperty("BKCD", tmpVal);
									}
									
									String htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
									tmpVal = ParseCase.parseInqAcno(htpInqAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("INQ_ACNO", tmpVal);
										forEnc.add("INQ_ACNO");
									}
									
									String htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
									tmpVal = ParseCase.parseWdrBkcd(htpWdrBkcd);
									if(tmpVal != null) {
										jsonAdds.addProperty("WDR_BKCD", tmpVal);
									}
	
									String htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
									tmpVal = ParseCase.parseInqAcno(htpWdrAcno);
									if(tmpVal != null) {
										jsonAdds.addProperty("WDR_ACNO", tmpVal);
										forEnc.add("WDR_ACNO");								
									}
								}
								
								forEnc.add("HTTP_QUERY");
								forEnc.add("HTTP_QUERY_JSON_DUMMY");
								
								
								// 만들어야 될것
								// json merge util
	//							JsonUtil.merge(obj);
								
								
								// key 존재 유무 util + trim 포함
								// 일반 httpQry 암호화 처리 로직 추가							
								
								
								// 나머지 http 항목 머지
								// 항목 중에 암호화 대상 암호화 처리
						
								
	//							log.debug("json : {}", json.toString());
	//							log.debug("jsonHtpQryParses : {}", jsonHtpQryParses.toString());
	//							log.debug("jsonAdds : {}", jsonAdds.toString());
								
								
								json = JsonUtil.merge(json, jsonAdds, jsonHtpQryParses);
								
								
	//							log.debug("json total : {}", json.toString());
								
									
							} else { // jsonHtpQry가 null 일 경우 ( json화 가능한 포맷이 아니라서 파싱이 되지 않는 경우 )
								
								
								json.add("HTTP_QUERY_JSON_DUMMY", null);
								
	//							cpnt_id				// HTTP_REFERER에서 __ID 추출
								tmpVal = ParseCase.parseCpntId(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("CPNT_ID", tmpVal);
								}
								
	//							cpnt_cn_info		// HTTP_REFERER에서 cc 추출
								tmpVal = ParseCase.parseCpntCnInfo(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("CPNT_CN_INFO", tmpVal);
								}
								
	//							prd_cd				// HTTP_REFERER에서 PRD_CD 추출
								tmpVal = ParseCase.parsePrdCd(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("PRD_CD", tmpVal);
								}
								
								
	//							page_id				// HTTP_REFERER에서 withyou 추출 - 복합 파싱
								tmpVal = ParseCase.parsePageId(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("PAGE_ID", tmpVal);
								}
								
	//							page_step_order		// HTTP_REFERER에서 __STEP 추출 - 복합 파싱
								tmpVal = ParseCase.parsePageStepOrder(sReferer, "" );
								if(tmpVal != null) {
									json.addProperty("PAGE_STEP_ORDER", tmpVal);
								}
								
								
	//							log.debug("json : {}", json.toString());							
								
							}
								
						}
	
						
	//					log.debug("forEnc : {}", forEnc != null ? forEnc.toString() : null);
	//					log.debug("forMask : {}", forMask != null ? forMask.toString() : null);
						
	//					log.debug(json.toString());			
						
						
						// 처리한 내역 file write
						
						String rsltStr = gs.toJson(json) + "\n";
						
						owr.write(rsltStr);
						
						
						JsonObject jtmp = json;
						
						boolean enc = true;
						
						if(enc == true && json != null) {
							
							if( forEnc != null && !forEnc.isEmpty() ) {
								for(String enckey : forEnc ) {
									
	//								log.debug("enckey {} -- {}",enckey, json.get(enckey));
									
									if(jtmp.get(enckey) != null 
											&& !jtmp.get(enckey).isJsonNull()
											&& !jtmp.get(enckey).getAsString().trim().isEmpty()
									) {
										String encStr = DamoEncUtil.data_encryption(jtmp.get(enckey).getAsString(), "string");
										jtmp.addProperty(enckey, encStr);
									}
									
								}
							}
							
							if( forMask != null && !forMask.isEmpty() ) {
								
								for(String maskkey : forEnc ) {
								
									if(jtmp.get(maskkey) != null
											&& !jtmp.get(maskkey).isJsonNull()
											&& !jtmp.get(maskkey).getAsString().trim().isEmpty()
									) {
	//									String maskStr = jtmp.get(maskkey).getAsString().replaceAll(".", "*");
										String maskStr = "*****";
	//									log.debug(maskStr);					
										jtmp.addProperty(maskkey, maskStr);
									}
									
								}
							}						
							
						}
						
						
						String jsonVo = gs.toJson(json);
						
						ResultVo rs = IMDGUtil.makeInsertQryFromVo(jsonVo, "RTO0002TM");
						
//						log.debug(rs.getQuery());
						
						try (PreparedStatement stmt = conn.prepareStatement(rs.getQuery())) {
							
							int idx = 1;
							for(String val : rs.getArgs()) {
								stmt.setString(idx++, val);				
							}
							
							stmt.executeUpdate();
						}
						
	
						
					}
					
					owr.close();
					br.close();
					
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					log.debug("{}",idxLn);
					e.printStackTrace();
				}
				
	            try (Statement stmt = conn.createStatement()) {
	                stmt.executeUpdate("SET STREAMING OFF");
	            }
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}		
	

	// RTOParseLogic Util

	private String[] explode(String str, String delim, boolean isTrim) {
		int delimLength = delim.length();

		List<String> list = new LinkedList<String>();
		int sidx = 0;
		int eidx = 0;
		while (true) {
			eidx = str.indexOf(delim, sidx);
			String col = _substring(str, sidx, eidx, isTrim);
			list.add(col);

			if (eidx == -1)
				break;

			sidx = eidx + delimLength;
		}

		return list.toArray(new String[list.size()]);
	}	
	
	private String _substring(String str, int sidx, int eidx, boolean isTrim) {
		String retval;
		if (eidx < 0)
			retval = str.substring(sidx);
		else
			retval = str.substring(sidx, eidx);

		if (isTrim)
			return retval.trim();
		else
			return retval;
	}	
	
	
	private String parseString(JsonElement jel) {
		if(jel != null) {
			return jel.getAsString();
		}
		return null;
	}	
		
	private String parseString(JsonElement jel, String sPtn) {
		
		if(jel != null) {
			
			String rslt = jel.getAsString();
			
			if(sPtn != null) {
				
				rslt = parsePtn(jel.getAsString(), sPtn);
			}
			
			return rslt;
		}
		return null;
	}

	private String parsePtn(String src, String sPtn) {

		if (src == null || "".equals(src.trim())) {
			return null;
		}

		Pattern ptn = Pattern.compile(sPtn);
		Matcher mtch = ptn.matcher(src);
		StringBuilder rslt = new StringBuilder();

		while (mtch.find() && mtch.groupCount() != 0) {

//			if (mtch.groupCount() > 1) {
//
//				log.debug("{} : {} ===> ", sPtn, src);
//
//				for (int i = 0; i <= mtch.groupCount(); i++) {
//					log.debug("{} : {}, ", i, mtch.group(i));
//				}
//			}

			rslt.append(mtch.group(1));
		}

		return rslt.length() == 0 ? null : rslt.toString();
	}


	private JsonObject parseHttpTime(JsonObject json, String src) {

		JsonObject rslt = json;

		if (src == null || src.trim().isEmpty()) {
//			rslt.add("YMDH", null);
//			rslt.add("HTTP_TIME_OCCUR_DATE", null);
//			rslt.add("HTTP_TIME_OCCUR_TIME", null);
			return rslt;
		}

		if (src.trim().length() >= 10) {
			rslt.addProperty("YMDH", src.substring(0, 10));
		}
		
		if (src.trim().length() >= 8) {
			rslt.addProperty("HTTP_TIME_OCCUR_DATE", src.substring(0, 8));
		}

		if (src.trim().length() == 17) {
			rslt.addProperty("HTTP_TIME_OCCUR_TIME", src.substring(8, 17));
		}
		
//		printHashMap(rsltMap);

		return rslt;
	}	
	
	
	private JsonObject parseRemoteUser(JsonObject json, String src) {

		JsonObject rslt = json;

		if (src == null || src.trim().isEmpty()) {
//			rslt.add("REMOTE_USER_ID", null);
//			rslt.add("REMOTE_USER_SEX", null);
//			rslt.add("REMOTE_USER_AGE", null);
//			rslt.add("REMOTE_USER_LOGINTYPE", null);
			return rslt;
		}

		String[] sTmp = explode(src, "_/", true);

		int c = sTmp.length;

		switch (c) {

//		case 4:
//			rslt.addProperty("REMOTE_USER_LOGINTYPE", sTmp[3]);
//		case 3:
//			rslt.addProperty("REMOTE_USER_AGE", sTmp[2]);
//		case 2:
//			rslt.addProperty("REMOTE_USER_SEX", sTmp[1]);
//		case 1:
//			rslt.addProperty("REMOTE_USER_ID", sTmp[0]);
			
		case 1:
			rslt.addProperty("REMOTE_USER_ID", sTmp[0]);
			break;
		case 2:
			rslt.addProperty("REMOTE_USER_ID", sTmp[0]);
			rslt.addProperty("REMOTE_USER_SEX", sTmp[1]);
			break;			
		case 3:
			rslt.addProperty("REMOTE_USER_ID", sTmp[0]);
			rslt.addProperty("REMOTE_USER_SEX", sTmp[1]);
			rslt.addProperty("REMOTE_USER_AGE", sTmp[2]);
			break;			
		case 4:
			rslt.addProperty("REMOTE_USER_ID", sTmp[0]);
			rslt.addProperty("REMOTE_USER_SEX", sTmp[1]);
			rslt.addProperty("REMOTE_USER_AGE", sTmp[2]);			
			rslt.addProperty("REMOTE_USER_LOGINTYPE", sTmp[3]);
			break;
		default:

		}

//		printHashMap(rsltMap);

		return rslt;
	}	
	
	
	private JsonObject parseUserAgent(JsonObject json, String src) {

		JsonObject rslt = json;
		
		if (src == null || src.trim().isEmpty()) {

//			rslt.add("USER_AGENT_OSINFO_ANDROID", null);
//			rslt.add("USER_AGENT_MODEL_INFO_ANDROID", null);
//			rslt.add("USER_AGENT_OSINFO_IOS", null);
//			rslt.add("USER_AGENT_MODEL_INFO_IOS", null);
//			rslt.add("NMA_APP_VER", null);
//			rslt.add("PUSH_ID", null);
//			rslt.add("ADID", null);
//			rslt.add("IDFA", null);
			
			return rslt;
		}
		
		final String userAgentOsinfoAndroidPtn = ";.?Android.?([0-9\\.]*);.?[^;|\\)]*";
		final String userAgentModelInfoAndroidPtn = ";.?Android.?[0-9\\.]*;.?([^;|\\)]*)";
		final String userAgentOsinfoIosPtn = ";.?CPU .*?OS.?([0-9_]*)[^;]*";
		final String userAgentModelInfoIosPtn = "\\([^;]*;.?[U|u];.?CPU (.*)?OS.?[0-9_]*[^;]*";
		final String nmpAppVerPtn = ";nma-app-ver=[\\[]?([0-9\\.]*)";
		final String pushIdPtn = ";push-id=([^;]*)";
		final String adidPtn = ";ADID=([a-zA-Z0-9-]*)";
		final String idfaPtn = ";IDFA=([^;]*)";

		rslt.addProperty("USER_AGENT_OSINFO_ANDROID", parsePtn(src, userAgentOsinfoAndroidPtn));
		rslt.addProperty("USER_AGENT_MODEL_INFO_ANDROID", parsePtn(src, userAgentModelInfoAndroidPtn));
		rslt.addProperty("USER_AGENT_OSINFO_IOS", parsePtn(src, userAgentOsinfoIosPtn));
		rslt.addProperty("USER_AGENT_MODEL_INFO_IOS", parsePtn(src, userAgentModelInfoIosPtn));
		rslt.addProperty("NMA_APP_VER", parsePtn(src ,nmpAppVerPtn));
		rslt.addProperty("PUSH_ID", parsePtn(src, pushIdPtn));
		rslt.addProperty("ADID", parsePtn(src, adidPtn));
		rslt.addProperty("IDFA", parsePtn(src, idfaPtn));

//		printHashMap(rslt);

		return rslt;
	}	
	
	
	private String getJsonValue(JsonElement jel, String key) {
		
		if(jel != null) {
			if(jel.getAsJsonObject().get(key) != null && !jel.getAsJsonObject().get(key).getAsString().trim().isEmpty()) {
				return jel.getAsJsonObject().get(key).getAsString();
			}
		}
		
		return null;
		
	}
	

	public static void main(String[] args) {

		Step001ImdgLogOrgToFile obj = new Step001ImdgLogOrgToFile();

//		obj.imdgLogOrgToCsv(
//			"/Proj/files/log_org.csv.info"
//		);
		
//		obj.imdgLogOrgToJsonFile(
//				"/Proj/files/log_org.json",
//				null,
//				null
//		);		
		
		obj.fileLogOrgToMstJsonFileImdg(
				"/Proj/files/log_org.json",
				"/Proj/files/log_org_mst.json"
			);
		
//		obj.fileLogOrgToMstJsonFile(
//			"/Proj/files/log_org.json",
//			"/Proj/files/log_org_mst.json"
//		);			

	}

}
