package com.woorifg.bigdata.rto.batch.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class JsonUtil {

	public static JsonObject merge(Object... obj) {
		
		JsonObject rslt = new JsonObject();
		
		for(int i=0;i<obj.length;i++) {
			
			if(obj[i] != null) {
				for(Entry<String, JsonElement> en : ((JsonObject)obj[i]).entrySet()) {
					rslt.add(en.getKey(), en.getValue());
				}
			} else {
				continue;
			}
		}
		
		return rslt;
	}
	
	
	public static void main(String[] args) {

		
		String[] src = {
			
				"{\"a\":\"aaa\"}",
				"{\"b\":\"bbb\"}",
				"{\"c\":\"ccc\"}",
				"aaa"
				
		};
		
		Gson gs = new Gson();
		
		
//		JsonElement j1 = gs.fromJson(src[0], JsonElement.class);
//		JsonObject jo1 = j1.getAsJsonObject();
//		
//		JsonElement j2 = gs.fromJson(src[1], JsonElement.class);
//		JsonObject jo2 = j2.getAsJsonObject();
//		
//		JsonObject rslt = merge(jo1, jo2);
//		
//		System.out.println(rslt.toString());
		
		
		List<JsonObject> jObjs = new ArrayList<JsonObject>();
		
		for(int i=0; i<src.length; i++) {
			
			try {
				jObjs.add(gs.fromJson(src[i], JsonElement.class).getAsJsonObject());
			} catch(IllegalStateException e) {
				JsonObject tmp = new JsonObject();
				tmp.addProperty("parse_err_" + String.valueOf(i+1), src[i]);
				jObjs.add(tmp);
			}
		}
		
		JsonObject rslt = merge(jObjs.toArray());

		
		System.out.println(rslt.toString());		

	}

}
