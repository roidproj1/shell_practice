package com.woorifg.bigdata.rto.batch.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class BaseParse {

	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(BaseParse.class);
	
	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";	
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";

	// Base Parser
	// (HTTP_QUERY="(.*)"\s*$)|(([_a-zA-Z]+)="([^"]*)")
	private static final String STEP_BASE = "(HTTP_QUERY=\"(.*)\"\\s*$)|(([_a-zA-Z0-9]+)=\"([^\"]*)\")";

	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String STEP_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";

	
	private static final Pattern ptnBase = Pattern.compile(STEP_BASE);
	private static final Pattern ptnHttpQuery = Pattern.compile(STEP_HTTP_QUERY);

	
	// Base Parser
	public static JsonObject parseLine(String src) throws Exception {
		return parseStepBase(src);
	}

	// HttpQry Parser
	public static JsonObject parseHttpQry(String src) throws Exception {
		
		JsonObject rsltJson = new JsonObject();
		
		JsonObject tmpHttpQry = parseStepHttpQuery(src);
		
		if (tmpHttpQry == null) {
			rsltJson.addProperty("HTTP_QUERY", src);
		} else {
			rsltJson.add("HTTP_QUERY", tmpHttpQry);
		}
		
		return rsltJson.size() == 0 ? null : rsltJson;
	}	
	
	
	// HttpQuery Parser
	private static JsonObject parseStepBase(String src) throws Exception {

		JsonObject rsltJson = new JsonObject();
		Matcher mtch = ptnBase.matcher(src);

		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				if (mtch.group(1) != null) {

					// 1: HTTP_QUERY Case --> 2: parseStepHttpQuery
					JsonObject tmpHttpQry = parseStepHttpQuery(mtch.group(2).toString());
//					log.debug("parseStepBase - HttpQuery : {}", tmpHttpQry==null?null:tmpHttpQry.toString());
					
					if (tmpHttpQry == null) {
						rsltJson.addProperty("HTTP_QUERY", mtch.group(2).toString());
					} else {
						rsltJson.add("HTTP_QUERY", tmpHttpQry);
					}

				} else if (mtch.group(3) != null) {
					
					// 3: Normal Case --> 4: key, 5: value
					rsltJson.addProperty(mtch.group(4).toString(), mtch.group(5).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}

	
	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		
		while (mtch.find()) {
			
			// Step 1 --> 0
			if (mtch.group(0) != null) {
				
				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {					
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch(JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {
					
					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch(JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) { 
					
					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {					
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch(JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}
					
				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value
//					//dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}	
	
}
