package com.woorifg.bigdata.rto.batch.enums_20220210;

public enum ECase {

	NEW,
	FIRST,
	SECOND,
	;
	
}
