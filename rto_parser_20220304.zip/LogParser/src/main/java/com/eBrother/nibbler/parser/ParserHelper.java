package com.eBrother.nibbler.parser;

import com.eBrother.nibbler.parser.impl.EBLogParser;
import com.eBrother.nibbler.parser.impl.ILogConst;
import com.eBrother.nibbler.parser.model.EBLog;


import com.eBrother.nibbler.util.UtilExt;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Hashtable;

public class ParserHelper {

    static ParserHelper me;

    public static ParserHelper getInstance () {

        if ( me == null ) {

            me = new ParserHelper ();
            return me;
        }
        return me;
    }

    private boolean run_parser ( String [] saz_dest, String szline ) {

        boolean bret = false;
        bret = EBLogParser.ccnt_util_parse_header( saz_dest, szline, "tag.jsp" );

        return bret;
    }

    public EBLog parseWNLog (String line ) {

        EBLog ebLog = new EBLog ();
        String [] saz_dest = new String [ILogConst.EB_REC_HEADER_CNT2];

        boolean bisgood = run_parser ( saz_dest, line );

        if ( ! bisgood ) return null;

        ebLog.setNibblerLog( saz_dest );

        return ebLog;

    }

    public String parse2Json ( String line ) throws JsonProcessingException {

        EBLog ebLog ;


        ebLog = parseWNLog( line );

        if ( ebLog == null ) return null;

        ObjectMapper mapper = new ObjectMapper();

        Hashtable<String, Object> record = new Hashtable<String, Object>();

        String query = ebLog.getQueryString ();
        String temp;
        Hashtable<String, String> hashQuery = new Hashtable<String, String> ();

        // 간혹 && 가 입수되는 경우가 있음 ...
        query = query.replace( "&&", "&");
        query = query.replace( "&&", "&");
        query = query.replace( "&&", "&");
        query = query.replace( "&&", "&");

        for ( int i = 1;; i++ ) {
            temp = UtilExt.getDelimitData( query, "&", i );
            if (temp.length() == 0 ) break;
            hashQuery.put( UtilExt.getDelimitData( temp, "=", 1), UtilExt.getDelimitData( temp, "=", 2 ));
        }

        Hashtable<String, String> hashRefQuery = new Hashtable<String, String> ();

        String [] ref = EBLogParser.ccnt_http_referer( ebLog.getREF());

        String refQuery = null;
        if ( ref[2] != null ) refQuery = ref[2];
        else if ( ref[1] != null ) refQuery = ref[1];

        if ( refQuery != null ) {
            for (int i = 1; ; i++) {
                temp = UtilExt.getDelimitData(refQuery, "&", i);
                if (temp.length() == 0) break;
                hashRefQuery.put(UtilExt.getDelimitData(temp, "=", 1), UtilExt.getDelimitData(temp, "=", 2));
            }
        }

        Hashtable<String, Object> hashRef = new Hashtable<String, Object> ();

        hashRef.put ( "ref-site", ref[0]);
        hashRef.put ( "ref-query", hashRefQuery );

        record.put( "ebrotherlog", ebLog );
        record.put( "query", hashQuery );
        record.put( "referer", hashRef );

        return mapper.writeValueAsString( record );

    }

    public String parse2JsonWN ( String line ) throws JsonProcessingException {

        EBLog ebLog ;


        ebLog = parseWNLog( line );

        String hostName = "";
        int idx = line.indexOf( "HOST_NAME=");


        if ( idx >= 0 ) {

            int last = line.indexOf( " ", idx + 11);

            if ( last > 0 ) {
                hostName = line.substring(10, last );
            }
        }

        if ( ebLog == null ) return null;

        ObjectMapper mapper = new ObjectMapper();

        Hashtable<String, Object> record = new Hashtable<String, Object>();

        record.put( "HTTP_TIME", ebLog.getYMDHMS() );
        record.put( "HTTP_CC_GUID", ebLog.getANON() );
        record.put( "HTTP_CC_SESSION", ebLog.getSESSION() );
        record.put( "SERVER_HOST", ebLog.getServerHost() );
        record.put( "SERVER_URL", ebLog.getURL() );
        record.put( "REMOTE_ADDR", ebLog.getIP() );
        record.put( "REMOTE_USER", ebLog.getUSERID() );
        record.put( "USER_AGENT", ebLog.getAGENT() );
        record.put( "HTTP_URI",  ebLog.getUri() );
        record.put( "HTTP_REFERER", ebLog.getREF() );
        record.put( "HTTP_COOKIE", ebLog.getCOOKIE() );
        record.put( "HTTP_METHOD", ebLog.getMethod () );
        record.put( "HTTP_QUERY", ebLog.getQueryString() );
        record.put( "HOST_NAME", hostName );

        return mapper.writeValueAsString( record );

    }

}
