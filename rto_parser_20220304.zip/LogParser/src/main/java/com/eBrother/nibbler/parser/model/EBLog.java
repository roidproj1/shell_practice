package com.eBrother.nibbler.parser.model;

import com.eBrother.nibbler.parser.impl.ILogConst;

public class EBLog {

    private String serverHost;
    private String uri;

    public String getServerHost() {
        return serverHost;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    private String method;
    private String hostName;

    private String IP = "";
    private String YMD = "";

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getYMD() {
        return YMD;
    }

    public void setYMD(String YMD) {
        this.YMD = YMD;
    }

    public String getHMS() {
        return HMS;
    }

    public void setHMS(String HMS) {
        this.HMS = HMS;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getQueryString() {
        return QUERY;
    }

    public void setQueryString(String QUERY) {
        this.QUERY = QUERY;
    }

    public String getREF() {
        return REF;
    }

    public void setREF(String REF) {
        this.REF = REF;
    }

    public String getCOOKIE() {
        return COOKIE;
    }

    public void setCOOKIE(String COOKIE) {
        this.COOKIE = COOKIE;
    }

    public String getUSERID() {
        return USERID;
    }

    public void setUSERID(String USERID) {
        this.USERID = USERID;
    }

    public String getSESSION() {
        return SESSION;
    }

    public void setSESSION(String SESSION) {
        this.SESSION = SESSION;
    }

    public String getAGENT() {
        return AGENT;
    }

    public void setAGENT(String AGENT) {
        this.AGENT = AGENT;
    }

    public String getSIZE() {
        return SIZE;
    }

    public void setSIZE(String SIZE) {
        this.SIZE = SIZE;
    }

    public String getANON() {
        return ANON;
    }

    public void setANON(String ANON) {
        this.ANON = ANON;
    }

    private String HMS = "";
    private String URL = "";
    private String QUERY = "";
    private String REF = "";
    private String COOKIE = "";
    private String USERID = "";
    private String SESSION = "";
    private String AGENT = "";
    private String SIZE = "";
    private String ANON = "";

    public String getYMDHMS() {
        return YMDHMS;
    }

    public void setYMDHMS(String YMDHMS) {
        this.YMDHMS = YMDHMS;
    }

    public String YMDHMS = "";

    public void clear () {


        IP = "";
        YMD = "";
        HMS = "";
        URL = "";
        QUERY = "";
        REF = "";
        COOKIE = "";
        USERID = "";
        SESSION = "";
        AGENT = "";
        SIZE = "";
        ANON = "";
        serverHost = "";
        uri = "";
        method = "";
        hostName = "";

    }

    public void copyLog ( EBLog logcur ) {


        IP 				= logcur.IP 			;
        YMD 			= logcur.YMD 		;
        HMS 			= logcur.HMS 		;
        URL 			= logcur.URL 		;
        QUERY 		= logcur.QUERY 	;
        REF 			= logcur.REF 		;
        COOKIE 		= logcur.COOKIE 	;
        USERID 		= logcur.USERID 	;
        SESSION 	= logcur.SESSION ;
        AGENT 		= logcur.AGENT 	;
        SIZE 			= logcur.SIZE 		;
        ANON 			= logcur.ANON 		;

        serverHost = logcur.serverHost;
        uri = logcur.uri;
        method = logcur.method;
        hostName = logcur.hostName;


    }

    public String get_dbkey () {

        String sztemp = "";

        sztemp += IP + ",";
        sztemp += YMD + ",";
        sztemp += HMS + ",";
        sztemp += USERID + ",";
        sztemp += AGENT + ",";
        sztemp += ANON += "";

        return sztemp;

    }

    public String toString () {

        String sztemp = "";

        sztemp += IP + ",";
        sztemp += YMD + ",";
        sztemp += HMS + ",";
        sztemp += URL + ",";
        sztemp += QUERY + ",";
        sztemp += REF + ",";
        sztemp += COOKIE + ",";
        sztemp += USERID + ",";
        sztemp += SESSION + ",";
        sztemp += AGENT + ",";
        sztemp += SIZE + ",";
        sztemp += ANON += "";

        return sztemp;

    }

    public boolean setNibblerLog ( String [] saz_dest ) {

        boolean bret = false;
        String sztemp;

        clear ();

        YMD = saz_dest[ILogConst.EB_REC_HEAD_TIME].substring(0,8);
        HMS = saz_dest[ILogConst.EB_REC_HEAD_TIME].substring(8);
        IP = saz_dest[ILogConst.EB_REC_HEAD_IP];

        URL = saz_dest[ILogConst.EB_REC_HEAD_URL];
        QUERY = saz_dest[ILogConst.EB_REC_HEAD_QUERY];

        REF = saz_dest[ILogConst.EB_REC_HEAD_REF];

        AGENT = saz_dest[ILogConst.EB_REC_HEAD_AGENT];

        sztemp = AGENT.replace(',', ' ');

        if ( sztemp.length() > 513 ) AGENT = sztemp.substring(0,512);
        else AGENT = sztemp;


        saz_dest[ILogConst.EB_REC_HEAD_AGENT] = AGENT;

        SIZE = "";
        COOKIE = saz_dest[ILogConst.EB_REC_HEAD_COOKIE];

        YMDHMS = saz_dest[ILogConst.EB_REC_HEAD_TIME];

        ANON = saz_dest[ILogConst.EB_REC_HEAD_GUID];


        USERID = saz_dest[ILogConst.EB_REC_HEAD_USER];

        SESSION = saz_dest[ILogConst.EB_REC_HEAD_SESSION];

        uri = saz_dest[ILogConst.EB_REC_HEAD_URI];

        method = saz_dest[ILogConst.EB_REC_HEAD_METHOD];

        serverHost = saz_dest[ILogConst.EB_REC_HEAD_SITE];
        return bret;

    }

}

