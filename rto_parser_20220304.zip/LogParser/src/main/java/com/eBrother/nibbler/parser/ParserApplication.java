package com.eBrother.nibbler.parser;

import com.fasterxml.jackson.core.JsonProcessingException;

public class ParserApplication {

	public static void main(String[] args) throws JsonProcessingException {

		ParserHelper helper = ParserHelper.getInstance();

		String data = "host_name=192.168.117.92      HTTP_CC_GUID=\"20090325163930c048120c00b0300000\" HTTP_CC_SESSION=\"20090325203855c048120c0091100017\" SERVER_HOST=\"www.hanabank.com\" SERVER_URL=\"/transfer/index.do\" \n" +				"REMOTE_ADDR=\"192.72.19.11\" REMOTE_USER=\"\" USER_AGENT=\"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; S" +
				"V1) ;  Embedded Web Browser from: http://bsalsa.com/; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648)\" HTTP_URI=\" \" HTTP_REF" +
				"ERER=\"http://59.11.68.10/transfer/index.do?menuItemId=wpdep414_02t\" HTTP_COOKIE=\"\" HTTP_METHOD=\"POST\" HTTP_TIME=\"20090325205005\" HTTP_QUERY=\"menuItemId=wpdep414_0" +
				"2t&acctNo=&contentUrl=/transfer/autotrans/wpdep414_02t.do\"";

		data = "host_name=192.168.117.92    HTTP_CC_GUID=\"20190427012319c0a8890f014af62960\" HTTP_CC_SESSION=\"20200531235822c0a8890b0080f3c06a\" SERVER_HOST=\"spib.wooribank.com\" SERVER_URL=\"/pib/Dream\" REMOTE_ADDR=\"221.141.184.58\" REMOTE_USER=\"\" USER_AGENT=\"Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko\" HTTP_URI=\" \" HTTP_REFERER=\"https://spib.wooribank.com/pib/Dream?withyou=PSTRS0008&__STEP=1\" HTTP_COOKIE=\"\" HTTP_METHOD=\"POST\" HTTP_TIME=\"20200601000048647\" HTTP_QUERY=\"ACT_PWNO=&AUTH_REASON=&CLNM_NO_ADD_SBJ=&CNTR_ACNO=&CNTR_AM=&CNTR_ICHE_YN=&CNTR_IST=&COST_CD=&COUNT_SUPPROT=0&COUNT_TRANS_FER=1&COUNT_TRANS_FER_RES=0&DOTCOM_MEMO_YN=N&FAVOR_ACCTNO_CHK=&FAVOR_EML=&FAVOR_HP_NO=&FEE=0&FEE_AM=0&FEXEM_YN=Y&FND_CAUTION_LMS=N&HP_NO=&HpNoAuth=N&IN_AMOUNT_13=5000&IN_BANK_CD_3=020&IN_CLIENT_NAME_22=이예슬&IS_CHD_MSG_TS=N&MEMBERS_ROW=1&MON_RENT_YN=&NRSD_6_1=&NRSD_6_2=&OWAC_FNM=강준석&PAYDACBR_3=&PAYDACCMOD_1=&PTN_PBOK_PRNG_TXT=강준석&P_RCVCNT=1&RCVDACBR_3=&RCV_ACNO=1002954451755&RCV_BKCD=020&RNPE_FNM=이예슬&RPS_PEN_YN=&RSTT_YN=&RSV_DT=20200531&TAX_CD=&TOTAL_CNT_2=1&TRAN_INFO=즉시이체/예약이체&TRN_AM=5000&TS_EXE_DT=20200531&TS_EXE_TM_DIS=&TS_GUBUN=1&WBF_DUP_CHECK_KEY=1062&WDR_ACNO=1005503365043&WDR_ACNO_MEMO=&WDR_ACNO_MEMO_GUBUN=&WDR_ACNO_TEXT=이예슬&WDR_ACNO_TEXT_MEMO=&WDR_NOTI_AMT_VIEW_YN=&WDR_NOTI_AUTO_YN=&WDR_NOTI_HP_NO1_12=&WDR_NOTI_INOT_SMS_FR_TM=&WDR_NOTI_INOT_SMS_TO_TM=&WDR_NOTI_MONEY_INOUT=&WDR_NOTI_REG=N&WDR_NOTI_SEND_AMT=&WDR_NOTI_SEND_AMT_SLT=&WDR_NOTI_WDR_ACCT=&WIBEE_MONEY_YN=&_INSIDE_NAT=&__STEP=2&authUsedPhoneNo=&lateTransDetail=&lateTransTimetxt=&transkeyUuid=undefined&transkey_i=1&transkey_inputs=Tk_PWNO_6:PWNO_6&withyou=PSTRS0008\"";

		String result = helper.parse2JsonWN( data );

		System.out.println ( result );
	}

}
