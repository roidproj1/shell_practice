package com.eBrother.nibbler.util;

import java.util.Hashtable;

public interface ICallBack {

    boolean run_Pre ();
    boolean run_Post ();
    boolean run_CallBack (String szline, Hashtable<String, Object> hparam);
    boolean run_CallBack (String szline );
    boolean run_CallBackFile (String szfile, String szline, Hashtable<String, Object> hparam);

}

