package com.woorifg.bigdata.rto.batch.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;
import java.util.Vector;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class SFTPClient {

	static {
		if(System.getProperty("log_name") == null) {
			  System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}
	
	private static final Logger log = LoggerFactory.getLogger(SFTPClient.class);

	private static final int BUFFER_LENGTH = 1024 * 1024;

	protected final String host;
	protected final int port;

	protected final String username;
	private final String passwd;
	private final String prvkeyPath;

	private Session session = null;
	private ChannelSftp channelSftp = null;

	public SFTPClient(String host, int port, String encUserName, String encPasswd, String prvkeyPath) {

		this.host = host;
		this.port = port;
		this.prvkeyPath = prvkeyPath;

		try {
			this.username = EncryptUtil.decrypt(encUserName, EncryptUtil.KEY);
			
			if (encPasswd != null)
				this.passwd = EncryptUtil.decrypt(encPasswd, EncryptUtil.KEY);
			else
				this.passwd = null;
		} catch (InvalidKeyException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (UnsupportedEncodingException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (NoSuchAlgorithmException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (NoSuchPaddingException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (InvalidAlgorithmParameterException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (IllegalBlockSizeException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		} catch (BadPaddingException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}
	}

	protected final void setSession(Session session) {
		this.session = session;
	}

	protected final void setChannelSftp(ChannelSftp channelSftp) {
		this.channelSftp = channelSftp;
	}

	public void connectWithUserPassword() {

		JSch jsch = new JSch();

		try {
			session = jsch.getSession(this.username, this.host, this.port);
			session.setPassword(this.passwd);

			Properties props = new Properties();
			props.put("StrictHostKeyChecking", "no");

			session.setConfig(props);

			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			this.channelSftp = (ChannelSftp) channel;
		} catch (JSchException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}

	}

	public void connectWithPrivateKey() {

		JSch jsch = new JSch();

		try {
			jsch.addIdentity(this.prvkeyPath);
			Session session = jsch.getSession(this.username, this.host, this.port);
			this.setSession(session);

			Properties props = new Properties();
			props.put("StrictHostKeyChecking", "no");

			session.setConfig(props);

			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();

			ChannelSftp channelSftp = (ChannelSftp) channel;
			this.setChannelSftp(channelSftp);
		} catch (JSchException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}

	}

	public String getHome() {
		try {
			return this.channelSftp.getHome();
		} catch (SftpException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}
	}

	public Vector<?> listFiles(String tgtPath) {
		try {
			Vector<?> filelist = this.channelSftp.ls(tgtPath);

			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				log.debug(entry.getFilename());
			}

			return filelist;
		} catch (SftpException ex) {
			log.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}
	}

	public boolean checkdir(String path) {

		SftpATTRS dStat = null;
		try {
			dStat = this.channelSftp.stat(path);
		} catch (SftpException ex) {
			log.debug(ex.getMessage(), ex);
		}
		if (dStat != null) {
			return true;
		} else {
			return false;
		}

	}

	public boolean mkdir(String path) {
		try {
			this.channelSftp.mkdir(path);
			return true;
		} catch (SftpException ex) {
			log.debug(ex.getMessage(), ex);
			return false;
		}
	}

	public boolean rm(String path) {
		try {
			this.channelSftp.rm(path);
			return true;
		} catch (SftpException ex) {
			log.debug(ex.getMessage(), ex);
			return false;
		}
	}

	public boolean rmdir(String path) {
		try {
			this.channelSftp.rmdir(path);
			return true;
		} catch (SftpException ex) {
			log.debug(ex.getMessage(), ex);
			return false;
		}
	}

	public long getFileSize(String path) {

		SftpATTRS dStat = null;

		try {
			dStat = this.channelSftp.stat(path);
		} catch (SftpException ex) {
			log.debug(ex.getMessage(), ex);
		}

		if (dStat != null) {
			return dStat.getSize();
		} else {
			throw new RuntimeException("FILE_NOT_EXIST");
		}

	}

	public void upload(String dir, String fileName, String localPath) {
		InputStream in = null;
		try {
			try {
				in = new BufferedInputStream(new FileInputStream(localPath));
			} catch (FileNotFoundException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}

			try {
				channelSftp.cd(dir);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
			try {
				channelSftp.put(in, fileName);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
		} finally {
			if (null != in)
				try {
					in.close();
				} catch (IOException ex) {
					;
				}
		}
	}
	
	public void uploadWithGrp(String dir, String fileName, String localPath, int grpId, int permssion) {
		InputStream in = null;
		try {
			try {
				in = new BufferedInputStream(new FileInputStream(localPath));
			} catch (FileNotFoundException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}

			try {
				channelSftp.cd(dir);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
			try {
				channelSftp.put(in, fileName);
				
				channelSftp.chmod(permssion, fileName);
				channelSftp.chgrp(grpId, fileName);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
		} finally {
			if (null != in)
				try {
					in.close();
				} catch (IOException ex) {
					;
				}
		}
	}	

	public void uploadConvertCharSet(String dir, String fileName, String localPath, String fCharSet)
			throws IOException {
		FileInputStream fis = null;
		InputStreamReader in = null;
		BufferedInputStream bis = null;

		try {
			try {

				fis = new FileInputStream(localPath);
				in = new InputStreamReader(fis, fCharSet);

				int rC;
				char[] buffer = new char[1024];
				try (ByteArrayOutputStream bais = new ByteArrayOutputStream()) {
					try (Writer writer = new OutputStreamWriter(bais, StandardCharsets.UTF_8)) {
						while ((rC = in.read(buffer, 0, buffer.length)) != -1) {
							writer.write(buffer, 0, rC);
						}
					}
					bis = new BufferedInputStream((new ByteArrayInputStream(bais.toByteArray())));
				}

			} catch (FileNotFoundException | UnsupportedEncodingException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			} finally {
				if (null != in)
					try {
						in.close();
					} catch (IOException ex) {
						;
					}
				if (null != fis)
					try {
						fis.close();
					} catch (IOException ex) {
						;
					}
			}

			try {
				channelSftp.cd(dir);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
			try {
				channelSftp.put(bis, fileName);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}
		} finally {
			if (null != in)
				try {
					in.close();
				} catch (IOException ex) {
					;
				}
		}
	}

	
	
	public void download(String dir, String fileName, String localPath) {
		byte[] buffer = new byte[BUFFER_LENGTH];
		
		try {
			channelSftp.cd(dir);
		} catch (SftpException ex) {
			log.error(ex.getMessage(), ex);

			throw new RuntimeException(ex);
		}

		InputStream in = null;
		OutputStream out = null;
		try {
			try {
				in = channelSftp.get(fileName);
			} catch (SftpException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}

			try {
				out = new BufferedOutputStream(new FileOutputStream(localPath));
			} catch (FileNotFoundException ex) {
				log.error(ex.getMessage(), ex);

				throw new RuntimeException(ex);
			}

			while (true) {
				int rlen = in.read(buffer);
				if (rlen < 0)
					break;
				out.write(buffer, 0, rlen);
			}
		} catch (IOException ex) {
			log.error(ex.getMessage(), ex);

			throw new RuntimeException(ex);
		} finally {
			if (null != out)
				try {
					out.flush();
				} catch (IOException ex) {
					;
				}
			if (null != out)
				try {
					out.close();
				} catch (IOException ex) {
					;
				}
			if (null != in)
				try {
					in.close();
				} catch (IOException ex) {
					;
				}
		}
	}

	public void disconnect() {
		if (null != this.channelSftp)
			this.channelSftp.disconnect();
		if (null != this.session)
			this.session.disconnect();
	}

	public static void mkdirs(SFTPClient sftp, String path) {
		String[] pathArr = StringUtil.explode(path, "/", true);
		StringBuilder strbuf = new StringBuilder();
		for (String dir : pathArr) {
			if (dir.equals("")) {
				strbuf.append('/');
				continue;
			}
			String absPath = strbuf.append(dir).toString();
			if (sftp.checkdir(absPath) == false)
				sftp.mkdir(absPath);
			strbuf.append('/');
		}
	}

}
