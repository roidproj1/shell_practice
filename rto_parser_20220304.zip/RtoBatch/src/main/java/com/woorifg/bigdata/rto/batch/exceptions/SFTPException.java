package com.woorifg.bigdata.rto.batch.exceptions;

public class SFTPException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1381670846373470270L;

	public SFTPException() {
		super();
	}

	public SFTPException(String message, Throwable cause) {
		super(message, cause);
	}

	public SFTPException(String message) {
		super(message);
	}

	public SFTPException(Throwable cause) {
		super(cause);
	}

}
