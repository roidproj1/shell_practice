package com.woorifg.bigdata.rto.batch.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;

import com.woorifg.bigdata.rto.batch.exceptions.JarException;

public class JarUtil {

	private static final int BUFFER_LEN = 1024 * 8; 	// 8KB

	public static List<String> getEntryList(String strJarPath) throws JarException {
		
		File fJar = new File(strJarPath);
		
		if (!fJar.exists()) {
			throw new JarException("[JAR_ER001] file not exist");
		}

		List<String> retList = new LinkedList<String>();
		JarFile objJarFile = null;
		
		try {
			
			try {
				objJarFile = new JarFile(fJar);
			} catch (IOException ex) { 		
				// 파일이 없거나, jar 파일이 아닌 경우 에러 발생
				throw new JarException("[JAR_ER002] non jar file", ex);
			}

			Enumeration<JarEntry> enums = objJarFile.entries();
			
			while (enums.hasMoreElements()) {
				JarEntry entry = (JarEntry) enums.nextElement();
				retList.add(entry.getName());
			}
			
		} finally {
			
			if (null != objJarFile) {
				
				try {
					objJarFile.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
				
			}
		}

		return null;
	}

	public static long zipJarFile(String[] src, String tgt) {

		byte[] buf = new byte[BUFFER_LEN];

		try {
			
			JarOutputStream out = new JarOutputStream(new FileOutputStream(tgt));

			for (int i = 0; i < src.length; i++) {

				FileInputStream in = new FileInputStream(src[i]);
				Path p = Paths.get(src[i]);

				String fileName = p.getFileName().toString();

				JarEntry je = new JarEntry(fileName);
				out.putNextEntry(je);

				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				out.closeEntry();
				in.close();
			}

			out.close();

			File ftmp = new File(tgt);
			return ftmp.length();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return 0;
	}

	/**
	 * jar 파일에서 해당 파일만 추출
	 * 
	 * @param strJarPath
	 * @param includeFilePath
	 * @param targetPath
	 * @throws JarFileUtilException
	 */
	public static void unzipJarForFile(String strJarPath, String entryPath, String targetPath) throws JarException {
		
		File fJar = new File(strJarPath);
		
		if (!fJar.exists()) {
			throw new JarException("[JAR_ER001] file not exist");
		}

		JarFile objJarFile = null;
		
		try {
			
			try {
				objJarFile = new JarFile(fJar);
			} catch (IOException ex) { 		// 파일이 없거나, jar 파일이 아닌 경우 에러 발생
				throw new JarException("[JAR_ER002] non jar file", ex);
			}

			JarEntry entry = (JarEntry) objJarFile.getEntry(entryPath);
			
			if (entry == null) {
				throw new JarException(String.format("[JAR_ER003] not exist %s", entryPath));
			}

			File targetFile = new File(targetPath);
			InputStream is = null;
			BufferedInputStream bis = null;
			BufferedOutputStream bos = null;
			FileOutputStream fos = null;

			try {
				
				is = objJarFile.getInputStream(entry);
				bis = new BufferedInputStream(is);
				fos = new FileOutputStream(targetFile);
				bos = new BufferedOutputStream(fos);

				byte[] buffer = new byte[BUFFER_LEN];

				while (true) {
					
					int rlen = bis.read(buffer);
					
					if (rlen < 0) 
						break;
					
					bos.write(buffer, 0, rlen);
				}
				
				fos.flush();
				
			} catch (IOException ex) {
				throw new JarException("[JAR_ER004] file extract exception", ex);
			} finally {
				if (bos != null) {
					try {
						bos.close();
					} catch (IOException ex) {
						;
					}
				}
				
				if (fos != null) {
					try {
						fos.close();
					} catch (IOException ex) {
						;
					}
				}

				if (bis != null) {
					try {
						bis.close();
					} catch (IOException ex) {
						;
					}
				}
				
				if (is != null) {
					try {
						is.close();
					} catch (IOException ex) {
						;
					}
				}
			}
		} finally {
			
			if (objJarFile != null) {
				
				try {
					objJarFile.close();
				} catch (IOException ex) {
					;
				}
				
			}
		}
	}

	public static void unzipJarFile(String strJarPath, String tgtPath) throws JarException {
		File fJar = new File(strJarPath);
		if (!fJar.exists())
			throw new JarException("[JAR_ER001] file not exist");

		JarFile objJarFile = null;
		try {
			try {
				objJarFile = new JarFile(fJar);
			} catch (IOException ex) { 		// 파일이 없거나, jar 파일이 아닌 경우 에러 발생
				throw new JarException("[JAR_ER002] non jar file", ex);
			}

			Enumeration<JarEntry> enumEntries = objJarFile.entries();

			InputStream is = null;
			BufferedInputStream bis = null;
			FileOutputStream fos = null;
			BufferedOutputStream bos = null;

			while (enumEntries.hasMoreElements()) {

				JarEntry je = (JarEntry) enumEntries.nextElement();
				File tgtFile = new File(tgtPath, je.getName());

				if(!tgtFile.exists()) {
					tgtFile.getParentFile().mkdirs();
					tgtFile = new File(tgtPath, je.getName());
				}
				
				if (tgtFile.isDirectory()) {
					tgtFile.mkdir();
					continue;
				}

				try {

					is = objJarFile.getInputStream(je);
					bis = new BufferedInputStream(is);
					fos = new FileOutputStream(tgtFile);
					bos = new BufferedOutputStream(fos);

					byte[] buffer = new byte[BUFFER_LEN];

					while (is.available() > 0) {
						int rlen = bis.read(buffer);
						if (rlen < 0)
							break;
						bos.write(buffer, 0, rlen);
					}

					fos.flush();

				} catch (IOException ex) {
					throw new JarException("[JAR_ER004] file extract exception", ex);
				} finally {
					if (null != bos)
						try {
							bos.close();
						} catch (IOException ex) {
							;
						}
					if (null != fos)
						try {
							fos.close();
						} catch (IOException ex) {
							;
						}

					if (null != bis)
						try {
							bis.close();
						} catch (IOException ex) {
							;
						}
					if (null != is)
						try {
							is.close();
						} catch (IOException ex) {
							;
						}
				}
			}
		} finally {
			if (null != objJarFile)
				try {
					objJarFile.close();
				} catch (IOException ex) {
					;
				}
		}
	}

	public static void main_old(String[] args) {
		String jarFilePath = args[0];
		String entryPath = args[1];
		String targetPath = args[2];

		try {
			JarUtil.unzipJarForFile(jarFilePath, entryPath, targetPath);
		} catch (JarException ex) {
			ex.printStackTrace(System.err);
			System.exit(1);
		}
	}

}
