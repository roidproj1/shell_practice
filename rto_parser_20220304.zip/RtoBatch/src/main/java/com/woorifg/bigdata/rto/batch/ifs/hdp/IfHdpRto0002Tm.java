package com.woorifg.bigdata.rto.batch.ifs.hdp;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.enums.ErrSftpBatch;
import com.woorifg.bigdata.rto.batch.parses.LogFileToMaster;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.StringUtil;

public class IfHdpRto0002Tm {

	static {
	  if(System.getProperty("log_name") == null) {
	      System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
	  }
	}
	
	private static final Logger log = LoggerFactory.getLogger(IfHdpRto0002Tm.class);

	private static final String IF_HDP_HEAD = "java -Dlog_base=${LOG_BASE} -Dlog_name=${LOG_NM} -cp ${LIB_PATH} ";
	private static final String IF_HDP_PROF = "-Dactive=[local|dev|test|prod] ";	
	
	private static final String clsNm = IfHdpRto0002Tm.class.getName();
	
	public static void main(String[] args) {

		// validation start
		String propf = null;
		
		if (System.getProperty("active") == null) {
			log.error(IF_HDP_PROF + " : active profile required !!!");
			System.err.println(IF_HDP_PROF + " : active profile required !!!");
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		
		if ("local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			log.error(IF_HDP_PROF + " : invalid active profile !!!");
			System.err.println(IF_HDP_PROF + " : invalid active profile !!!");			
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		
		if (args == null || args.length != 2 ) {
			log.error(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${OrgLogJsonFilePath} ${OutputFileNm}"));
			log.error(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=IfHdpRto0002Tm_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," /ecube/file/ifs/hdp/send/RTO0001TM_2022022513.json RTO0002TM_2022022513.json"));

			System.err.println(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${OrgLogJsonFilePath} ${OutputFileNm}"));
			System.err.println(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=IfHdpRto0002Tm_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," /ecube/file/ifs/hdp/send/RTO0001TM_2022022513.json RTO0002TM_2022022513.json"));
			
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
		}
		

		log.debug("{} start !!!", clsNm);
		log.debug("active profile : {} -- {}.properties", System.getProperty("active"), propf);		
		
		
		LogFileToMaster pobj = new LogFileToMaster();

		String SRC_PATH = args[0];
		File srcFile = new File(SRC_PATH);
		
		String TGT_PATH = StringUtil.concat(PropertiesUtil.getProperty(propf + ".properties").getProperty("if_hdp.sndpath"), args[1]);
		
		if(srcFile.exists()) {
			
			pobj.fileLogOrgToMstJsonFileImdg(SRC_PATH, TGT_PATH, true, true, true);
			
		} else {
			
			log.error("No original log file found !!!");
			
			System.err.println("No original log file found !!!");
			System.exit(ErrSftpBatch.NO_SEND_FILE.getVal());				
		}
		
		log.debug("{} end !!!", clsNm);

	}

}
