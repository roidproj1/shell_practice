package com.woorifg.bigdata.rto.batch.consts;

public class Consts {

	public static final String DEFAULT_LOG_NAME = "rto_batch_log";
	public static final String DEFAULT_CHARSET = "UTF-8";
	
	public static final int EXIT_ERR_NO_ACTIVE_PROFILE = 999;
	public static final int EXIT_ERR_INVALID_ARGS = 980;	
	public static final int EXIT_ERR_NO_DAMO_INI = 900;
	
}
