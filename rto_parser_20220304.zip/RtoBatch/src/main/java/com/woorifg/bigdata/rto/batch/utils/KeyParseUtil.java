package com.woorifg.bigdata.rto.batch.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.woorifg.bigdata.rto.batch.consts.Consts;

public class KeyParseUtil {

	static {
		if(System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
	}
	
	private static final Logger log = LoggerFactory.getLogger(KeyParseUtil.class);
	private static final int DEPTH_LIMIT = 5;
	
	public static LinkedHashMap<String, String> parseKeyValues(String jsonStr) {
		
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonKeyValues(keys, json, "", 1);	
		return keys;
		
	}
	
	
	private static LinkedHashMap<String, String> _getJsonKeyValues(LinkedHashMap<String, String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!"".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
			
			if(entry.getValue().isJsonArray()) {
				keys.put(hd + entry.getKey(), entry.getValue().toString());
			}

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.put(hd + entry.getKey(), entry.getValue().toString());
				_getJsonKeyValues(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.containsKey(hd + entry.getKey())) {
					try {
						keys.put(hd + entry.getKey(), entry.getValue().getAsString());
					} catch(Exception e) {
						log.error(entry.getKey());
					}
				}
			}
		}
		return keys;
	}
	
	
	
	public static List<String> parseJsonKeys(String jsonStr) {
		
		List<String> keys = new ArrayList<String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonKeys(keys, json, "", 1);	
		
		return keys;
		
	}	
	

	private static List<String> _getJsonKeys(List<String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!"".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.add(hd + entry.getKey());
				_getJsonKeys(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.contains(hd + entry.getKey())) {
					keys.add(hd + entry.getKey());
				}
			}
		}
		return keys;
	}
	
	
	
	public static List<String> parseJsonPathKeys(String jsonStr) {
		
		List<String> keys = new ArrayList<String>();
		
		Gson gs = new Gson();
		JsonElement el = gs.fromJson(jsonStr, JsonElement.class);
		
		JsonObject json = null;
		
		try {
			json = el.getAsJsonObject();
		} catch(IllegalStateException | NullPointerException e) {
			log.error(e.toString());
			return null;
		} 
		
		keys = _getJsonPathKeys(keys, json, ".", 1);	
		
		return keys;
		
	}

	private static List<String> _getJsonPathKeys(List<String> keys, JsonObject json, String hd, int depth) {
		
		if(json == null) {
			return null;
		}
		
		if(!".".equals(hd)) {
			hd = hd + ".";
		}

		for (Map.Entry<String, JsonElement> entry : json.entrySet()) {

			if (entry.getValue().isJsonObject() && depth < DEPTH_LIMIT) {
				keys.add(hd + entry.getKey());
				_getJsonPathKeys(keys, entry.getValue().getAsJsonObject(), hd + entry.getKey(), ++depth);
			} else {
				if(entry.getKey() != null && !"".equals(entry.getKey().trim()) && ! keys.contains(hd + entry.getKey())) {
					keys.add(hd + entry.getKey());
				}
			}
		}
		return keys;
	}
	
}
