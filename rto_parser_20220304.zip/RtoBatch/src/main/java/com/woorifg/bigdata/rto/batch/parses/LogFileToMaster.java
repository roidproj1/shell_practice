package com.woorifg.bigdata.rto.batch.parses;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.utils.DamoEncUtil;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.JsonUtil;
import com.woorifg.bigdata.rto.batch.utils.KeyParseUtil;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.StringUtil;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;

// Step 1. Log to Json
public class LogFileToMaster {

	private final static String ACTIVE_PROFILE_LIST = "local|dev|test|prod";
	
	private static final String CONN_STR;
	private static final String propf;
	
	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}

		if (System.getProperty("active") != null && ACTIVE_PROFILE_LIST.indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			propf = null;
			System.err.println(StringUtil.concat("No active profile !!!! : -Dactive=[", ACTIVE_PROFILE_LIST, "]"));
			System.exit(Consts.EXIT_ERR_NO_ACTIVE_PROFILE);
		}
		
		// IMDG Connection String
		if(System.getProperty("rto.imdg.thin.url") != null) {
			CONN_STR = System.getProperty("rto.imdg.thin.url");
		} else {
			CONN_STR = PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.thin.url");
		}
		
		if(CONN_STR == null || CONN_STR.trim().isEmpty()) {
			System.err.println("No rto.imdg.thin.url in properties [ IMDG URL ] or -Drto.imdg.thin.url=${IMDG conn str}");
			System.exit(Consts.EXIT_ERR_NO_DAMO_INI);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(LogFileToMaster.class);

	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";

//	private static final String SRC_TBL = "RTO0001TM";		// LOG ORG	
	private static final String MST_TBL = "RTO0002TM";		// MASTER

	// HttpQuery Parser
	// (_JSON_DATA=({.*}))|((accInfo[a-zA-Z]{3,4})=(\[.*\]))|((accInfo[a-zA-Z]{3,4})=({.*}))|(([_a-zA-Z0-9]+)=([^&]*))
	private static final String PTN_HTTP_QUERY = "(_JSON_DATA=(\\{.*\\}))|((accInfo[a-zA-Z]{3,4})=(\\[.*\\]))|((accInfo[a-zA-Z]{3,4})=(\\{.*\\}))|(([_a-zA-Z0-9]+)=([^&]*))";
	
	private static Pattern ptnHttpQuery = Pattern.compile(PTN_HTTP_QUERY);

	
	LinkedHashMap<String, Object> hm = new LinkedHashMap<String, Object>();
	
	public LogFileToMaster() {

		
		String hmCnfFileNm = PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.parse.http_query.entity.file");
		
		File src = new File(hmCnfFileNm);
		
		if(src.exists()) {
			
			int idxLn = 0;
			String rd_line = null;
			String[] tmpStrArr = null;
			
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
				
				while ((rd_line = br.readLine()) != null) {
					
					if(rd_line.trim().isEmpty())
						continue;
					
					idxLn++;
					
					tmpStrArr = rd_line.split("\\|");
					
					hm.put(tmpStrArr[0], tmpStrArr[1]);
					
				}
				
				
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				log.error("error : {} line -- {}", idxLn, e.getMessage());
				e.printStackTrace();
			}
			
		} else {
			System.err.println(StringUtil.concat("No Http_query parse config file !!!!"));
			System.exit(Consts.EXIT_ERR_NO_ACTIVE_PROFILE);
		}
	}
	
	// HttpQuery Parser
	public JsonObject parseLine(String src) {
		
		// 1: HTTP_QUERY Case --> 2: parseStepHttpQuery
		JsonObject rsltJson = new JsonObject();
		
		try {
		
			JsonObject tmpHttpQry = parseStepHttpQuery(src);
			
			if (tmpHttpQry == null) {
				rsltJson.addProperty("HTTP_QUERY", src);
			} else {
				rsltJson.add("HTTP_QUERY", tmpHttpQry);
			}
			
		} catch (Exception e) {
			
//			e.printStackTrace();
			rsltJson.addProperty("HTTP_QUERY", src);
			
			log.debug("HttpQuery toJson Error : {}", src);
		}
		
		return rsltJson.size() == 0 ? null : rsltJson;

	}

	// HttpQuery Parser
	private static JsonObject parseStepHttpQuery(String sHttpQry) throws Exception {

		Matcher mtch = ptnHttpQuery.matcher(sHttpQry);
		JsonObject rsltJson = new JsonObject();

		Gson gs = new Gson();

		// HttpQry Log
//		System.out.println(sHttpQry);
		while (mtch.find()) {

			// Step 1 --> 0
			if (mtch.group(0) != null) {

				// Step 2
				// _JSON_DATA
				if (mtch.group(1) != null) {

					// 1: _JSON_DATA Case --> 2
					// json case --> json converting
					try {
						rsltJson.add("_JSON_DATA", mtch.group(2) != null ? gs.fromJson(mtch.group(2), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : _JSON_DATA -- {}", mtch.group(2).toString());
						rsltJson.addProperty("_JSON_DATA", mtch.group(2).toString());
					}

				} else if (mtch.group(3) != null) {

					// 3: accInfoLst/Data Array Case --> 4, 5 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(4), mtch.group(5) != null ? gs.fromJson(mtch.group(5), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(4), mtch.group(5).toString());
						rsltJson.addProperty(mtch.group(4), mtch.group(5).toString());
					}

				} else if (mtch.group(6) != null) {

					// 6: accInfoLstData Json Case --> 7, 8 value
					// json case --> json converting
					try {
						rsltJson.add(mtch.group(7), mtch.group(8) != null ? gs.fromJson(mtch.group(8), JsonElement.class) : null);
					} catch (JsonSyntaxException e) {
						log.debug("Exception : {} -- {}", mtch.group(7), mtch.group(8).toString());
						rsltJson.addProperty(mtch.group(7), mtch.group(8).toString());
					}

				} else if (mtch.group(9) != null) { // 9 : Normal Case --> 10: key, 11: value

					// dup check
//					if(rsltJson.has(mtch.group(10).toString())) {
//						log.debug("DUP KEY !!! HttpQuery > {} : {} --> {}", mtch.group(10).toString(), rsltJson.get(mtch.group(10).toString()), mtch.group(11).toString());
//					}

					rsltJson.addProperty(mtch.group(10).toString(), mtch.group(11).toString());
				}
			}
		}

		return rsltJson.size() == 0 ? null : rsltJson;
	}	

	// RTOParseLogic Util
	private String getJsonValue(JsonElement jel, String key) {
		
		if(jel != null) {
			if( jel.getAsJsonObject().get(key) != null 
					&& !jel.getAsJsonObject().get(key).getAsString().trim().isEmpty()
			) {
				return jel.getAsJsonObject().get(key).getAsString();
			}
		}
		return null;
		
	}
	
	public void fileLogOrgToMstJsonFile(final String SRC_PATH, final String TGT_PATH, final boolean enc, final boolean bincJsonAcnt) {

		StopWatch swch = new StopWatch("fileLogOrgToMstJsonFile");
		swch.start();
		
		File src = new File(SRC_PATH);
		
		Gson gs = new Gson();

		JsonObject json = null;
		JsonObject jsonHtpQry = null;
		
		long idxLn = 0L;
		
		
		String tmpVal = null;
		
		if (src.exists()) {
			
			idxLn = 0L;
			
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
				
//				File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + "_mst.json");
				File wrFile = new File(TGT_PATH);
				
				try(OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET)) {
				
					String rd_line = null;
					
					LinkedHashMap<String, String> tm = null;
					
					String sReferer;
					String htpQryDummy;
					
					String sId, sCc, sPlmPdcd, sPrdCd;
					String eventNo, psnzChnlKey, psnzAreaKey, psnzScnrKey, psnzCtnsKey, psnzTgtKey;
					String cmdCd, qrBrCd, sQrAdvpeNo, sQr_advpe_no;
					String inbkSearchText, smtbkSearchText;
					String withyou, step;
					String acno, htpAcno, bkcd, htpBkcd, inqAcNo, htpInqAcno, wdrBkcd, htpWdrBkcd, wdrAcNo, htpWdrAcno;
					
					JsonObject jsonHtpQryParses;
					JsonObject jsonAdds;
					JsonObject jtmp;
					
					List<String> forEnc = null;
					List<String> forMask = null;
					
					String encStr, maskStr;		
					
					String tmpStrArr[];
					String rsltStr;
	
					
					while ((rd_line = br.readLine()) != null
	//						&& idxLn < 2
							) {
						
						idxLn++;
						
						json = gs.fromJson(rd_line, JsonObject.class);
						
						/*** 	json 추가 구역  	***/
						// host_ip_addr
						json.addProperty("HOST_IP_ADDR", ParseCase.parseString(json.get("REMOTE_ADDR")));
						
						// host_domain
						json.addProperty("HOST_DOMAIN", ParseCase.parseString(json.get("SERVER_HOST"), "([a-zA-Z0-9_]*)\\.wooribank\\.com"));
						
						// parseHttpTime
						json = ParseCase.parseHttpTime(json, ParseCase.parseString(json.get("HTTP_TIME")));
						
						// parseRemoteUser
						json = ParseCase.parseRemoteUser(json, ParseCase.parseString(json.get("REMOTE_USER")));					
						
						// parseUserAgent
						json = ParseCase.parseUserAgent(json, ParseCase.parseString(json.get("USER_AGENT")));
						
						// http parsing
						// http_query 존재 유무 체크
						sReferer = null;
						
						if( json.get("HTTP_REFERER") != null && !json.get("HTTP_REFERER").getAsString().trim().isEmpty() ) {
							sReferer = json.get("HTTP_REFERER").getAsString();
						}
						
						if(forEnc != null) {
							forEnc.clear();
							forEnc = null;
						}
						
						if(forMask != null) {
							forMask.clear();
							forMask = null;
						}
						
						// http_query_json_dummy
						if( json.get("HTTP_QUERY") != null ) {
							
								jsonHtpQry = parseLine(ParseCase.parseString(json.get("HTTP_QUERY")));
	//							log.debug("jsonHtpQry : {}", jsonHtpQry);
								
							if(jsonHtpQry != null) {
								
								htpQryDummy = gs.toJson(jsonHtpQry.get("HTTP_QUERY"));
								json.addProperty("HTTP_QUERY_JSON_DUMMY", htpQryDummy);
								
								if(tm != null) {
									tm.clear();
									tm = null;
								}
								
								try {
									
									tm = KeyParseUtil.parseKeyValues(htpQryDummy);
									
								} catch(Exception e) {
									
									log.debug("error {} ln : {} ", idxLn, htpQryDummy);
									continue;
								}
								
	//							log.debug("{}",KeyParseUtil.parseJsonPathKeys(htpQryDummy));
	//							log.debug("{}", tm);
								
								jsonHtpQryParses = new JsonObject(); 
								
								forEnc = new ArrayList<String>();
								forMask = new ArrayList<String>();
								
								for(String t : tm.keySet()) {
	
	//								System.out.println(t);
									
									if(hm.containsKey(t)) {
										
	//									log.debug("{} = {}, {}", t, tm.get(t), hm.get(t));
	
										tmpStrArr = hm.get(t).toString().split(";");
										
										jsonHtpQryParses.addProperty(tmpStrArr[0], tm.get(t));
										
										// move or dump
										switch(tmpStrArr[1]) {
										
										case "d":
										case "m":
											jsonHtpQryParses.addProperty(tmpStrArr[0], tm.get(t));
											break;										
										
										default:
											
										}									
										
										// enc, mask, full_mask
										switch(tmpStrArr[2]) {
										
										case "e":
											forEnc.add(tmpStrArr[0]);
											break;
	
										case "k":
										case "f":
											forMask.add(tmpStrArr[0]);
											break;										
										
										default:
											
										}
									}
								}
								
								// merge
								// json , jsonHtpQryParses , jsonAdds 
	//							log.debug(jsonHtpQryParses.toString());
								
								jsonAdds = new JsonObject();
								
								
	//							CPNT_ID				// HTTP_QUERY.__ID or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
								sId = getJsonValue(jsonHtpQryParses, "HTP_QRY_ID");
								
								tmpVal = ParseCase.parseCpntId(sId, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("CPNT_ID", tmpVal);
								}
								
	//							CPNT_CN_INFO		// HTTP_QUERY.cc or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
								sCc = getJsonValue(jsonHtpQryParses, "HTP_QRY_CC");
								tmpVal = ParseCase.parseCpntCnInfo(sCc, sReferer);
								if(tmpVal != null) {							
									jsonAdds.addProperty("CPNT_CN_INFO", tmpVal);
								}
								
	//							PLM_PDCD			// HTTP_QUERY.PLM_PDCD 단순 파싱 
								sPlmPdcd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PLM_PDCD");
								tmpVal = ParseCase.parsePlmPdcd(sPlmPdcd);
								if(tmpVal != null) {
									jsonAdds.addProperty("PLM_PDCD", tmpVal);
								}
								
	//							PRD_CD				// HTTP_QUERY.PRD_CD or HTTP_REFERER에서 추출
								sPrdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PRD_CD");
								tmpVal = ParseCase.parsePrdCd(sPrdCd, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("PRD_CD", tmpVal);
								}
								
	//							EVENT_NO			// HTTP_QUERY.no 단순 파싱
								eventNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_NO");
								tmpVal = ParseCase.parseEventNo(eventNo);
								if(tmpVal != null) {
									jsonAdds.addProperty("EVENT_NO", tmpVal);
								}
	
	//							PSNZ_CHNL_KEY		// HTTP_QUERY.m 단순 파싱
								psnzChnlKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_M");
								tmpVal = ParseCase.parsePsnzChnlKey(psnzChnlKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_CHNL_KEY", tmpVal);
								}
								
								
	//							PSNZ_AREA_KEY		// HTTP_QUERY.z 단순 파싱
								psnzAreaKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_Z");
								tmpVal = ParseCase.parsePsnzAreaKey(psnzAreaKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_AREA_KEY", tmpVal);
								}
								
								
	//							PSNZ_SCNR_KEY		// HTTP_QUERY.s 단순 move
								psnzScnrKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_S");
								if(psnzScnrKey != null) {
									jsonAdds.addProperty("PSNZ_SCNR_KEY", psnzScnrKey);
								}
								
								
	//							PSNZ_CTNS_KEY		// HTTP_QUERY.c 단순 파싱
								psnzCtnsKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_C");
								tmpVal = ParseCase.parsePsnzCtnsKey(psnzCtnsKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_CTNS_KEY", tmpVal);
								}
	
								
	//							PSNZ_TGT_KEY		// HTTP_QUERY.t 단순 파싱
								psnzTgtKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_T");
								tmpVal = ParseCase.parsePsnzTgtKey(psnzTgtKey);
								if(tmpVal != null) {
									jsonAdds.addProperty("PSNZ_TGT_KEY", tmpVal);
								}
								
								
	//							CMD_CD				// HTTP_QUERY.cmd 단순 파싱
								cmdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_CMD");
								tmpVal = ParseCase.parseCmdCd(cmdCd);
								if(tmpVal != null) {
									jsonAdds.addProperty("CMD_CD", tmpVal);
								}
								
								
	//							QR_BR_CD			// HTTP_QUERY.qrBrCd 단순 파싱
								qrBrCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRBRCD");
								tmpVal = ParseCase.parseQrBrCd(qrBrCd);
								if(tmpVal != null) {
									jsonAdds.addProperty("QR_BR_CD", tmpVal);
								}
								
								
	//							QR_ADVPE_NO			// HTTP_QUERY.qrAdvpeNo 단순 파싱
								sQrAdvpeNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRADVPENO");
								sQr_advpe_no = getJsonValue(jsonHtpQryParses, "HTP_QRY_QR_ADVPE_NO");
								tmpVal = ParseCase.parseQrAdvpeNo(sQrAdvpeNo, sQr_advpe_no);
								if(tmpVal != null) {
									jsonAdds.addProperty("QR_ADVPE_NO", tmpVal);
								}
								
								
	//							INBK_SEARCH_TEXT	// HTTP_QUERY.query 단순 move	
								inbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_QUERY");
								if(inbkSearchText != null) {
									jsonAdds.addProperty("INBK_SEARCH_TEXT", inbkSearchText);
								}
								
								
	//							SMTBK_SEARCH_TEXT	// HTTP_QUERY.searchText 단순 move
								smtbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_SEARCHTEXT"); 
								if(smtbkSearchText != null) {
									jsonAdds.addProperty("SMTBK_SEARCH_TEXT", smtbkSearchText);
								}
								
								
	//							SEARCH_TEXT			// HTTP_QUERY.query or HTTP_QUERY.searchText 에서 추출 단순 파싱
								tmpVal = ParseCase.parseSearchText(inbkSearchText, smtbkSearchText);
								if(tmpVal != null) {
									jsonAdds.addProperty("SEARCH_TEXT", tmpVal);
								}
								
								
								
	//							PAGE_ID				// HTTP_QUERY.withyou or HTTP_REFERER에서 추출 - 복합 파싱 
								withyou = getJsonValue(jsonHtpQryParses, "HTP_QRY_WITHYOU");
								tmpVal = ParseCase.parsePageId(withyou, sReferer);
								if(tmpVal != null) {
									jsonAdds.addProperty("PAGE_ID", tmpVal);
								}
								
								
	//							PAGE_STEP_ORDER		// HTTP_QUERY.__STEP or HTTP_REFERER에서 추출 - 복합 파싱, psnz_chnl_key == 30002 --> psnz_scnr_key
								step = getJsonValue(jsonHtpQryParses, "HTP_QRY___STEP"); 
								
								if("30002".equals(psnzChnlKey)) {
									tmpVal = ParseCase.parsePageStepOrder(sReferer, psnzScnrKey, step);
									if(tmpVal != null) {
										jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
									}
								} else {
									tmpVal = ParseCase.parsePageStepOrder(sReferer, step);
									if(tmpVal != null) {
										jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
									}
								}
								
	
	//							log.debug("jsonAdds :  {}", jsonAdds.toString());							
								
								if(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA") != null
										&& jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA") != null
										&& !jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA").isJsonNull()
										) {
									
									
									if(bincJsonAcnt) {
										// acno : .HTTP_QUERY.ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.ACNO	+ 암호화	
										acno = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "ACNO"); 
										htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
										tmpVal = ParseCase.parseAcno(acno, htpAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("ACNO", tmpVal);
											forEnc.add("ACNO");
										}
										
		
										//	bkcd : .HTTP_QUERY.BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.BKCD
										bkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "BKCD");
										htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
										tmpVal = ParseCase.parseBkcd(bkcd, htpBkcd);
										if(tmpVal != null) {
											jsonAdds.addProperty("BKCD", tmpVal);
										}
		
										
										//	inq_acno : .HTTP_QUERY.INQ_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.INQ_ACNO + 암호화 	
										inqAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "INQ_ACNO");
										htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
										tmpVal = ParseCase.parseInqAcno(inqAcNo, htpInqAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("INQ_ACNO", tmpVal);
											forEnc.add("INQ_ACNO");
										}
										
										
										// wdr_bkcd : .HTTP_QUERY.WDR_BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_BKCD
										wdrBkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_BKCD");
										htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
										tmpVal = ParseCase.parseWdrBkcd(wdrBkcd, htpWdrBkcd);
										if(tmpVal != null) {
											jsonAdds.addProperty("WDR_BKCD", tmpVal);
										}
									
										
										// wdr_acno : .HTTP_QUERY.WDR_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_ACNO + 암호화	
										wdrAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_ACNO");
										htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
										tmpVal = ParseCase.parseInqAcno(wdrAcNo, htpWdrAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("WDR_ACNO", tmpVal);
											forEnc.add("WDR_ACNO");
										}
									}
									
								} else {
									
									if(bincJsonAcnt) {									
										htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
										tmpVal = ParseCase.parseAcno(htpAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("ACNO", tmpVal);
											forEnc.add("ACNO");
										}
										
										htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
										tmpVal = ParseCase.parseBkcd(htpBkcd);
										if(tmpVal != null) {
											jsonAdds.addProperty("BKCD", tmpVal);
										}
										
										htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
										tmpVal = ParseCase.parseInqAcno(htpInqAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("INQ_ACNO", tmpVal);
											forEnc.add("INQ_ACNO");
										}
										
										htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
										tmpVal = ParseCase.parseWdrBkcd(htpWdrBkcd);
										if(tmpVal != null) {
											jsonAdds.addProperty("WDR_BKCD", tmpVal);
										}
		
										htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
										tmpVal = ParseCase.parseInqAcno(htpWdrAcno);
										if(tmpVal != null) {
											jsonAdds.addProperty("WDR_ACNO", tmpVal);
											forEnc.add("WDR_ACNO");								
										}
									}
								}
								
								forEnc.add("HTTP_QUERY");
								forEnc.add("HTTP_QUERY_JSON_DUMMY");
								
								json = JsonUtil.merge(json, jsonAdds, jsonHtpQryParses);
									
							} else { // jsonHtpQry가 null 일 경우 ( json화 가능한 포맷이 아니라서 파싱이 되지 않는 경우 )
								
								json.add("HTTP_QUERY_JSON_DUMMY", null);
								
	//							cpnt_id				// HTTP_REFERER에서 __ID 추출
								tmpVal = ParseCase.parseCpntId(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("CPNT_ID", tmpVal);
								}
								
	//							cpnt_cn_info		// HTTP_REFERER에서 cc 추출
								tmpVal = ParseCase.parseCpntCnInfo(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("CPNT_CN_INFO", tmpVal);
								}
								
	//							prd_cd				// HTTP_REFERER에서 PRD_CD 추출
								tmpVal = ParseCase.parsePrdCd(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("PRD_CD", tmpVal);
								}
								
								
	//							page_id				// HTTP_REFERER에서 withyou 추출 - 복합 파싱
								tmpVal = ParseCase.parsePageId(null, sReferer);
								if(tmpVal != null) {
									json.addProperty("PAGE_ID", tmpVal);
								}
								
	//							page_step_order		// HTTP_REFERER에서 __STEP 추출 - 복합 파싱
								tmpVal = ParseCase.parsePageStepOrder(sReferer, "" );
								if(tmpVal != null) {
									json.addProperty("PAGE_STEP_ORDER", tmpVal);
								}
								
	//							log.debug("json : {}", json.toString());							
								
							}
								
						}
						
	//					log.debug("forEnc : {}", forEnc != null ? forEnc.toString() : null);
	//					log.debug("forMask : {}", forMask != null ? forMask.toString() : null);
	
						// 처리한 내역 file write
						
						rsltStr = gs.toJson(json) + "\n";
						owr.write(rsltStr);
						
						jtmp = json;
						
						if(enc && json != null) {
							
							if( forEnc != null && !forEnc.isEmpty() ) {
								for(String enckey : forEnc ) {
									
	//								log.debug("enckey {} -- {}",enckey, json.get(enckey));
									
									if(jtmp.get(enckey) != null 
											&& !jtmp.get(enckey).isJsonNull()
											&& !jtmp.get(enckey).getAsString().trim().isEmpty()
									) {
										encStr = DamoEncUtil.data_encryption(jtmp.get(enckey).getAsString(), "string");
										jtmp.addProperty(enckey, encStr);
									}
									
								}
							}
							
							if( forMask != null && !forMask.isEmpty() ) {
								
								for(String maskkey : forEnc ) {
								
									if(jtmp.get(maskkey) != null
											&& !jtmp.get(maskkey).isJsonNull()
											&& !jtmp.get(maskkey).getAsString().trim().isEmpty()
									) {
	//									maskStr = jtmp.get(maskkey).getAsString().replaceAll(".", "*");
										maskStr = "*****";
	//									log.debug(maskStr);					
										jtmp.addProperty(maskkey, maskStr);
									}
								}
							}						
						}
					}
				
					owr.close();
					br.close();
				
				} catch (UnsupportedEncodingException e) {
					log.error("{}", e.getMessage());
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					log.error("{}", e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					log.error("{}", e.getMessage());
					e.printStackTrace();
				}
				
			} catch (UnsupportedEncodingException e) {
				log.error("{}", e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				log.error("{}", e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				log.error("{} line -- {}", idxLn, e.getMessage());
				e.printStackTrace();
			}
			
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}			
	
	

	// 향후 keys 받는 외부 함수로 인자 변경 처리
	public void fileLogOrgToMstJsonFileImdg(final String SRC_PATH, final String TGT_PATH, final boolean enc, final boolean bincJsonAcnt, final boolean bfileOut) {

		StopWatch swch = new StopWatch("fileLogOrgToMstJsonFileImdg");
		swch.start();
		
		File src = new File(SRC_PATH);
		
		Gson gs = new Gson();
		JsonObject json = null;
		JsonObject jsonHtpQry = null;
		
		long idxLn = 0L;
		
		String tmpVal = null;
		
		if (src.exists()) {
			
			idxLn = 0L;
			
			try (Connection conn = DriverManager.getConnection(CONN_STR)) {
				
	            try (Statement stmt = conn.createStatement()) {
	                stmt.executeUpdate("SET STREAMING ON");
	            }			
			
				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(src), IN_CHARSET))) {
					
//					File wrFile = new File(TGT_PATH + FilenameUtils.getBaseName(src.getName()) + "_mst.json");
					File wrFile = new File(TGT_PATH);
						
					try(OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET)) {
						
						String rd_line = null;
						
						
						LinkedHashMap<String, String> tm = null;
						
						String sReferer;
						String htpQryDummy;
						
						String sId, sCc, sPlmPdcd, sPrdCd;
						String eventNo, psnzChnlKey, psnzAreaKey, psnzScnrKey, psnzCtnsKey, psnzTgtKey;
						String cmdCd, qrBrCd, sQrAdvpeNo, sQr_advpe_no;
						String inbkSearchText, smtbkSearchText;
						String withyou, step;
						String acno, htpAcno, bkcd, htpBkcd, inqAcNo, htpInqAcno, wdrBkcd, htpWdrBkcd, wdrAcNo, htpWdrAcno;
						
						JsonObject jsonHtpQryParses;
						JsonObject jsonAdds;
						JsonObject jtmp;
						
						List<String> forEnc = null;
						List<String> forMask = null;
						
						String encStr, maskStr;		
						
						String tmpStrArr[];
						String rsltStr;	
						
						int idx = 1;
						
						String jsonVo;
						ResultVo rs;
						
						String tgtTbl;
						
						if(PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.hdp.schema") != null) {
							tgtTbl = StringUtil.concat(PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.hdp.schema"), ".", MST_TBL);
						} else {
							tgtTbl = MST_TBL;
						}	
						
						
						while ((rd_line = br.readLine()) != null
								
//								&& idxLn < 5
								
								) {
							
							idxLn++;
							
//							if(
//								idxLn != 67304
//							) {
//								continue;
//							} 
							
							json = gs.fromJson(rd_line, JsonObject.class);
							
							
							/*** 	json 추가 구역  	***/
							
							// host_ip_addr
							json.addProperty("HOST_IP_ADDR", ParseCase.parseString(json.get("REMOTE_ADDR")));
							
							// host_domain
							json.addProperty("HOST_DOMAIN", ParseCase.parseString(json.get("SERVER_HOST"), "([a-zA-Z0-9_]*)\\.wooribank\\.com"));
							
							// parseHttpTime
							json = ParseCase.parseHttpTime(json, ParseCase.parseString(json.get("HTTP_TIME")));
							
							// parseRemoteUser
							json = ParseCase.parseRemoteUser(json, ParseCase.parseString(json.get("REMOTE_USER")));					
							
							// parseUserAgent
							json = ParseCase.parseUserAgent(json, ParseCase.parseString(json.get("USER_AGENT")));		
							
							
							// http parsing
							// http_query 존재 유무 체크
							
							sReferer = null; 
							if( json.get("HTTP_REFERER") != null && !json.get("HTTP_REFERER").getAsString().trim().isEmpty() ) {
								sReferer = json.get("HTTP_REFERER").getAsString();
							}
							
							if(forEnc != null) {
								forEnc.clear();
								forEnc = null;
							}
							
							if(forMask != null) {
								forMask.clear();
								forMask = null;
							}
							
							// http_query_json_dummy
							if( json.get("HTTP_QUERY") != null ) {
								
									jsonHtpQry = parseLine(ParseCase.parseString(json.get("HTTP_QUERY")));
		//							log.debug("jsonHtpQry : {}", jsonHtpQry);
									
								if(jsonHtpQry != null) {
									
									htpQryDummy = gs.toJson(jsonHtpQry.get("HTTP_QUERY"));
									
									json.addProperty("HTTP_QUERY_JSON_DUMMY", htpQryDummy);
									
									if(tm != null) {
										tm.clear();
										tm = null;
									}
									
									try {
										tm = KeyParseUtil.parseKeyValues(htpQryDummy);
									} catch(Exception e) {
										log.debug("error {} ln : {} ", idxLn, htpQryDummy);
										
										continue;
									}
									
		//							log.debug("{}",KeyParseUtil.parseJsonPathKeys(htpQryDummy));
		//							log.debug("{}", tm);
									
									jsonHtpQryParses = new JsonObject(); 
									
									forEnc = new ArrayList<String>();
									forMask = new ArrayList<String>();
									
									for(String t : tm.keySet()) {
										
		//								System.out.println(t);
										
										if(hm.containsKey(t)) {
		//									log.debug("{} = {}, {}", t, tm.get(t), hm.get(t));
		
											tmpStrArr = hm.get(t).toString().split(";");
											
											jsonHtpQryParses.addProperty(tmpStrArr[0], tm.get(t));
											
											// move or dump
											switch(tmpStrArr[1]) {
											
											case "d":
											case "m":
												jsonHtpQryParses.addProperty(tmpStrArr[0], tm.get(t));
												break;										
											
											default:
												
											}									
											
											// enc, mask, full_mask
											switch(tmpStrArr[2]) {
											
											case "e":
												forEnc.add(tmpStrArr[0]);
												break;
		
											case "k":
											case "f":
												forMask.add(tmpStrArr[0]);
												break;										
											
											default:
												
											}
										}
									}
									
	
									// merge
									// json , jsonHtpQryParses , jsonAdds 
		//							log.debug(jsonHtpQryParses.toString());
	
									jsonAdds = new JsonObject();
									
									
		//							CPNT_ID				// HTTP_QUERY.__ID or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
									sId = getJsonValue(jsonHtpQryParses, "HTP_QRY_ID");
									
									tmpVal = ParseCase.parseCpntId(sId, sReferer);
									if(tmpVal != null) {
										jsonAdds.addProperty("CPNT_ID", tmpVal);
									}
									
		//							CPNT_CN_INFO		// HTTP_QUERY.cc or HTTP_REFERER에서 추출 , http_query내 존재 유무 체크 후 추출 로직
									sCc = getJsonValue(jsonHtpQryParses, "HTP_QRY_CC");
									tmpVal = ParseCase.parseCpntCnInfo(sCc, sReferer);
									if(tmpVal != null) {							
										jsonAdds.addProperty("CPNT_CN_INFO", tmpVal);
									}
									
		//							PLM_PDCD			// HTTP_QUERY.PLM_PDCD 단순 파싱 
									sPlmPdcd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PLM_PDCD");
									tmpVal = ParseCase.parsePlmPdcd(sPlmPdcd);
									if(tmpVal != null) {
										jsonAdds.addProperty("PLM_PDCD", tmpVal);
									}
									
		//							PRD_CD				// HTTP_QUERY.PRD_CD or HTTP_REFERER에서 추출
									sPrdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_PRD_CD");
									tmpVal = ParseCase.parsePrdCd(sPrdCd, sReferer);
									if(tmpVal != null) {
										jsonAdds.addProperty("PRD_CD", tmpVal);
									}
									
		//							EVENT_NO			// HTTP_QUERY.no 단순 파싱
									eventNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_NO");
									tmpVal = ParseCase.parseEventNo(eventNo);
									if(tmpVal != null) {
										jsonAdds.addProperty("EVENT_NO", tmpVal);
									}
		
		//							PSNZ_CHNL_KEY		// HTTP_QUERY.m 단순 파싱
									psnzChnlKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_M");
									tmpVal = ParseCase.parsePsnzChnlKey(psnzChnlKey);
									if(tmpVal != null) {
										jsonAdds.addProperty("PSNZ_CHNL_KEY", tmpVal);
									}
									
									
		//							PSNZ_AREA_KEY		// HTTP_QUERY.z 단순 파싱
									psnzAreaKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_Z");
									tmpVal = ParseCase.parsePsnzAreaKey(psnzAreaKey);
									if(tmpVal != null) {
										jsonAdds.addProperty("PSNZ_AREA_KEY", tmpVal);
									}
									
									
		//							PSNZ_SCNR_KEY		// HTTP_QUERY.s 단순 move
									psnzScnrKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_S");
									if(psnzScnrKey != null) {
										jsonAdds.addProperty("PSNZ_SCNR_KEY", psnzScnrKey);
									}
									
									
		//							PSNZ_CTNS_KEY		// HTTP_QUERY.c 단순 파싱
									psnzCtnsKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_C");
									tmpVal = ParseCase.parsePsnzCtnsKey(psnzCtnsKey);
									if(tmpVal != null) {
										jsonAdds.addProperty("PSNZ_CTNS_KEY", tmpVal);
									}
		
									
		//							PSNZ_TGT_KEY		// HTTP_QUERY.t 단순 파싱
									psnzTgtKey = getJsonValue(jsonHtpQryParses, "HTP_QRY_T");
									tmpVal = ParseCase.parsePsnzTgtKey(psnzTgtKey);
									if(tmpVal != null) {
										jsonAdds.addProperty("PSNZ_TGT_KEY", tmpVal);
									}
									
									
		//							CMD_CD				// HTTP_QUERY.cmd 단순 파싱
									cmdCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_CMD");
									tmpVal = ParseCase.parseCmdCd(cmdCd);
									if(tmpVal != null) {
										jsonAdds.addProperty("CMD_CD", tmpVal);
									}
									
									
		//							QR_BR_CD			// HTTP_QUERY.qrBrCd 단순 파싱
									qrBrCd = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRBRCD");
									tmpVal = ParseCase.parseQrBrCd(qrBrCd);
									if(tmpVal != null) {
										jsonAdds.addProperty("QR_BR_CD", tmpVal);
									}
									
									
		//							QR_ADVPE_NO			// HTTP_QUERY.qrAdvpeNo 단순 파싱
									sQrAdvpeNo = getJsonValue(jsonHtpQryParses, "HTP_QRY_QRADVPENO");
									sQr_advpe_no = getJsonValue(jsonHtpQryParses, "HTP_QRY_QR_ADVPE_NO");
									tmpVal = ParseCase.parseQrAdvpeNo(sQrAdvpeNo, sQr_advpe_no);
									if(tmpVal != null) {
										jsonAdds.addProperty("QR_ADVPE_NO", tmpVal);
									}
									
									
		//							INBK_SEARCH_TEXT	// HTTP_QUERY.query 단순 move	
									inbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_QUERY");
									if(inbkSearchText != null) {
										jsonAdds.addProperty("INBK_SEARCH_TEXT", inbkSearchText);
									}
									
									
		//							SMTBK_SEARCH_TEXT	// HTTP_QUERY.searchText 단순 move
									smtbkSearchText = getJsonValue(jsonHtpQryParses, "HTP_QRY_SEARCHTEXT"); 
									if(smtbkSearchText != null) {
										jsonAdds.addProperty("SMTBK_SEARCH_TEXT", smtbkSearchText);
									}
									
									
		//							SEARCH_TEXT			// HTTP_QUERY.query or HTTP_QUERY.searchText 에서 추출 단순 파싱
									tmpVal = ParseCase.parseSearchText(inbkSearchText, smtbkSearchText);
									if(tmpVal != null) {
										jsonAdds.addProperty("SEARCH_TEXT", tmpVal);
									}
									
									
									
		//							PAGE_ID				// HTTP_QUERY.withyou or HTTP_REFERER에서 추출 - 복합 파싱 
									withyou = getJsonValue(jsonHtpQryParses, "HTP_QRY_WITHYOU");
									
//									log.debug("withyou : {}", withyou);
//									log.debug("sReferer : {}", sReferer);
									
									tmpVal = ParseCase.parsePageId(withyou, sReferer);
									if(tmpVal != null) {
										jsonAdds.addProperty("PAGE_ID", tmpVal);
									}
									
									
		//							PAGE_STEP_ORDER		// HTTP_QUERY.__STEP or HTTP_REFERER에서 추출 - 복합 파싱, psnz_chnl_key == 30002 --> psnz_scnr_key
									step = getJsonValue(jsonHtpQryParses, "HTP_QRY___STEP"); 
									
									if("30002".equals(psnzChnlKey)) {
										tmpVal = ParseCase.parsePageStepOrder(sReferer, psnzScnrKey, step);
										if(tmpVal != null) {
											jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
										}
									} else {
										tmpVal = ParseCase.parsePageStepOrder(sReferer, step);
										if(tmpVal != null) {
											jsonAdds.addProperty("PAGE_STEP_ORDER", tmpVal);
										}
									}
									
		
		//							log.debug("jsonAdds :  {}", jsonAdds.toString());							
									
									if(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA") != null
											&& jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA") != null
											&& !jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA").isJsonNull()
											) {
										
										if(bincJsonAcnt) {	
										
											// acno : .HTTP_QUERY.ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.ACNO	+ 암호화	
											acno = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "ACNO"); 
											htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
											tmpVal = ParseCase.parseAcno(acno, htpAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("ACNO", tmpVal);
												forEnc.add("ACNO");
											}
											
			
											//	bkcd : .HTTP_QUERY.BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.BKCD
											bkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "BKCD");
											htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
											tmpVal = ParseCase.parseBkcd(bkcd, htpBkcd);
											if(tmpVal != null) {
												jsonAdds.addProperty("BKCD", tmpVal);
											}
			
											
											//	inq_acno : .HTTP_QUERY.INQ_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.INQ_ACNO + 암호화 	
											inqAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "INQ_ACNO");
											htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
											tmpVal = ParseCase.parseInqAcno(inqAcNo, htpInqAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("INQ_ACNO", tmpVal);
												forEnc.add("INQ_ACNO");
											}
											
											
											// wdr_bkcd : .HTTP_QUERY.WDR_BKCD , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_BKCD
											wdrBkcd = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_BKCD");
											htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
											tmpVal = ParseCase.parseWdrBkcd(wdrBkcd, htpWdrBkcd);
											if(tmpVal != null) {
												jsonAdds.addProperty("WDR_BKCD", tmpVal);
											}
										
											
											// wdr_acno : .HTTP_QUERY.WDR_ACNO , .HTTP_QUERY._JSON_DATA._REQ_DATA.WDR_ACNO + 암호화	
											wdrAcNo = getJsonValue(jsonHtpQry.get("HTTP_QUERY").getAsJsonObject().get("_JSON_DATA").getAsJsonObject().get("_REQ_DATA"), "WDR_ACNO");
											htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
											tmpVal = ParseCase.parseInqAcno(wdrAcNo, htpWdrAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("WDR_ACNO", tmpVal);
												forEnc.add("WDR_ACNO");
											}
										}
										
									} else {
										
										if(bincJsonAcnt) {	
											
											htpAcno = getJsonValue(jsonHtpQryParses, "HTP_QRY_ACNO");
											tmpVal = ParseCase.parseAcno(htpAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("ACNO", tmpVal);
												forEnc.add("ACNO");
											}
											
											htpBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_BKCD");
											tmpVal = ParseCase.parseBkcd(htpBkcd);
											if(tmpVal != null) {
												jsonAdds.addProperty("BKCD", tmpVal);
											}
											
											htpInqAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_INQ_ACNO");
											tmpVal = ParseCase.parseInqAcno(htpInqAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("INQ_ACNO", tmpVal);
												forEnc.add("INQ_ACNO");
											}
											
											htpWdrBkcd =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_BKCD");
											tmpVal = ParseCase.parseWdrBkcd(htpWdrBkcd);
											if(tmpVal != null) {
												jsonAdds.addProperty("WDR_BKCD", tmpVal);
											}
			
											htpWdrAcno =  getJsonValue(jsonHtpQryParses, "HTP_QRY_WDR_ACNO");
											tmpVal = ParseCase.parseInqAcno(htpWdrAcno);
											if(tmpVal != null) {
												jsonAdds.addProperty("WDR_ACNO", tmpVal);
												forEnc.add("WDR_ACNO");								
											}
										}
									}
									
									forEnc.add("HTTP_QUERY");
									forEnc.add("HTTP_QUERY_JSON_DUMMY");
									
									json = JsonUtil.merge(json, jsonAdds, jsonHtpQryParses);
									
								} else { 
									
									// jsonHtpQry가 null 일 경우 ( json화 가능한 포맷이 아니라서 파싱이 되지 않는 경우 )
									
									json.add("HTTP_QUERY_JSON_DUMMY", null);
									
		//							cpnt_id				// HTTP_REFERER에서 __ID 추출
									tmpVal = ParseCase.parseCpntId(null, sReferer);
									if(tmpVal != null) {
										json.addProperty("CPNT_ID", tmpVal);
									}
									
		//							cpnt_cn_info		// HTTP_REFERER에서 cc 추출
									tmpVal = ParseCase.parseCpntCnInfo(null, sReferer);
									if(tmpVal != null) {
										json.addProperty("CPNT_CN_INFO", tmpVal);
									}
									
		//							prd_cd				// HTTP_REFERER에서 PRD_CD 추출
									tmpVal = ParseCase.parsePrdCd(null, sReferer);
									if(tmpVal != null) {
										json.addProperty("PRD_CD", tmpVal);
									}
									
									
		//							page_id				// HTTP_REFERER에서 withyou 추출 - 복합 파싱
									tmpVal = ParseCase.parsePageId(null, sReferer);
									if(tmpVal != null) {
										json.addProperty("PAGE_ID", tmpVal);
									}
									
		//							page_step_order		// HTTP_REFERER에서 __STEP 추출 - 복합 파싱
									tmpVal = ParseCase.parsePageStepOrder(sReferer, "" );
									if(tmpVal != null) {
										json.addProperty("PAGE_STEP_ORDER", tmpVal);
									}
									
		//							log.debug("json : {}", json.toString());							
								}
									
							}
		
		//					log.debug("forEnc : {}", forEnc != null ? forEnc.toString() : null);
		//					log.debug("forMask : {}", forMask != null ? forMask.toString() : null);
							
							// 처리한 내역 file write
							
							rsltStr = gs.toJson(json) + "\n";
							
							if(bfileOut) {
								owr.write(rsltStr);
							}
							
							jtmp = json;
							
							if(enc && json != null) {
								
								if( forEnc != null && !forEnc.isEmpty() ) {
									for(String enckey : forEnc ) {
										
	//									log.debug("enckey {} -- {}",enckey, json.get(enckey));
										if(jtmp.get(enckey) != null 
												&& !jtmp.get(enckey).isJsonNull()
												&& !jtmp.get(enckey).getAsString().trim().isEmpty()
										) {
											encStr = DamoEncUtil.data_encryption(jtmp.get(enckey).getAsString(), "string");
											jtmp.addProperty(enckey, encStr);
										}
										
									}
								}
								
								if( forMask != null && !forMask.isEmpty() ) {
									
									for(String maskkey : forEnc ) {
									
										if(jtmp.get(maskkey) != null
												&& !jtmp.get(maskkey).isJsonNull()
												&& !jtmp.get(maskkey).getAsString().trim().isEmpty()
										) {
	//										maskStr = jtmp.get(maskkey).getAsString().replaceAll(".", "*");
											maskStr = "*****";
	//										log.debug(maskStr);					
											jtmp.addProperty(maskkey, maskStr);
										}
									}
								}						
							}
							
							
							jsonVo = gs.toJson(json);
							
							rs = IMDGUtil.makeInsertQryFromVo(jsonVo, tgtTbl);
							
	//						log.debug(rs.getQuery());
							
							try(PreparedStatement pstmt = conn.prepareStatement(rs.getQuery())) {
								
								idx = 1;
								for(String val : rs.getArgs()) {
									pstmt.setString(idx++, val);				
								}
							
								pstmt.executeUpdate();
//								pstmt.addBatch();
							}
						}
						
						owr.close();
						br.close();
						
						if(!bfileOut) {
							wrFile.delete();
						}
						
					} catch (UnsupportedEncodingException e) {
						log.error("{}", e.getMessage());
						e.printStackTrace();
					} catch (FileNotFoundException e) {
						log.error("{}", e.getMessage());
						e.printStackTrace();
					} catch (IOException e) {
						log.error("{}", e.getMessage());
						e.printStackTrace();
					}
					
				} catch (UnsupportedEncodingException e) {
					log.error("{}", e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					log.error("{}", e.getMessage());
					e.printStackTrace();
				} catch (Exception e) {
					log.error("{} line -- {}", idxLn, e.getMessage());
					e.printStackTrace();
				}
				
	            try (Statement stmt = conn.createStatement()) {
	                stmt.executeUpdate("SET STREAMING OFF");
	            }
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}

		swch.stop();
		log.debug("sec : {}s", swch.getTotalTimeSeconds());
	}		

	public static void main(String[] args) {

//		LogFileToMaster obj = new LogFileToMaster();

//		obj.fileLogOrgToMstJsonFile(
//			"/Proj/files/log_org.json",
//			"/Proj/files/log_org_mst.json",
//			true,
//			false
//		);			
		
//		obj.fileLogOrgToMstJsonFileImdg(
//			"/Proj/files/log_org.json",
//			"/Proj/files/log_org_mst.json",
//			true,
//			false,
//			true
//		);

	}
}
