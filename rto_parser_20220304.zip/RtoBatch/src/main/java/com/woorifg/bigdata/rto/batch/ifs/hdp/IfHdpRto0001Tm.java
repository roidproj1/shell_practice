package com.woorifg.bigdata.rto.batch.ifs.hdp;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.enums.ErrSftpBatch;
import com.woorifg.bigdata.rto.batch.parses.LogImdgdbToFile;
import com.woorifg.bigdata.rto.batch.utils.DateUtil;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.StringUtil;

public class IfHdpRto0001Tm {

	static {
	  if(System.getProperty("log_name") == null) {
	      System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
	  }
	}
	
	private static final Logger log = LoggerFactory.getLogger(IfHdpRto0001Tm.class);

	private static final String IF_HDP_HEAD = "java -Dlog_base=${LOG_BASE} -Dlog_name=${LOG_NM} -cp ${LIB_PATH} ";
	private static final String IF_HDP_PROF = "-Dactive=[local|dev|test|prod] ";	
	
	private static final String clsNm = IfHdpRto0001Tm.class.getName();
	
	public static void main(String[] args) {

		// validation start
		String propf = null;
		
		if (System.getProperty("active") == null) {
			log.error(IF_HDP_PROF + " : active profile required !!!");
			System.err.println(IF_HDP_PROF + " : active profile required !!!");
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		
		if ("local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			log.error(IF_HDP_PROF + " : invalid active profile !!!");
			System.err.println(IF_HDP_PROF + " : invalid active profile !!!");			
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}

		
		if (args == null || ( args.length != 2 && args.length != 3 )) {
			log.error(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${sendFileNm} [${oTime}|${sFrom} ${sTo}]"));
			log.error(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=IfHdpRto0001Tm_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," RTO0001TM_2022022513.json [${oTime:yyyymmddHH}|${sFrom} ${sTo}]"));

			System.err.println(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${sendFileNm} [${oTime}|${sFrom} ${sTo}]"));
			System.err.println(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=IfHdpRto0001Tm_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," ${sendFileNm} [${oTime}|${sFrom} ${sTo}]"));
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
		}
		

		log.debug("{} start !!!", clsNm);
		log.debug("active profile : {} -- {}.properties", System.getProperty("active"), propf);		
		
		
		LogImdgdbToFile pobj = new LogImdgdbToFile();

		String TGT_PATH = StringUtil.concat(PropertiesUtil.getProperty(propf + ".properties").getProperty("if_hdp.sndpath"), args[0]);
		
		String sFrom = null;
		String sTo = null;
		
		try {
			if(args.length == 2) {
				
				// yyyyMMdd
				if(args[1].length() == 8) {
					
					sFrom = DateUtil.getDayFrom(args[1]);
					sTo = DateUtil.getDayTo(args[1]);
					
				// yyyyMMddHH
				} else if(args[1].length() == 10) {
					
					sFrom = DateUtil.getHourFrom(args[1]);
					sTo = DateUtil.getHourTo(args[1]);
					
				}
				
			} else {

				// from ~ to ~
				sFrom = DateUtil.makeYyyyMMddHHmmssSSS(args[1]);
				sTo = DateUtil.makeYyyyMMddHHmmssSSS(args[2]);
				
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
			
			log.error("param error : date parse error !!!");
			log.error(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=IfHdpRto0001Tm_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," ${sendFileNm} [${oTime:yyyymmddHH}|${sFrom} ${sTo}]"));
			
			System.err.println("param error : date parse error !!!");
			System.err.println(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${sendFileNm} [${oTime}|${sFrom} ${sTo}]"));
			
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
		}
		
		pobj.imdgRto0001TmToFileJson(TGT_PATH, sFrom, sTo);
		
		log.debug("{} end !!!", clsNm);

	}

}
