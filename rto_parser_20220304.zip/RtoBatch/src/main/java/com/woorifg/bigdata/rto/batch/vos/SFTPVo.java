package com.woorifg.bigdata.rto.batch.vos;

import org.apache.commons.io.FilenameUtils;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SFTPVo {
	
	private String ip;
	private Integer port;
	private String username;
	private String password;
	private String pKey;

	private String srcFile;
	private String srcFileTimeStamp; 		//yyyyMMddhhmmss
	
	private Long srcfileLine;
	
	private long srcFileSize;
	private long srcFileJarSize;
	
	private String tgtFilePath;
	private Integer tgtGrpId;
	
	public String getSrcFileName() {
		return FilenameUtils.getName(this.srcFile);
	}
	
	public String getTgtFileName() {
		return FilenameUtils.getName(this.srcFile) + ".jar";
	}
	
	public String getTgtFinName() {
		return FilenameUtils.getName(this.srcFile) + ".jar.fin";
	}

}
