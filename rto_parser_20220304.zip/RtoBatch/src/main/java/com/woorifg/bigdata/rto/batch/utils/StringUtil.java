package com.woorifg.bigdata.rto.batch.utils;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

public class StringUtil {

	public static String concat(String... args) {
		
		if(args == null) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i<args.length; i++) {
			sb.append(args[i]);
		}
		
		return sb.toString();
		
	}
	
	
	public static boolean isNumeric(String str) {
		return _isValid(str, "[0-9]+");
	}
	
	private static boolean _isValid(String str, String regex) {
		
		if (str == null) {
			return false;
		}
		
		return Pattern.matches(regex, str);
	}

	public static String toCsvFormatLine(String str, String delim) {
		String[] cols = explode(str, delim, true);
		return toCsvFormatByStringArr(cols);
	}

	public static String[] explode(String str, String delim, boolean isTrim) {
		int delimLength = delim.length();

		List<String> list = new LinkedList<String>();

		int sidx = 0;
		int eidx = 0;

		while (true) {
			eidx = str.indexOf(delim, sidx);
			String col = _substring(str, sidx, eidx, isTrim);
			list.add(col);

			if (eidx == -1) {
				break;
			}

			sidx = eidx + delimLength;
		}

		return list.toArray(new String[list.size()]);
	}

	private static String _substring(String str, int sidx, int eidx, boolean isTrim) {
		
		String retval;

		if (eidx < 0) {
			retval = str.substring(sidx);
		} else {
			retval = str.substring(sidx, eidx);
		}

		if (isTrim) {
			return retval.trim();
		} else {
			return retval;
		}
	}

	public static String toCsvFormatByStringArr(String[] strings) {

		StringBuilder sb = new StringBuilder();

		for (String str : strings) {
			
			// line 배열의 첫 번째 문자열이 아닌 경우에만 ","을 찍는다.
			if (sb.length() != 0) {
				sb.append(',');
			}

			// 문자열이 빈 값이면 ""을, 숫자면 숫자를, 그 외에는 ""를 포함하여 넣는다.
			if (str == null) {
				sb.append("");
			} else if (StringUtil.isNumeric(str)) {
				sb.append(str);
			} else {
				sb.append('"').append(escape(str)).append('"');
			}
			
		}
		
		return sb.toString();
	}

	private static String escape(String str) {

		if (str == null) {
			return "";
		}

		return str.replaceAll("\r", "").replaceAll("\n", " ").replaceAll("\\\\", "\\\\\\\\").replaceAll("\"", "\\\\\"");
	}

	public static String changeFileExt(String fileName, String newExt) {
		int idx = fileName.lastIndexOf('.');
		
		if (idx < 0) {
			return fileName;
		}

		return String.format("%s.%s", fileName.substring(0, idx), newExt);
	}
}
