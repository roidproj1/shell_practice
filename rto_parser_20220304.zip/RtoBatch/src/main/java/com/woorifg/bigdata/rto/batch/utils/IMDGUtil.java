package com.woorifg.bigdata.rto.batch.utils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.woorifg.bigdata.rto.batch.vos.ResultVo;

public class IMDGUtil {


	public static String makeDeleteQryFromTblCols(final String tblNm, final String colNm, final String sFrom, final String sTo) {

		if(
			(tblNm == null || tblNm.trim().isEmpty()) ||
			(colNm == null || colNm.trim().isEmpty()) ||
			(sFrom == null || sFrom.trim().isEmpty()) ||
			(sTo == null || sTo.trim().isEmpty())
		) {
			return null;
		}
		
		StringBuilder rsltQry = new StringBuilder();
		
		final String QRY_DEL_HD_1 = "DELETE FROM ";
		final String QRY_DEL_WHERE = " WHERE ";
		
		rsltQry.append(QRY_DEL_HD_1)
			.append(tblNm)
			.append(QRY_DEL_WHERE)
			.append(colNm).append(" >= '").append(sFrom).append("'")
			.append(" AND ").append(colNm).append(" < '").append(sTo).append("'")
		;
		
		return rsltQry.toString();

	}	
	
	public static String makeSelectQryFromStrArr(String[] keys, String tblNm) {

		final String QRY_SEL_HD_1 = "SELECT ";
		final String QRY_SEL_TL_1 = " FROM "; 
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		
		qryKey.setLength(0);
		
		for(String key : keys) {
			
			if(qryKey.length() != 0) {
				qryKey.append(", ");	
			}
			
			qryKey.append(key);
		}
		
		rsltQry.append(QRY_SEL_HD_1)
			.append(qryKey.toString())
			.append(QRY_SEL_TL_1)
			.append(tblNm)
		;
		
		return rsltQry.toString();

	}

	public static ResultVo makeInsertQryFromVo(String jsonVo, String tblNm) {

		ResultVo rslt = new ResultVo();  
		
		final String QRY_INS_HD_1 = "INSERT INTO ";
		final String QRY_INS_HD_2 = " ( "; 
		final String QRY_INS_MD_1 = " ) VALUES ( "; 
		final String QRY_INS_TL_1 = " )";
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		StringBuilder qryValue = new StringBuilder();
		
		Gson gs = new Gson();
		
		Type voMapType = new TypeToken<TreeMap<String, String>>(){}.getType();
		
		TreeMap<String, String> mp = gs.fromJson(jsonVo, voMapType);
		
		qryKey.setLength(0);
		List<String> tmpArg = new ArrayList<String>(); 
		
		for(String key : mp.keySet()) {
			
			if(qryKey.length()!=0) {
				qryKey.append(", ");	
				qryValue.append(", ");
			}
			
			qryKey.append(key);
			qryValue.append("?");
			
			tmpArg.add(mp.get(key));
			
		}
		
		rsltQry.append(QRY_INS_HD_1)
			.append(tblNm)
			.append(QRY_INS_HD_2)
			.append(qryKey.toString())
			.append(QRY_INS_MD_1)
			.append(qryValue.toString())
			.append(QRY_INS_TL_1)
		;	
		
		rslt.setArgs(tmpArg);
		rslt.setQuery(rsltQry.toString());
		
		return rslt;

	}
	
	public static ResultVo makeInsertQryFromVo(String jsonVo, String schemaNm, String tblNm) {

		ResultVo rslt = new ResultVo();  
		
		final String QRY_INS_HD_1 = "INSERT INTO ";
		final String QRY_INS_HD_2 = " ( "; 
		final String QRY_INS_MD_1 = " ) VALUES ( "; 
		final String QRY_INS_TL_1 = " )";
		
		StringBuilder rsltQry = new StringBuilder();
		
		StringBuilder qryKey = new StringBuilder();
		StringBuilder qryValue = new StringBuilder();
		
		Gson gs = new Gson();
		
		Type voMapType = new TypeToken<TreeMap<String, String>>(){}.getType();
		
		TreeMap<String, String> mp = gs.fromJson(jsonVo, voMapType);
		
		
		qryKey.setLength(0);
		List<String> tmpArg = new ArrayList<String>(); 
		
		for(String key : mp.keySet()) {
			
			if(qryKey.length()!=0) {
				qryKey.append(", ");	
				qryValue.append(", ");
			}
			
			qryKey.append(key);
			qryValue.append("?");
			
			tmpArg.add(mp.get(key));
			
		}
		
		rsltQry.append(QRY_INS_HD_1)
			.append(schemaNm)
			.append(".")
			.append(tblNm)
			.append(QRY_INS_HD_2)
			.append(qryKey.toString())
			.append(QRY_INS_MD_1)
			.append(qryValue.toString())
			.append(QRY_INS_TL_1)
		;	
		
		rslt.setArgs(tmpArg);
		rslt.setQuery(rsltQry.toString());
		
		return rslt;

	}	
	
	public static void main(String[] args) {
		
//		String json = "{\"aaa\":\"bbb\"}";
//		
//		ResultVo vo = makeInsertQryFromVo(json, "test");
//		
//		System.out.println(vo);
		
	}

}
