package com.woorifg.bigdata.rto.batch.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

public class DateUtil {

	public static String getCurrentDateWithPattern(String pattern) {
		return new SimpleDateFormat(pattern).format(new Date());
	}
	
	
	public static String getNow() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}

	public static String getLogAggrDatetime() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
	
	public static String getDayFrom(String src) throws ParseException {

		if(src == null || src.length() != 8 ) {
			throw new ParseException(src, 0);
		}
		
		// yyyyMMdd
		return makeYyyyMMddHHmmssSSS(src);
	}	

	public static String getDayTo(String src) throws ParseException {
		// yyyyMMdd
		return makeYyyyMMddHHmmssSSS(plusOneDay(src));
	}
	
	public static String getHourFrom(String src) throws ParseException {
		
		if(src == null || src.length() != 10 ) {
			throw new ParseException(src, 0);
		}
		
		// yyyyMMddHH
		return makeYyyyMMddHHmmssSSS(src);
	}	

	public static String getHourTo(String src) throws ParseException {
		// yyyyMMddHH
		return makeYyyyMMddHHmmssSSS(plusOneHour(src));
	}	
	
	public static String getHour30(String src) throws ParseException {
		// yyyyMMddHH
		return makeYyyyMMddHHmmssSSS(plus30Mins(src));
	}		
	
	
	public static String makeYyyyMMddHHmmssSSS(String src) {
		
		String yyyyMMddHHmmssSSS = "00000000000000000";
		
		if(src != null) {
			
			if(src.length() > 17) {
				return src;
			} else {
				return src + yyyyMMddHHmmssSSS.substring(src.length());
			}
			
		} else {
			return null;
		}
	}
	
	public static String minusOneDay(String src) throws ParseException {
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
		return yyyyMMdd.format(addDay(DateUtils.parseDate(src, "yyyyMMdd"), -1));
	}
	
	public static String plusOneDay(String src) throws ParseException {
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
		return yyyyMMdd.format(addDay(DateUtils.parseDate(src, "yyyyMMdd"), 1));
	}
	
	public static Date addDay(Date src, int days) {
		return DateUtils.addDays(src, days);
	}	
	
	
	public static String minusOneHour(String src) throws ParseException {
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMddHH");
		return yyyyMMdd.format(addHour(DateUtils.parseDate(src, "yyyyMMddHH"), -1));
	}
	
	public static String plusOneHour(String src) throws ParseException {
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMddHH");
		return yyyyMMdd.format(addHour(DateUtils.parseDate(src, "yyyyMMddHH"), 1));
	}
	
	public static Date addHour(Date src, int hours) {
		return DateUtils.addHours(src, hours);
	}
	
	
	public static String plusMins(String src, int mins) throws ParseException {
		SimpleDateFormat yyyyMMddHHmm = new SimpleDateFormat("yyyyMMddHHmm");
		return yyyyMMddHHmm.format(addMins(DateUtils.parseDate(src, "yyyyMMddHH"), mins));
	}	
	
	public static String plus30Mins(String src) throws ParseException {
		SimpleDateFormat yyyyMMddHHmm = new SimpleDateFormat("yyyyMMddHHmm");
		return yyyyMMddHHmm.format(addMins(DateUtils.parseDate(src, "yyyyMMddHH"), 30));
	}
	
	public static Date addMins(Date src, int mins) {
		return DateUtils.addMinutes(src, mins);
	}	
	
	public static void main(String[] args) throws ParseException {
		
//		System.out.println(minusOneDay("20220224"));
//		System.out.println(minusOneHour("2022022400"));
		
		System.out.println(getDayFrom("20220228"));
		System.out.println(getDayTo("20220228"));
		
		System.out.println(getHourFrom("2022022823"));
		System.out.println(getHourTo("2022022823"));		
		System.out.println(getHour30("2022022823"));
		
		System.out.println(makeYyyyMMddHHmmssSSS("202202282330"));
		

	}

}
