package com.woorifg.bigdata.rto.batch.exceptions;

public class JarException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6874405803530883655L;

	public JarException() {
		super();
	}

	public JarException(String message, Throwable cause) {
		super(message, cause);
	}

	public JarException(String message) {
		super(message);
	}

	public JarException(Throwable cause) {
		super(cause);
	}

}
