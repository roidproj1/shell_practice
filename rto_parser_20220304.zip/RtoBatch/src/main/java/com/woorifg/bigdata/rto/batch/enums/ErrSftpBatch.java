package com.woorifg.bigdata.rto.batch.enums;

public enum ErrSftpBatch {

	PROFILE_NULL(101),
	ARGS_ERROR(102),
	NO_SEND_FILE(201),
	TRNS_SIZE_ERROR(601),
	FIN_FILE_ERROR(801),
	ETC(999),
	;
	
	private final int value;
	
	private ErrSftpBatch(int value) {
		this.value = value;
	}

	public int getVal() {
		return value;
	}
	
}
