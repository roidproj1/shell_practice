package com.woorifg.bigdata.rto.batch.ifs.hdp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.enums.ErrSftpBatch;
import com.woorifg.bigdata.rto.batch.utils.JarUtil;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.SFTPClient;
import com.woorifg.bigdata.rto.batch.vos.SFTPVo;

public class IfHdpSender {

	static {
	  if(System.getProperty("log_name") == null) {
	      System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
	  }
	}
	
	private static final Logger log = LoggerFactory.getLogger(IfHdpSender.class);

	public static void main(String[] args) {

		final int PERMISSION = 0660;
		
		// validation start
		String propf = null;
		
		if (System.getProperty("active") == null) {
			log.error("-Dactive=[local|dev|test|prod] : active profile required !!!");
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}

		
		if ("local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			log.error("-Dactive=[local|dev|test|prod] : invalid active profile !!!");
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		

		// java -Dlog_name=${LOG_NM} -Dactive=${local|dev|tst|prd} -cp ${LIB_PATH} com.woorifg.bigdata.rto.batch.ifs.hadoop.IfHdpStep02 ${sendFileNm} ${yyyyMMddHHmmss} ${line}
		if (args.length != 3) {
			log.error(
					"param: java -Dlog_name=${LOG_NM} -Dactive=[local|dev|test|prod] -cp ${LIB_PATH} com.woorifg.bigdata.rto.batch.ifs.hadoop.IfHdpStep02 ${sendFileNm} ${yyyyMMddHHmmss} ${line}");
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
		}
		

		log.debug("{} start !!!", IfHdpSender.class.getName());
		log.debug("active profile : {} -- {}.properties", System.getProperty("active"), propf);		
		
		File srcFile = new File(args[0]);

		
		if (!srcFile.exists()) {
			log.error("SendFile not exist !!");
			System.exit(ErrSftpBatch.NO_SEND_FILE.getVal());
		}
		// validation end

		 try {
			// propertyUtil
			Properties property = PropertiesUtil.getProperty(propf + ".properties");
			
			SFTPVo sftpVo = SFTPVo.builder()
						.ip(property.getProperty("if_hdp.ip"))
						.port(Integer.parseInt(property.getProperty("if_hdp.port")))
						.username(property.getProperty("if_hdp.username"))
						.password(property.getProperty("if_hdp.password"))
						.pKey(property.getProperty("if_hdp.pkey"))
						.srcFile(args[0])
						.srcFileTimeStamp(args[1])
						.srcfileLine(Long.parseLong(args[2]))
						.srcFileSize(srcFile.length())
						.tgtFilePath(property.getProperty("if_hdp.tgtpath"))
						.tgtGrpId(Integer.parseInt(property.getProperty("if_hdp.tgt_grpid")))
						.build();
			
			// make jar
			String[] tmpFileArr = { args[0] };
			sftpVo.setSrcFileJarSize(JarUtil.zipJarFile(tmpFileArr, args[0] + ".jar"));
			
			// sftp 
			SFTPClient sftpCl = null;
	
			try {
				// sFTP 전송
				if ("local".equals(propf)) {
					// String host, int port, String encUserName, String encPasswd, String pKeyPath
					sftpCl = new SFTPClient(sftpVo.getIp(), sftpVo.getPort(), sftpVo.getUsername(), sftpVo.getPassword(), null);
	
					sftpCl.connectWithUserPassword();
				} else {
					// String host, int port, String encUserName, String encPasswd, String pKeyPath
					sftpCl = new SFTPClient(sftpVo.getIp(), sftpVo.getPort(), sftpVo.getUsername(), null, sftpVo.getPKey());
	
					sftpCl.connectWithPrivateKey();
				}
	
				SFTPClient.mkdirs(sftpCl, sftpVo.getTgtFilePath());
				
				// upload(tgtPath, tgtFilename, srcFullPath)
				if ("local".equals(propf)) {
					sftpCl.upload(sftpVo.getTgtFilePath(), sftpVo.getTgtFileName(), sftpVo.getSrcFile() + ".jar");
				} else {
					sftpCl.uploadWithGrp(sftpVo.getTgtFilePath(), sftpVo.getTgtFileName(), sftpVo.getSrcFile() + ".jar", sftpVo.getTgtGrpId(), PERMISSION);
				}
				
				long tgtFileSize = sftpCl.getFileSize(sftpVo.getTgtFilePath() + sftpVo.getTgtFileName());
				
				if(sftpVo.getSrcFileJarSize() !=  tgtFileSize) {
					
					log.error("FILE_SIZE_ERROR:{} ({}/{})", sftpVo.getSrcFile() + ".jar", tgtFileSize, sftpVo.getSrcFileJarSize());

					System.exit(ErrSftpBatch.TRNS_SIZE_ERROR.getVal());
					
				} else {
					log.debug("SEND FILE_SIZE:{} ({}/{})", sftpVo.getSrcFile() + ".jar", tgtFileSize, sftpVo.getSrcFileJarSize());
					
					// makeFin
					
					File finFile = new File(sftpVo.getSrcFile() + ".jar.fin");
					
					StringBuffer sb = new StringBuffer();
					
					sb.append(sftpVo.getSrcFileName()).append(",")
						.append(sftpVo.getSrcFileTimeStamp()).append(",")
						.append(sftpVo.getSrcfileLine()).append(",")
						.append(sftpVo.getSrcFileSize());
					
					try(BufferedWriter bwr = new BufferedWriter(new FileWriter(finFile))) {
						
						bwr.write(sb.toString());
						bwr.close();
						
					} catch(IOException e) {
						
						log.error("Create Fin File Error !!");
						
						e.printStackTrace();
						System.exit(ErrSftpBatch.FIN_FILE_ERROR.getVal());
						
					}
					
					// sendFin
					if ("local".equals(propf)) {
						sftpCl.upload(sftpVo.getTgtFilePath(), sftpVo.getTgtFinName(), sftpVo.getSrcFile() + ".jar.fin");
					} else {
						sftpCl.uploadWithGrp(sftpVo.getTgtFilePath(), sftpVo.getTgtFinName(), sftpVo.getSrcFile() + ".jar.fin", sftpVo.getTgtGrpId(), PERMISSION);
					}					
				
				}
	
			} catch (Throwable eth) {
				
				eth.printStackTrace(System.err);
				
				if (sftpCl != null) {
					sftpCl.disconnect();
				}
				
			} finally {
				
				if (sftpCl != null) {
					sftpCl.disconnect();
				}
				
			}
	

		 } catch(Exception e) {
			 e.printStackTrace();
		 }
	}

}
