package com.woorifg.bigdata.rto.batch.utils;

import java.util.Map.Entry;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class JsonUtil {

	public static JsonObject merge(Object... obj) {
		
		JsonObject rslt = new JsonObject();
		
		for(int i=0;i<obj.length;i++) {
			
			if(obj[i] != null) {
				for(Entry<String, JsonElement> en : ((JsonObject)obj[i]).entrySet()) {
					rslt.add(en.getKey(), en.getValue());
				}
			} else {
				continue;
			}
		}
		
		return rslt;
	}

}
