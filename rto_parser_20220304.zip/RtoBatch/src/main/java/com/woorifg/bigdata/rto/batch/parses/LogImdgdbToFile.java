package com.woorifg.bigdata.rto.batch.parses;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.ignite.client.ClientConnectionException;
import org.apache.ignite.client.ClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.utils.DamoEncUtil;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.StringUtil;

// Step 1. Log to Json
public class LogImdgdbToFile {

	private static final String CONN_STR;
	private static final String propf;
	
	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
		
		if (System.getProperty("active") != null && "local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			propf = null;
			System.err.println("No active profile !!!! : -Dactive=[local|dev|test|prod]");
			System.exit(Consts.EXIT_ERR_NO_ACTIVE_PROFILE);
		}
		
		// IMDG Connection String
		if(System.getProperty("rto.imdg.thin.url") != null) {
			CONN_STR = System.getProperty("rto.imdg.thin.url");
		} else {
			CONN_STR = PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.thin.url");
		}
		
		if(CONN_STR == null || CONN_STR.trim().isEmpty()) {
			System.err.println("No rto.imdg.thin.url in properties [ IMDG URL ] or -Drto.imdg.thin.url=${IMDG conn str}");
			System.exit(Consts.EXIT_ERR_NO_DAMO_INI);
		}
	}

	private static final Logger log = LoggerFactory.getLogger(LogImdgdbToFile.class);

//	private static final String IN_CHARSET = "UTF-8";
//	private static final String IN_CHARSET = "ms949";
	private static final String OUT_CHARSET = "UTF-8";
//	private static final String OUT_CHARSET = "ms949";
	
	private static final String SRC_TBL = "RTO0001TM";			// LOG_ORG

	
	public void imdgRto0001TmToFileJson(final String TGT_PATH, String sFrom, String sTo) {

		StopWatch swch = new StopWatch("imdgRto0001TmToFileJson");
		swch.start();
		
		StringBuilder sb = new StringBuilder();
		
		// 아래의 순서되로 SELECT 및 결과 리턴시 아래 순서로 저장 처리
		sb.append("HTTP_CC_GUID;")
			.append("HTTP_CC_SESSION;")
			.append("HTTP_TIME;")
			.append("HOST_NAME;")
			.append("LOG_AGGR_DATETIME;")
			.append("RND_KEY;")
			.append("HTTP_COOKIE;")
			.append("HTTP_METHOD;")
			.append("HTTP_REFERER;")
			.append("HTTP_URI;")
			.append("REMOTE_ADDR;")
			.append("REMOTE_USER;")
			.append("SERVER_HOST;")
			.append("SERVER_URL;")
			.append("USER_AGENT;")
			.append("HTTP_QUERY")
		;
		
		String[] keys = sb.toString().split(";", -1);
		
		StringBuilder sbQry = new StringBuilder();
		
		String selQry;
		
		if(PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.hdp.schema") != null) {
			selQry = IMDGUtil.makeSelectQryFromStrArr(keys, StringUtil.concat(PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.hdp.schema"), ".", SRC_TBL));
		} else {
			selQry = IMDGUtil.makeSelectQryFromStrArr(keys, SRC_TBL);
		}
		
		sbQry.append(selQry);
		
		if(sFrom != null) {
			sbQry.append(" WHERE HTTP_TIME >= '").append(sFrom).append("'");
		}
		
		if(sFrom != null && sTo != null) {
			sbQry.append(" AND HTTP_TIME < '").append(sTo).append("'");
		}
		
		selQry = sbQry.toString();

		
		JsonObject json;
		Gson gs = new Gson();
		
		int idxLn = 0;
		int i = 0;
		
		// Property 처리할 것
		try (Connection conn = DriverManager.getConnection(CONN_STR)) {
			
			try (Statement stmt = conn.createStatement()) {
				
				File wrFile = new File(TGT_PATH);
				
            	try (OutputStreamWriter owr = new OutputStreamWriter(new FileOutputStream(wrFile), OUT_CHARSET)) {
				
	                try (ResultSet rs = stmt.executeQuery(selQry)) {
	
	                    while (rs.next() 
//                    		&& idxLn++ < 2
	                    ) {
	
	                    	i = 1;
	                    	json = new JsonObject();
	                    	
	                    	for(String key : keys) {
	                    		
//                    			log.debug("{} -- {}", key, rs.getString(i));
	                    		
	                    		// HTTP_QUERY 복호화 처리
	                    		if("HTTP_QUERY".equals(key)) {
	                    			
	                    			if( rs.getString(i) != null ) {
		                    			json.addProperty("HTTP_QUERY", DamoEncUtil.data_decryption(rs.getString(i)));
	                    			} else {
	                    				json.add("HTTP_QUERY", null);
	                    			}
	                    		
	                    		} else {
	                    			json.addProperty(key, rs.getString(i));
	                    		}
	                    		
	                    		i++;
	                    	}
	                    	
//                    		log.debug("{}", sbCsv.toString());
	                    	owr.write(gs.toJson(json) + "\n");
	                    }
	                    
	                } catch (SQLException e) {
	                	log.error("Exception : {}", e.getMessage());
						e.printStackTrace();
					}
	                
	                owr.close();
	                
            	} catch (UnsupportedEncodingException e) {
            		log.error("Exception : {}", e.getMessage());
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					log.error("Exception : {}", e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					log.error("Exception -- line {} : {}", idxLn, e.getMessage());
					e.printStackTrace();
				}
            	
            	stmt.close();
            	
            } catch (SQLException e) {
            	log.error("Exception : {}", e.getMessage());
				e.printStackTrace();
			} 
			
			conn.close();
			
		} catch (ClientConnectionException e) {
			log.error("Exception : {}", e.getMessage());
			e.printStackTrace();
		} catch (ClientException e) {
			log.error("Exception : {}", e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("Exception : {}", e.getMessage());
			e.printStackTrace();
		}

		swch.stop();
		log.info("{}s", swch.getTotalTimeSeconds());
	}
		
}
