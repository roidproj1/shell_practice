package com.woorifg.bigdata.rto.batch.utils;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.woorifg.bigdata.rto.batch.consts.Consts;

public class EncryptUtil {

	public static byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00 }; // 16

	public static String KEY = "sftpifg!(SFTP2hd";
	
	public static String assemblingKey(byte[] raw) {
		
		try {
			StringBuilder strbuf = new StringBuilder();

			for (int i = 8; i < 12; i++) { 		// 3
				strbuf.append((char) raw[i]);
			}

			for (int i = 4; i < 8; i++) { 		// 2
				strbuf.append((char) raw[i]);
			}

			for (int i = 12; i < 16; i++) { 	// 4
				strbuf.append((char) raw[i]);
			}

			for (int i = 0; i < 4; i++) { 		// 1
				strbuf.append((char) raw[i]);
			}
			
			return strbuf.toString();
			
		} catch (Throwable ex) {
			
			try {
				return new String(raw, "UTF-8");
			} catch (UnsupportedEncodingException ex2) {
				return new String(raw);
			}
			
		}
	}

	public static String encrypt(String str)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		String secretKey = EncryptUtil.KEY.substring(0, 16); // 32byte 이하는 에러발생
		byte[] textBytes = str.getBytes("UTF-8");

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
		Cipher cipher = null;
		cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
		
		return Base64.encodeBase64String(cipher.doFinal(textBytes));
	}	
	
	
	// encrypt
	public static String encrypt(String str, String key)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		String secretKey = key.substring(0, 16); // 32byte 이하는 에러발생
		byte[] textBytes = str.getBytes("UTF-8");

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
		Cipher cipher = null;
		cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
		
		return Base64.encodeBase64String(cipher.doFinal(textBytes));
	}

	public static String decrypt(String str)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		String secretKey = EncryptUtil.KEY.substring(0, 16);
		byte[] textBytes = Base64.decodeBase64(str); 

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
		
		return new String(cipher.doFinal(textBytes), "UTF-8");
	}	
	
	// decrypt
	public static String decrypt(String str, String key)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		String secretKey = key.substring(0, 16);
		byte[] textBytes = Base64.decodeBase64(str); 

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
		
		return new String(cipher.doFinal(textBytes), "UTF-8");
	}

	public static void main(String[] args)
			throws InvalidKeyException, UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		if (args.length != 2) {
			System.err.println(
					"param: java -cp ${LIB_PATH} com.woorifg.bigdata.rto.batch.utils.EncryptUtil [e|d] ${string}");
			System.exit(Consts.EXIT_ERR_INVALID_ARGS);
		} 
		
		StringBuilder sb = new StringBuilder();
		
		switch(args[0]) {
		
		case "e":
			
			String encStr = EncryptUtil.encrypt(args[1]);
			sb.append(args[1]).append(" --> ").append(encStr);
			break;
			
		case "d":
			String decStr = EncryptUtil.decrypt(args[1], EncryptUtil.KEY);
			sb.append(args[1]).append(" --> ").append(decStr);
			
			break;		
		}
		
		System.out.println(sb.toString());
		sb.setLength(0);

	}

}
