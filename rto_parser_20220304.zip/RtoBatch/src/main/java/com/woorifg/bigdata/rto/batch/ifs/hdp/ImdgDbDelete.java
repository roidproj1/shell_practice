package com.woorifg.bigdata.rto.batch.ifs.hdp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.woorifg.bigdata.rto.batch.consts.Consts;
import com.woorifg.bigdata.rto.batch.enums.ErrSftpBatch;
import com.woorifg.bigdata.rto.batch.utils.DateUtil;
import com.woorifg.bigdata.rto.batch.utils.IMDGUtil;
import com.woorifg.bigdata.rto.batch.utils.PropertiesUtil;
import com.woorifg.bigdata.rto.batch.utils.StringUtil;

public class ImdgDbDelete {

	private static final String CONN_STR;
	private static final String propf;
	
	static {
		if (System.getProperty("log_name") == null) {
			System.setProperty("log_name", Consts.DEFAULT_LOG_NAME);
		}
		
		if (System.getProperty("active") != null && "local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			propf = null;
			System.err.println("No active profile !!!! : -Dactive=[local|dev|test|prod]");
			System.exit(Consts.EXIT_ERR_NO_ACTIVE_PROFILE);
		}
		
		// IMDG Connection String
		if(System.getProperty("rto.imdg.thin.url") != null) {
			CONN_STR = System.getProperty("rto.imdg.thin.url");
		} else {
			CONN_STR = PropertiesUtil.getProperty(propf + ".properties").getProperty("rto.imdg.thin.url");
		}
		
		if(CONN_STR == null || CONN_STR.trim().isEmpty()) {
			System.err.println("No rto.imdg.thin.url in properties [ IMDG URL ] or -Drto.imdg.thin.url=${IMDG conn str}");
			System.exit(Consts.EXIT_ERR_NO_DAMO_INI);
		}
	}
		
	private static final Logger log = LoggerFactory.getLogger(IfHdpRto0001Tm.class);

	private static final String IF_HDP_HEAD = "java -Dlog_base=${LOG_BASE} -Dlog_name=${LOG_NM} -cp ${LIB_PATH} ";
	private static final String IF_HDP_PROF = "-Dactive=[local|dev|test|prod] ";	
		
	private static final String clsNm = ImdgDbDelete.class.getName();	
	
	public static void main(String[] args) {

		// validation start
		String propf = null;
		
		if (System.getProperty("active") == null) {
			log.error(IF_HDP_PROF + " : active profile required !!!");
			System.err.println(IF_HDP_PROF + " : active profile required !!!");
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		
		if ("local|dev|test|prod".indexOf(System.getProperty("active")) > -1) {
			propf = System.getProperty("active");
		} else {
			log.error(IF_HDP_PROF + " : invalid active profile !!!");
			System.err.println(IF_HDP_PROF + " : invalid active profile !!!");			
			
			System.exit(ErrSftpBatch.PROFILE_NULL.getVal());
		}
		
		if (args == null || args.length != 4 ) {
			log.error(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${TGT_SCHEMA.TBL} ${COL_NM} ${From:yyyyMMddHHmmssSSS} ${To:yyyyMMddHHmmssSSS}"));
			log.error(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=ImdgDbDelete_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," PUBLIC.TEMP_TBL 20220201000000000 20220302000000000"));

			System.err.println(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${TGT_SCHEMA.TBL} ${COL_NM} ${From:yyyyMMddHHmmssSSS} ${To:yyyyMMddHHmmssSSS}"));
			System.err.println(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=ImdgDbDelete_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," PUBLIC.TEMP_TBL 20220201000000000 20220302000000000"));
			
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
		}
		
		log.debug("{} start !!!", clsNm);
		log.debug("active profile : {} -- {}.properties", System.getProperty("active"), propf);		

		
		if( 
			(args[0] == null || args[0].trim().isEmpty()) || 
			(args[1] == null || args[1].trim().isEmpty()) ||
			!StringUtil.isNumeric(args[2]) ||
			!StringUtil.isNumeric(args[3])
		) {
			
			log.error(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${TGT_SCHEMA.TBL} ${COL_NM} ${From:yyyyMMddHHmmssSSS} ${To:yyyyMMddHHmmssSSS}"));
			log.error(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=ImdgDbDelete_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," PUBLIC.TEMP_TBL 20220201000000000 20220302000000000"));

			System.err.println(StringUtil.concat("param: ", IF_HDP_HEAD, IF_HDP_PROF, clsNm, " ${TGT_SCHEMA.TBL} ${COL_NM} ${From:yyyyMMddHHmmssSSS} ${To:yyyyMMddHHmmssSSS}"));
			System.err.println(StringUtil.concat("ex) java -Dlog_base=/ecube/log -Dlog_name=ImdgDbDelete_20220225.log -cp ${LIB_PATH} -Dactive=prod ", clsNm ," PUBLIC.TEMP_TBL 20220201000000000 20220302000000000"));
			
			System.exit(ErrSftpBatch.ARGS_ERROR.getVal());
			
		}
		
		String sFrom = null;
		String sTo = null;
		
		// from ~ to ~
		sFrom = DateUtil.makeYyyyMMddHHmmssSSS(args[2]);
		sTo = DateUtil.makeYyyyMMddHHmmssSSS(args[3]);
		
//		sFrom = args[2];
//		sTo = args[3];
		
		
		String delQry = IMDGUtil.makeDeleteQryFromTblCols(args[0], args[1], sFrom, sTo);
		
		log.info(delQry);
		
		try (Connection conn = DriverManager.getConnection(CONN_STR)) {

			try (Statement stmt = conn.createStatement()) {
				stmt.execute(delQry);
				stmt.close();
			} 
			
			conn.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		log.debug("{} end !!!", clsNm);		

	}

}
